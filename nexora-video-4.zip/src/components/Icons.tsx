import React from 'react';
import {theme} from '../theme';

type P = {size?: number; color?: string; fill?: string; sw?: number; style?: React.CSSProperties};

const Svg: React.FC<P & {vb?: string; children?: React.ReactNode}> = ({size = 80, vb = '0 0 100 100', style, children}) => (
  <svg width={size} height={size} viewBox={vb} style={{display: 'block', overflow: 'visible', ...style}}>
    {children}
  </svg>
);
const S = (c: string, sw: number) => ({stroke: c, strokeWidth: sw, strokeLinecap: 'round' as const, strokeLinejoin: 'round' as const});

export const Flame: React.FC<P> = ({size = 120, color = theme.colors.accent, fill = theme.colors.accent, sw = 0, style}) => (
  <Svg size={size} vb="0 0 100 130" style={style}>
    <path d="M50 6 C58 30 86 46 86 82 C86 108 68 124 50 124 C32 124 14 108 14 82 C14 62 26 52 34 38 C38 52 44 56 48 58 C46 40 44 22 50 6 Z" fill={fill} {...S(color, sw)} />
    <path d="M50 66 C56 80 68 86 68 100 C68 112 60 120 50 120 C40 120 32 112 32 100 C32 90 42 84 50 66 Z" fill={theme.colors.bg} opacity={0.85} />
  </Svg>
);
export const Check: React.FC<P> = ({size = 60, color = theme.colors.text, sw = 12, style}) => (
  <Svg size={size} style={style}><path d="M18 54 L42 76 L84 26" fill="none" {...S(color, sw)} /></Svg>
);
export const Cross: React.FC<P> = ({size = 60, color = theme.colors.text, sw = 12, style}) => (
  <Svg size={size} style={style}><path d="M24 24 L76 76 M76 24 L24 76" fill="none" {...S(color, sw)} /></Svg>
);
export const Bell: React.FC<P> = ({size = 90, color = theme.colors.text, fill = 'none', sw = 7, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 12 C34 12 24 26 24 44 L24 60 L14 76 L86 76 L76 60 L76 44 C76 26 66 12 50 12 Z" fill={fill} {...S(color, sw)} />
    <path d="M40 86 C42 94 58 94 60 86" fill="none" {...S(color, sw)} />
  </Svg>
);
export const Phone: React.FC<P> = ({size = 90, color = theme.colors.text, fill = 'none', sw = 7, style}) => (
  <Svg size={size} style={style}>
    <rect x="28" y="8" width="44" height="84" rx="10" fill={fill} {...S(color, sw)} />
    <path d="M44 80 L56 80" {...S(color, sw)} />
  </Svg>
);
export const Play: React.FC<P> = ({size = 80, color = theme.colors.text, fill = theme.colors.text, sw = 6, style}) => (
  <Svg size={size} style={style}><path d="M32 18 L82 50 L32 82 Z" fill={fill} {...S(color, sw)} /></Svg>
);
export const Sun: React.FC<P> = ({size = 120, color = theme.colors.accent, fill = theme.colors.accent, sw = 7, style}) => (
  <Svg size={size} style={style}>
    <circle cx="50" cy="50" r="18" fill={fill} {...S(color, sw)} />
    {Array.from({length: 8}).map((_, i) => {
      const a = (i * Math.PI) / 4;
      return <path key={i} d={`M${50 + Math.cos(a) * 30} ${50 + Math.sin(a) * 30} L${50 + Math.cos(a) * 42} ${50 + Math.sin(a) * 42}`} {...S(color, sw)} />;
    })}
  </Svg>
);
export const RainCloud: React.FC<P> = ({size = 120, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M28 60 C14 60 12 42 26 38 C26 22 48 18 56 32 C70 26 84 38 78 54 C90 58 88 72 74 72 L30 72 C18 72 16 62 28 60 Z" fill={fill} {...S(color, sw)} />
    <path d="M34 82 L28 94 M52 82 L46 94 M70 82 L64 94" {...S(color, sw)} />
  </Svg>
);
export const House: React.FC<P> = ({size = 160, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M12 48 L50 14 L88 48" fill="none" {...S(color, sw)} />
    <path d="M22 44 L22 86 L78 86 L78 44" fill={fill} {...S(color, sw)} />
    <rect x="42" y="58" width="16" height="28" rx="3" fill={color} />
  </Svg>
);
export const Toothbrush: React.FC<P> = ({size = 140, color = theme.colors.text, fill = theme.colors.accent, sw = 5, style}) => (
  <Svg size={size} style={style}>
    <rect x="4" y="46" width="66" height="12" rx="6" fill={theme.colors.cardSolid} {...S(color, sw)} />
    <rect x="60" y="36" width="36" height="22" rx="7" fill={fill} {...S(color, sw)} />
    <path d="M66 36 L66 22 M74 36 L74 20 M82 36 L82 20 M90 36 L90 22" {...S(color, sw)} />
  </Svg>
);
export const Pin: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 92 C28 66 22 54 22 40 C22 24 34 12 50 12 C66 12 78 24 78 40 C78 54 72 66 50 92 Z" fill={fill} {...S(color, sw)} />
    <circle cx="50" cy="40" r="10" fill={theme.colors.cardSolid} />
  </Svg>
);
export const Repeat: React.FC<P> = ({size = 90, color = theme.colors.text, sw = 8, style}) => (
  <Svg size={size} style={style}>
    <path d="M20 44 L20 36 C20 28 26 24 34 24 L78 24 M66 12 L78 24 L66 36" fill="none" {...S(color, sw)} />
    <path d="M80 56 L80 64 C80 72 74 76 66 76 L22 76 M34 88 L22 76 L34 64" fill="none" {...S(color, sw)} />
  </Svg>
);
export const Moon: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M66 14 C40 16 22 36 24 60 C26 82 46 94 66 90 C48 80 44 52 56 34 C60 26 64 20 66 14 Z" fill={fill} {...S(color, sw)} />
  </Svg>
);
export const Pulse: React.FC<P> = ({size = 90, color = theme.colors.text, sw = 7, style}) => (
  <Svg size={size} style={style}><path d="M6 54 L26 54 L36 24 L52 82 L62 44 L70 54 L94 54" fill="none" {...S(color, sw)} /></Svg>
);
export const Apple: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 30 C36 18 14 28 16 52 C18 74 34 90 50 84 C66 90 82 74 84 52 C86 28 64 18 50 30 Z" fill={fill} {...S(color, sw)} />
    <path d="M50 30 C50 20 54 14 62 10" fill="none" {...S(color, sw)} />
  </Svg>
);
export const Sparkle: React.FC<P> = ({size = 90, color = theme.colors.accent, fill = theme.colors.accent, sw = 4, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 6 C54 34 66 46 94 50 C66 54 54 66 50 94 C46 66 34 54 6 50 C34 46 46 34 50 6 Z" fill={fill} {...S(color, sw)} />
  </Svg>
);
export const Book: React.FC<P> = ({size = 110, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M14 18 L50 26 L86 18 L86 78 L50 86 L14 78 Z" fill={fill} {...S(color, sw)} />
    <path d="M50 26 L50 86" {...S(color, sw)} />
  </Svg>
);
export const Flag: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M26 10 L26 92" {...S(color, sw + 2)} />
    <path d="M26 14 L78 14 L66 32 L78 50 L26 50 Z" fill={fill} {...S(color, sw)} />
  </Svg>
);
export const Bulb: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 10 C30 10 20 26 22 42 C24 54 34 60 36 70 L64 70 C66 60 76 54 78 42 C80 26 70 10 50 10 Z" fill={fill} {...S(color, sw)} />
    <path d="M38 80 L62 80 M42 90 L58 90" {...S(color, sw)} />
  </Svg>
);

// ── অতিরিক্ত আইকন (Deadline Blue ভিডিও) ──
export const Heart: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}><path d="M50 86 C14 60 12 30 32 24 C42 21 48 28 50 34 C52 28 58 21 68 24 C88 30 86 60 50 86 Z" fill={fill} {...S(color, sw)} /></Svg>
);
export const Warn: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 12 L90 82 L10 82 Z" fill={fill} {...S(color, sw)} />
    <path d="M50 40 L50 58 M50 68 L50 70" {...S(theme.colors.bg, sw + 1)} />
  </Svg>
);
export const Shield: React.FC<P> = ({size = 100, color = theme.colors.text, fill = theme.colors.hero, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 8 L84 20 L84 48 C84 70 68 84 50 92 C32 84 16 70 16 48 L16 20 Z" fill={fill} {...S(color, sw)} />
    <path d="M34 50 L46 62 L68 36" fill="none" {...S(color, sw)} />
  </Svg>
);
export const Person: React.FC<P> = ({size = 100, color = theme.colors.text, fill = theme.colors.hero, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <circle cx="50" cy="32" r="18" fill={fill} {...S(color, sw)} />
    <path d="M16 90 C16 62 84 62 84 90" fill={fill} {...S(color, sw)} />
  </Svg>
);
export const Pill: React.FC<P> = ({size = 100, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <g transform="rotate(-40 50 50)">
      <rect x="8" y="30" width="84" height="40" rx="20" fill={theme.colors.cardSolid} {...S(color, sw)} />
      <path d="M50 30 L50 70 M50 30 C70 30 92 36 92 50 C92 64 70 70 50 70 Z" fill={fill} {...S(color, sw)} />
    </g>
  </Svg>
);
export const Doc: React.FC<P> = ({size = 110, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M24 8 L62 8 L80 26 L80 92 L24 92 Z" fill={fill} {...S(color, sw)} />
    <path d="M62 8 L62 26 L80 26" fill="none" {...S(color, sw)} />
    <path d="M36 46 L68 46 M36 60 L68 60 M36 74 L56 74" {...S(color, sw)} />
  </Svg>
);
export const Magnifier: React.FC<P> = ({size = 120, color = theme.colors.text, fill = theme.colors.heroSoft, sw = 7, style}) => (
  <Svg size={size} style={style}>
    <circle cx="42" cy="42" r="28" fill={fill} {...S(color, sw)} />
    <path d="M63 63 L90 90" {...S(color, sw + 3)} />
  </Svg>
);
export const Battery: React.FC<P & {level?: number}> = ({size = 140, color = theme.colors.text, fill = theme.colors.accent, sw = 6, level = 0, style}) => (
  <Svg size={size} style={style}>
    <rect x="8" y="32" width="76" height="36" rx="8" fill="none" {...S(color, sw)} />
    <rect x="86" y="42" width="8" height="16" rx="3" fill={color} />
    {level > 0 && <rect x="14" y="38" width={64 * level} height="24" rx="4" fill={fill} />}
  </Svg>
);
export const Tag: React.FC<P> = ({size = 120, color = theme.colors.text, fill = theme.colors.accent, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M10 14 L48 14 L90 56 L56 90 L14 48 Z" fill={fill} {...S(color, sw)} />
    <circle cx="28" cy="30" r="6" fill={theme.colors.bg} />
  </Svg>
);
export const Mountain: React.FC<P> = ({size = 120, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M6 84 L38 26 L54 54 L66 36 L94 84 Z" fill={fill} {...S(color, sw)} />
  </Svg>
);
export const ClockIcon: React.FC<P> = ({size = 100, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <circle cx="50" cy="50" r="40" fill={fill} {...S(color, sw)} />
    <path d="M50 26 L50 50 L66 60" fill="none" {...S(color, sw)} />
  </Svg>
);
export const Pause: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.text, sw = 4, style}) => (
  <Svg size={size} style={style}>
    <rect x="26" y="20" width="16" height="60" rx="5" fill={fill} {...S(color, sw)} />
    <rect x="58" y="20" width="16" height="60" rx="5" fill={fill} {...S(color, sw)} />
  </Svg>
);

export const Door: React.FC<P & {open?: number}> = ({size = 200, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, open = 0, style}) => (
  <Svg size={size} style={style}>
    <rect x="22" y="8" width="56" height="86" rx="4" fill={open > 0 ? theme.colors.hero : 'none'} opacity={open > 0 ? 0.35 + open * 0.6 : 1} {...S(color, sw)} />
    <path d={`M22 8 L${22 + 56 * (1 - open * 0.7)} ${8 + open * 6} L${22 + 56 * (1 - open * 0.7)} ${94 - open * 6} L22 94 Z`} fill={fill} {...S(color, sw)} />
    <circle cx={22 + 56 * (1 - open * 0.7) - 8} cy="52" r="3.5" fill={color} />
  </Svg>
);
export const Key: React.FC<P> = ({size = 160, color = theme.colors.text, fill = theme.colors.hero, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <circle cx="30" cy="50" r="20" fill={fill} {...S(color, sw)} />
    <circle cx="30" cy="50" r="6" fill={theme.colors.bg} />
    <path d="M50 50 L92 50 M80 50 L80 64 M68 50 L68 60" fill="none" {...S(color, sw + 1)} />
  </Svg>
);
export const Lock: React.FC<P & {open?: boolean}> = ({size = 120, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, open = false, style}) => (
  <Svg size={size} style={style}>
    <rect x="22" y="44" width="56" height="44" rx="8" fill={fill} {...S(color, sw)} />
    <path d={open ? 'M34 44 L34 30 C34 10 70 10 70 28' : 'M34 44 L34 30 C34 8 66 8 66 30 L66 44'} fill="none" {...S(color, sw)} />
    <circle cx="50" cy="64" r="5" fill={color} />
  </Svg>
);
export const Scale: React.FC<P> = ({size = 150, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M50 12 L50 84 M30 88 L70 88 M14 34 L86 34" fill="none" {...S(color, sw)} />
    <path d="M14 34 L4 60 C4 70 24 70 24 60 Z M86 34 L76 60 C76 70 96 70 96 60 Z" fill={fill} {...S(color, sw - 1)} />
  </Svg>
);

export const Controller: React.FC<P> = ({size = 120, color = theme.colors.text, fill = theme.colors.cardSolid, sw = 6, style}) => (
  <Svg size={size} style={style}>
    <path d="M26 30 L74 30 C88 30 96 44 94 60 C92 74 82 80 74 70 L66 62 L34 62 L26 70 C18 80 8 74 6 60 C4 44 12 30 26 30 Z" fill={fill} {...S(color, sw)} />
    <path d="M28 40 L28 54 M21 47 L35 47" {...S(color, sw)} />
    <circle cx="70" cy="42" r="4" fill={color} /><circle cx="80" cy="50" r="4" fill={color} />
  </Svg>
);
export const Hourglass: React.FC<P & {level?: number}> = ({size = 220, color = theme.colors.text, fill = theme.colors.hero, sw = 6, level = 0.5, style}) => (
  <Svg size={size} style={style}>
    <path d="M26 8 L74 8 L74 20 C74 38 54 44 54 50 C54 56 74 62 74 80 L74 92 L26 92 L26 80 C26 62 46 56 46 50 C46 44 26 38 26 20 Z" fill="none" {...S(color, sw)} />
    <path d={`M${50 - 22 * level} ${44 - 30 * level} L${50 + 22 * level} ${44 - 30 * level} L50 46 Z`} fill={fill} opacity={level > 0.02 ? 1 : 0} />
    <path d={`M${50 - 22 * (1 - level)} 90 L${50 + 22 * (1 - level)} 90 L50 ${90 - 30 * (1 - level)} Z`} fill={fill} opacity={1 - level > 0.02 ? 1 : 0} />
    <path d="M50 46 L50 82" stroke={fill} strokeWidth="3" opacity={level > 0.02 && level < 0.98 ? 1 : 0} />
  </Svg>
);
export const Coin: React.FC<P> = ({size = 90, color = theme.colors.text, fill = theme.colors.hero, sw = 6, style}) => (
  <Svg size={size} style={style}><circle cx="50" cy="50" r="38" fill={fill} {...S(color, sw)} /><path d="M50 28 L50 72 M38 40 C38 30 62 30 62 40 C62 50 38 50 38 60 C38 70 62 70 62 60" fill="none" {...S(theme.colors.onHero, sw - 1)} /></Svg>
);
