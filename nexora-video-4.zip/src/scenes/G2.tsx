import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from '../components/Ui';
import {Counter, DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Check, ClockIcon, Controller, Cross, Door, Flag, Heart, Hourglass, Lock, Moon, Person, Repeat, Sparkle, Coin, Phone} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {BlurBG, C, Flash, H, PhotoCard, glow} from '../components/Kit';

const warn = `0 0 90px ${theme.colors.accentGlow}, ${theme.shadow}`;

// ১৭ — "এবার সেই হিসাবটা": ২৪ ঘণ্টার ঘড়িতে ৩ ঘণ্টা (cue 41–43)
export const ThreeHours: React.FC = () => {
  const {at, len} = useScene();
  const R = 240, circ = 2 * Math.PI * R;
  const fill = useEase(at(42) + 10, 40, 'inOut');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
          <Words text="এবার সেই *হিসাবটা*" delay={at(41)} per={7} size={130} />
          <Enter delay={at(42)} dir="up"><div style={{...H, fontWeight: theme.weight.strong, fontSize: 64, lineHeight: 1.35}}>রোজ মাত্র <span style={{color: theme.colors.hero}}>তিন ঘণ্টা</span> গেম</div></Enter>
          <Enter delay={at(43)} dir="up" cfg="bouncy"><Chip dark style={{fontSize: 52, padding: '12px 48px'}}>বেশি না, তিন ঘণ্টা</Chip></Enter>
        </div>
        <Enter delay={at(41)} cfg="bouncy" from={0.6} style={{flexShrink: 0}}>
          <div style={{position: 'relative', width: 620, height: 620}}>
            <svg width={620} height={620} viewBox="0 0 620 620" style={{transform: 'rotate(-90deg)'}}>
              <circle cx={310} cy={310} r={R} fill={theme.colors.card} stroke={theme.colors.line} strokeWidth={50} />
              <circle cx={310} cy={310} r={R} fill="none" stroke={theme.colors.hero} strokeWidth={50} strokeDasharray={`${circ * (3 / 24) * fill} ${circ}`} />
              <circle cx={310} cy={310} r={R} fill="none" stroke={theme.colors.bg} strokeWidth={50} strokeDasharray="3 " opacity={0} />
            </svg>
            <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', ...H}}>
              <span style={{fontSize: 200, lineHeight: 1.1, color: theme.colors.hero}}>৩</span><span style={{fontSize: 60, fontWeight: theme.weight.strong}}>ঘণ্টা / ২৪</span>
            </div>
          </div>
        </Enter>
      </div>
      <Flash at={at(41) + 1} />
      <Sfx at={at(41)} type="thud" />
      <Sfx at={at(42) + 10} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(43)} type="pop" />
    </Stage>
  );
};

// ১৮ — ৩ × ৩৬৫ = ১০৯৫ ঘণ্টা (cue 44)
export const Equation: React.FC = () => {
  const {at, len} = useScene();
  const toks = ['৩ ঘণ্টা', '×', '৩৬৫ দিন', '='].map((t, i) => ({t, d: at(44) + 6 + i * 16}));
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        {toks.map((k, i) => (
          <Enter key={k.t} delay={k.d} cfg="bouncy" from={0.5}>
            {i % 2 ? <span style={{...H, fontSize: 130, color: theme.colors.accent}}>{k.t}</span> : <Card style={{padding: '18px 48px'}}><span style={{...H, fontSize: 110}}>{k.t}</span></Card>}
          </Enter>
        ))}
      </div>
      <Enter delay={at(44) + 76} cfg="bouncy" from={0.5} style={{marginTop: 50}}>
        <Card dark style={{padding: '14px 100px', boxShadow: glow, display: 'flex', alignItems: 'baseline', gap: 26}}>
          <Counter from={0} to={1095} delay={at(44) + 80} dur={46} style={{...H, fontSize: 280, lineHeight: 1.15}} /><span style={{...H, fontSize: 90}}>ঘণ্টা</span>
        </Card>
      </Enter>
      {toks.map((k, i) => <Sfx key={k.t} at={k.d} type="pop" rate={0.95 + i * 0.07} vol={0.7} />)}
      <Sfx at={at(44) + 80} type="whoosh" rate={1.1} />
      <Sfx at={at(44) + 126} type="thud" />
    </Stage>
  );
};

// ১৯ — ১০৯৫ ঘণ্টা ≈ ৪৬ দিন (cue 45–47)
export const Days: React.FC = () => {
  const {at, len} = useScene();
  const total = 46, cols = 12;
  const span = len(45, 47) - 30;
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
          <Enter delay={at(45)} dir="down" dist={24}><Chip dark>১০৯৫ ঘণ্টা মানে</Chip></Enter>
          <div style={{display: 'flex', alignItems: 'baseline', gap: 20}}><Counter from={0} to={46} delay={at(45) + 20} dur={Math.max(60, span - 20)} style={{...H, fontSize: 300, color: theme.colors.hero, lineHeight: 1.15, textShadow: `0 0 60px ${theme.colors.heroGlow}`}} /><span style={{...H, fontSize: 110}}>দিন</span></div>
          <Enter delay={at(46)} dir="up"><Card style={{padding: '20px 40px', alignSelf: 'flex-start'}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>বছরের দেড় মাসের একটু বেশি</span></Card></Enter>
          <Enter delay={at(47)} dir="up" cfg="bouncy"><Card dark style={{padding: '20px 40px', alignSelf: 'flex-start', boxShadow: warn}}><span style={{...H, fontSize: 56}}>না ঘুমিয়ে, না খেয়ে শুধু গেম</span></Card></Enter>
        </div>
        <Enter delay={at(45)} dir="left" dist={60} style={{width: 840, flexShrink: 0}}>
          <Card style={{padding: 34}}>
            <div style={{display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 10}}>
              {Array.from({length: 48}).map((_, i) => {
                const d = at(45) + 16 + Math.round((i * span) / total);
                const on = i < total;
                const p = useSpring(d, 'snappy');
                return <div key={i} style={{height: 56, borderRadius: 12, background: on ? (i > 44 ? theme.colors.accent : theme.colors.hero) : theme.colors.heroSoft, opacity: on ? clamp01(p * 1.5) : 0.35, transform: on ? `scale(${0.6 + p * 0.4})` : 'none'}} />;
              })}
            </div>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(45)} type="whoosh" vol={0.7} />
      <Sfx at={at(46)} type="pop" />
      <Sfx at={at(47)} type="thud" vol={0.7} />
    </Stage>
  );
};

// ২০ — দুই ঘণ্টা হলেও প্রায় ৩০ দিন (cue 48–49)
export const TwoHours: React.FC = () => {
  const {at} = useScene();
  const a = useEase(at(48), 40, 'out'), b = useEase(at(48) + 30, 40, 'out');
  return (
    <Stage style={C}>
      <Words text="দুই ঘণ্টা হলেও?" delay={at(48)} per={7} size={100} />
      <Card style={{marginTop: 50, padding: '50px 56px', display: 'flex', flexDirection: 'column', gap: 40}}>
        {[{l: '৩ ঘণ্টা', v: 46, p: a, c: theme.colors.hero}, {l: '২ ঘণ্টা', v: 30, p: b, c: theme.colors.accent}].map((r) => (
          <div key={r.l} style={{display: 'flex', alignItems: 'center', gap: 36}}>
            <span style={{...H, fontSize: 64, width: 250}}>{r.l}</span>
            <div style={{flex: 1, height: 70, borderRadius: 16, background: theme.colors.heroSoft}}><div style={{width: `${(r.v / 46) * 100 * r.p}%`, height: '100%', borderRadius: 16, background: r.c}} /></div>
            <span style={{...H, fontSize: 80, width: 230, color: r.c}}>{toBn(Math.round(r.v * r.p))} দিন</span>
          </div>
        ))}
      </Card>
      <Enter delay={at(49)} dir="up" cfg="bouncy" style={{marginTop: 44, alignSelf: 'center'}}><Chip dark style={{fontSize: 60, padding: '14px 60px'}}>পুরো একটা মাস</Chip></Enter>
      <Sfx at={at(48)} type="whoosh" vol={0.7} />
      <Sfx at={at(48) + 30} type="pop" />
      <Sfx at={at(49)} type="thud" vol={0.7} />
    </Stage>
  );
};

// ২১ — এই ঘণ্টা দিয়ে কী শুরু করতে পারতে? (cue 50–51)
export const CouldDo: React.FC = () => {
  const {at, len} = useScene();
  const items = ['নতুন দক্ষতা', 'ছোট ব্যবসার পরিকল্পনা', 'পড়াশোনায় বড় লাভ', 'শরীর ঠিক করা', 'পরিবারকে সময়'].map((t, i) => ({t, d: at(51) + 6 + Math.round((i * (len(51) - 14)) / 5)}));
  return (
    <>
      <BlurBG src="images/study-desk.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 18}}>
            <Words text="এই ঘণ্টা দিয়ে কী *শুরু* করতে পারতে?" delay={at(50)} per={5} size={78} />
            {items.map((it) => <Enter key={it.t} delay={it.d} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '14px 34px'}}><Check size={50} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 50}}>{it.t}</span></Card></Enter>)}
          </div>
          <Enter delay={at(50) - 4} dir="left" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/study-desk.jpg" w={700} h={620} pos="50% 45%" zoomOut /></Enter>
        </div>
      </Stage>
      <Sfx at={at(50)} type="whoosh" vol={0.7} />
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 + i * 0.05} vol={0.7} />)}
    </>
  );
};

// ২২ — জীবন থেকে যাচ্ছে: বালুঘড়ি (cue 52–53)
export const HourglassScene: React.FC = () => {
  const {at, len} = useScene();
  const t = useEase(at(52) + 10, len(52, 53) - 20, 'inOut');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <Enter delay={at(52)} cfg="bouncy" from={0.6} style={{flexShrink: 0}}><div style={{filter: `drop-shadow(0 0 40px ${theme.colors.heroGlow})`}}><Hourglass size={520} level={1 - t} /></div></Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 30}}>
          <Enter delay={at(52)} dir="left" dist={50}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 60, color: theme.colors.textDim, lineHeight: 1.35}}>সব ঘণ্টা বাঁচাতে হবে, এমন না</div></Enter>
          <Words text="এটা তোমার *জীবন থেকে* যাচ্ছে" delay={at(52) + 30} per={5} size={92} />
          <Enter delay={at(53)} dir="up" cfg="bouncy"><Chip dark style={{fontSize: 54, padding: '12px 50px'}}>হিসাবটা জানা দরকার</Chip></Enter>
        </div>
      </div>
      <Sfx at={at(52)} type="pop" />
      <Sfx at={at(52) + 30} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(53)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ২৩ — টাকার হিসাব: ফ্রি, কিন্তু দাম সময়ে (cue 54–56)
export const Money: React.FC = () => {
  const {at} = useScene();
  const toks = [{t: '৫০০ টাকা', d: at(54) + 4}, {t: '× ১২ মাস', d: at(54) + 30}];
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36, justifyContent: 'center'}}>
        <Enter delay={at(54)} cfg="bouncy" from={0.5}><Coin size={120} /></Enter>
        {toks.map((k) => <Enter key={k.t} delay={k.d} cfg="bouncy" from={0.5}><Card style={{padding: '14px 44px'}}><span style={{...H, fontSize: 96}}>{k.t}</span></Card></Enter>)}
        <Enter delay={at(55)} cfg="bouncy" from={0.5}><Card dark style={{padding: '14px 50px', boxShadow: glow}}><span style={{...H, fontSize: 110}}>= ৬০০০ টাকা</span></Card></Enter>
      </div>
      <div style={{display: 'flex', gap: 40, marginTop: 70, justifyContent: 'center'}}>
        <Enter delay={at(56)} dir="right" dist={60} style={{flex: 1}}><Card style={{height: 280, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16}}><Chip>গেমটা ফ্রি</Chip><span style={{...H, fontSize: 84, color: theme.colors.textDim}}><Struck delay={at(56) + 40}>দাম টাকায়</Struck></span></Card></Enter>
        <Enter delay={at(56) + 30} dir="left" dist={60} cfg="bouncy" style={{flex: 1}}><Card dark style={{height: 280, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, boxShadow: warn}}><ClockIcon size={90} color={theme.colors.onHero} fill="transparent" /><span style={{...H, fontSize: 100}}>দাম সময়ে</span></Card></Enter>
      </div>
      <Sfx at={at(54)} type="pop" />
      <Sfx at={toks[1].d} type="pop" rate={1.06} />
      <Sfx at={at(55)} type="chime" vol={0.8} />
      <Sfx at={at(56) + 40} type="click" />
      <Sfx at={at(56) + 30} type="thud" vol={0.6} />
    </Stage>
  );
};

// ২৪ — র‍্যাঙ্ক রিসেট হয়, জীবন হয় না (cue 57–59)
export const NoReset: React.FC = () => {
  const {at, len} = useScene();
  const drop = useEase(at(57) + 30, 36, 'inOut');
  const items = [{t: 'নষ্ট ঘুম', d: at(58)}, {t: 'পিছিয়ে যাওয়া পড়াশোনা', d: at(58) + Math.round(len(58) / 2)}, {t: 'দূরে সরে যাওয়া মানুষ', d: at(59) - 6}];
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
        <Enter delay={at(57)} dir="right" dist={60} style={{width: 640, flexShrink: 0}}>
          <Card style={{padding: '44px 46px'}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 20, marginBottom: 26}}><Controller size={84} /><span style={{...H, fontSize: 70}}>র‍্যাঙ্ক</span></div>
            <div style={{height: 46, borderRadius: 46, background: theme.colors.heroSoft, overflow: 'hidden'}}><div style={{width: `${interpolate(drop, [0, 1], [86, 6])}%`, height: '100%', borderRadius: 46, background: theme.colors.hero}} /></div>
            <Chip style={{marginTop: 26, fontSize: 46}}><Repeat size={44} /> সিজন শেষে রিসেট</Chip>
          </Card>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
          {items.map((it) => <Enter key={it.t} delay={it.d} dir="right" dist={60}><Card dark style={{display: 'flex', alignItems: 'center', gap: 26, padding: '24px 40px', boxShadow: warn}}><Lock size={70} fill={theme.colors.onHero} color={theme.colors.onHero} /><span style={{...H, fontSize: 56}}>{it.t}</span></Card></Enter>)}
          <Enter delay={at(59)} dir="up" cfg="bouncy"><Chip style={{fontSize: 52, padding: '12px 48px'}}>রিসেট হয় না</Chip></Enter>
        </div>
      </div>
      <Sfx at={at(57)} type="pop" />
      <Sfx at={at(57) + 30} type="whoosh" rate={0.9} vol={0.7} />
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="thud" rate={1.1 - i * 0.07} vol={0.55} />)}
    </Stage>
  );
};

// ২৫ — তিনটা ছোট নিয়ম (cue 60–62)
export const RulesIntro: React.FC = () => {
  const {at, len} = useScene();
  return (
    <Stage style={C}>
      <Words text="তাহলে কী করবে?" delay={at(60)} per={7} size={120} />
      <Enter delay={at(61)} dir="left" dist={60} style={{marginTop: 30}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 70, color: theme.colors.textDim}}>গেম <Struck delay={at(61) + 30}>ডিলিট</Struck> করতে বলব না</div></Enter>
      <div style={{display: 'flex', gap: 36, marginTop: 54}}>
        {[1, 2, 3].map((n, i) => (
          <Enter key={n} delay={at(62) + 6 + i * 12} cfg="bouncy" from={0.5} style={{flex: 1}}>
            <Card dark={i === 0} style={{height: 270, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: i === 0 ? glow : theme.shadow}}><span style={{...H, fontSize: 200, color: i === 0 ? theme.colors.onHero : theme.colors.hero}}>{toBn(n)}</span></Card>
          </Enter>
        ))}
      </div>
      <Enter delay={at(62)} dir="up" style={{marginTop: 34, alignSelf: 'center'}}><Chip style={{fontSize: 54}}>তিনটা ছোট নিয়ম</Chip></Enter>
      <Sfx at={at(60)} type="whoosh" vol={0.7} />
      <Sfx at={at(61) + 30} type="click" />
      {[0, 1, 2].map((i) => <Sfx key={i} at={at(62) + 6 + i * 12} type="pop" rate={1 + i * 0.08} vol={0.8} />)}
    </Stage>
  );
};

// ২৬ — নিয়ম ১: মাপো (cue 63–65)
export const Rule1: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/screen-time.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
            <Enter delay={at(63)} cfg="bouncy" from={0.5}><Card dark style={{display: 'inline-flex', alignItems: 'center', gap: 28, padding: '12px 54px', boxShadow: glow}}><span style={{...H, fontSize: 110, color: theme.colors.onHero}}>১</span><span style={{...H, fontSize: 130}}>মাপো</span></Card></Enter>
            <Enter delay={at(64)} dir="up"><Chip style={{fontSize: 48}}>স্ক্রিন টাইম খুলে সত্যটা দেখো</Chip></Enter>
            <Enter delay={at(65)} dir="up"><div style={{...H, fontSize: 66, lineHeight: 1.35}}>যা মাপা যায় না, তা <span style={{color: theme.colors.hero}}>বদলানো কঠিন</span></div></Enter>
          </div>
          <Enter delay={at(63) - 4} dir="left" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/screen-time.jpg" w={860} h={480} pos="55% 50%" /></Enter>
        </div>
      </Stage>
      <Sfx at={at(63)} type="thud" vol={0.7} />
      <Sfx at={at(64)} type="pop" />
      <Sfx at={at(65)} type="chime" vol={0.8} />
    </>
  );
};

// ২৭ — নিয়ম ২: শুরুর আগেই শেষ ঠিক করো (cue 66–68)
export const Rule2: React.FC = () => {
  const {at, len} = useScene();
  const toks = [0, 1, 2].map((i) => at(67) + 6 + Math.round((i * len(67)) / 3));
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(66)} cfg="bouncy" from={0.5}><Card dark style={{padding: '8px 44px', boxShadow: glow}}><span style={{...H, fontSize: 110}}>২</span></Card></Enter>
        <Words text="শুরুর আগেই *শেষ* ঠিক করো" delay={at(66) + 6} per={5} size={84} />
      </div>
      <div style={{display: 'flex', gap: 30, marginTop: 50, alignItems: 'center'}}>
        {toks.map((d, i) => (
          <Enter key={i} delay={d} cfg="bouncy" from={0.4} style={{flex: 1}}>
            <Card dark={i === 2} style={{height: 260, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, boxShadow: i === 2 ? glow : theme.shadow}}><Controller size={110} color={i === 2 ? theme.colors.onHero : theme.colors.text} fill="transparent" /><span style={{...H, fontSize: 64}}>ম্যাচ {toBn(i + 1)}</span></Card>
          </Enter>
        ))}
        <Enter delay={at(68)} dir="left" dist={60} cfg="bouncy" style={{flex: 1}}><Card style={{height: 260, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10}}><Door size={120} /><span style={{...H, fontSize: 56}}>উঠে যাও</span></Card></Enter>
      </div>
      <div style={{display: 'flex', gap: 40, marginTop: 36, alignItems: 'center'}}>
        <Enter delay={at(67)} dir="up"><Chip style={{fontSize: 46}}>ঘণ্টা নয়, ম্যাচ</Chip></Enter>
        <Enter delay={at(68) + 16} dir="up"><div style={{...H, fontSize: 60, color: theme.colors.textDim}}><Struck delay={at(68) + 40}>আর এক ম্যাচ</Struck> বলার আগেই</div></Enter>
      </div>
      <Sfx at={at(66)} type="thud" vol={0.7} />
      {toks.map((d, i) => <Sfx key={i} at={d} type="pop" rate={1 + i * 0.08} vol={0.8} />)}
      <Sfx at={at(68)} type="whoosh" vol={0.7} />
      <Sfx at={at(68) + 40} type="click" />
    </Stage>
  );
};

// ২৮ — নিয়ম ৩: ঘুমের এক ঘণ্টা আগে বন্ধ (cue 69–71)
export const Rule3: React.FC = () => {
  const {at, len} = useScene();
  const sweep = useEase(at(70), len(70) - 10, 'inOut');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(69)} cfg="bouncy" from={0.5}><Card dark style={{padding: '8px 44px', boxShadow: glow}}><span style={{...H, fontSize: 110}}>৩</span></Card></Enter>
        <Words text="ঘুমের *এক ঘণ্টা আগে* বন্ধ" delay={at(69) + 6} per={5} size={84} />
      </div>
      <Enter delay={at(69) + 14} dir="up" style={{marginTop: 54}}>
        <Card style={{padding: '50px 54px'}}>
          <div style={{display: 'flex', height: 120, borderRadius: 24, overflow: 'hidden'}}>
            <div style={{flex: 3, background: theme.colors.heroSoft, display: 'flex', alignItems: 'center', justifyContent: 'center', ...H, fontWeight: theme.weight.strong, fontSize: 46, color: theme.colors.textDim}}>দিন</div>
            <div style={{flex: 1, background: theme.colors.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, ...H, fontSize: 46, color: theme.colors.onHero, transform: `scaleY(${0.85 + sweep * 0.15})`}}><Phone size={50} color={theme.colors.onHero} /> বন্ধ</div>
            <div style={{flex: 2, background: theme.colors.hero, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, ...H, fontSize: 52, color: theme.colors.onHero}}><Moon size={56} color={theme.colors.onHero} fill={theme.colors.onHero} /> ঘুম</div>
          </div>
          <div style={{position: 'relative', height: 30, marginTop: 14}}><div style={{position: 'absolute', left: `${sweep * 66}%`, top: 0, width: 8, height: 30, background: theme.colors.text, borderRadius: 4}} /></div>
        </Card>
      </Enter>
      <Enter delay={at(70)} dir="up" style={{marginTop: 34}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>ঘুম তোমার <span style={{color: theme.colors.hero}}>সবকিছুর ভিত্তি</span> — পরদিনের মন, পড়া, কাজ</div></Enter>
      <Enter delay={at(71)} dir="up" cfg="bouncy" style={{marginTop: 20, alignSelf: 'flex-start'}}><Chip dark style={{fontSize: 52}}>এটা বাঁচাও</Chip></Enter>
      <Sfx at={at(69)} type="thud" vol={0.7} />
      <Sfx at={at(70)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(71)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ২৯ — একদিন ভাঙলে আবার ফিরে এসো (cue 72)
export const ComeBack: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const pts = [[60, 120], [240, 150], [420, 300], [540, 130], [700, 90], [880, 230], [1040, 80], [1240, 40]];
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ');
  const t = useEase(at(72) + 10, len(72) - 30, 'inOut');
  const idx = Math.min(pts.length - 2, Math.floor(t * (pts.length - 1)));
  const lt = t * (pts.length - 1) - idx;
  const px = pts[idx][0] + (pts[idx + 1][0] - pts[idx][0]) * lt, py = pts[idx][1] + (pts[idx + 1][1] - pts[idx][1]) * lt;
  return (
    <Stage style={C}>
      <Enter delay={at(72)} dir="down" dist={24}><Chip dark style={{alignSelf: 'flex-start'}}>প্রথমদিনই নিখুঁত হতে হবে না</Chip></Enter>
      <Enter delay={at(72) + 8} dir="up" style={{marginTop: 28}}>
        <Card style={{padding: 28}}>
          <svg width={1580} height={380} viewBox="0 0 1300 330" style={{overflow: 'visible'}}>
            <DrawPath d={d} delay={at(72) + 10} dur={len(72) - 30} color={theme.colors.text} width={9} />
            <circle cx={px} cy={py} r={18 + Math.sin(f / 5) * 2} fill={theme.colors.hero} opacity={clamp01(t * 30)} />
            <g transform="translate(405 292)" opacity={useEase(at(72) + 50, 14)}><Cross size={44} color={theme.colors.accent} /></g>
          </svg>
        </Card>
      </Enter>
      <Enter delay={at(72) + 70} dir="up" cfg="bouncy" style={{marginTop: 28, alignSelf: 'flex-start'}}><Card dark style={{display: 'flex', alignItems: 'center', gap: 22, padding: '18px 44px', boxShadow: glow}}><Repeat size={60} color={theme.colors.onHero} /><span style={{...H, fontSize: 56}}>একদিন ভাঙলে, পরের দিন আবার ফিরে এসো</span></Card></Enter>
      <Sfx at={at(72)} type="pop" vol={0.7} />
      <Sfx at={at(72) + 50} type="thud" vol={0.5} />
      <Sfx at={at(72) + 70} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৩০ — "আর এক ম্যাচ": বেছে নিচ্ছি নাকি অভ্যাস? (cue 73–74)
export const Choose: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const pulse = 1 + Math.sin(f / 7) * 0.03;
  return (
    <>
      <BlurBG src="images/thinking.jpg" dim={0.65} />
      <Stage style={C}>
        <Enter delay={at(73)} dir="up" cfg="bouncy" style={{alignSelf: 'center'}}><div style={{transform: `scale(${pulse})`, ...H, fontSize: 130, padding: '14px 76px', borderRadius: 28, background: theme.colors.hero, color: theme.colors.onHero, boxShadow: glow}}>“আর এক ম্যাচ”</div></Enter>
        <Enter delay={at(73) + 30} dir="up" style={{marginTop: 34, alignSelf: 'center'}}><Chip style={{fontSize: 52}}>একটু থেমে নিজেকে জিজ্ঞেস করো</Chip></Enter>
        <div style={{display: 'flex', gap: 50, marginTop: 50}}>
          <Enter delay={at(74)} dir="right" dist={60} style={{flex: 1}}><Card style={{height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 24}}><Check size={80} /><span style={{...H, fontSize: 74}}>বেছে নিচ্ছি?</span></Card></Enter>
          <Enter delay={at(74) + 22} dir="left" dist={60} cfg="bouncy" style={{flex: 1}}><Card dark style={{height: 260, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 24, boxShadow: warn}}><Repeat size={80} color={theme.colors.onHero} /><span style={{...H, fontSize: 74}}>নাকি অভ্যাস?</span></Card></Enter>
        </div>
      </Stage>
      <Sfx at={at(73)} type="thud" vol={0.7} />
      <Sfx at={at(74)} type="pop" />
      <Sfx at={at(74) + 22} type="pop" rate={0.9} />
    </>
  );
};

// ৩১ — বিশ্বস্ত কারো সঙ্গে কথা বলো (cue 75–76)
export const Help: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/sunrise-city.jpg" dim={0.55} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(75) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/sunrise-city.jpg" w={640} h={660} pos="60% 45%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Enter delay={at(75)} dir="down" dist={24}><Chip style={{fontSize: 42}}>ঘুম, পড়াশোনা, সম্পর্ক নষ্ট হতে থাকলে</Chip></Enter>
            <Words text="*বিশ্বস্ত কারো* সঙ্গে কথা বলো" delay={at(75) + 10} per={5} size={86} />
            <Enter delay={at(76)} dir="up" cfg="bouncy"><Card dark style={{padding: '26px 48px', boxShadow: glow, alignSelf: 'flex-start'}}><span style={{...H, fontSize: 72}}>সেটা হার মানা নয়</span></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(75)} type="pop" vol={0.7} />
      <Sfx at={at(76)} type="chime" />
    </>
  );
};

// ৩২ — কমেন্ট বক্স (টাইপরাইটার শুধু ইনপুট UI-তে) (cue 77)
export const CommentBox: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const words = 'গত সপ্তাহে গড় গেমিং টাইম কত ছিল?'.split(' ');
  const start = at(77) + 40, per = Math.max(6, Math.floor((len(77) - 80) / words.length));
  const shown = Math.max(0, Math.min(words.length, Math.floor((f - start) / per) + 1));
  const press = useEase(start + per * words.length + 6, 10, 'out');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(77)} dir="down" dist={24}><Chip dark>নিচের কমেন্টে</Chip></Enter>
        <Words text="লিখে *জানাও*" delay={at(77) + 6} per={7} size={92} />
      </div>
      <Enter delay={at(77) + 16} dir="up" cfg="bouncy" style={{marginTop: 46}}>
        <Card style={{padding: '40px 44px'}}>
          <div style={{display: 'flex', gap: 34, alignItems: 'flex-start'}}>
            <div style={{width: 100, height: 100, borderRadius: '50%', background: theme.colors.hero, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Person size={64} color={theme.colors.onHero} fill="transparent" /></div>
            <div style={{flex: 1, minHeight: 170, borderRadius: 28, border: `3px solid ${theme.colors.line}`, background: theme.colors.bgAlt, padding: '26px 36px', ...H, fontWeight: theme.weight.strong, fontSize: 62, lineHeight: 1.5}}>
              {words.slice(0, shown).join(' ')}
              <span style={{display: 'inline-block', width: 5, height: 64, background: theme.colors.hero, marginLeft: 8, verticalAlign: 'middle', opacity: f % 30 < 18 ? 1 : 0}} />
            </div>
          </div>
          <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: 24}}><div style={{...H, fontSize: 46, padding: '12px 46px', borderRadius: 999, background: theme.colors.hero, color: theme.colors.onHero, transform: `scale(${1 - 0.06 * Math.sin(press * Math.PI)})`, boxShadow: press > 0.5 ? glow : 'none'}}>পাঠাও</div></div>
        </Card>
      </Enter>
      <Sfx at={at(77)} type="pop" />
      <Sfx at={at(77) + 16} type="whoosh" rate={1.05} vol={0.7} />
      <Sfx at={start + per * words.length + 6} type="click" />
    </Stage>
  );
};

// ৩৩ — সাবস্ক্রাইব (cue 78)
export const Subscribe: React.FC = () => {
  const {at, len} = useScene();
  const press = useEase(at(78) + 60, 12, 'out');
  const done = press > 0.6;
  return (
    <>
      <BlurBG src="images/rooftop.jpg" dim={0.55} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 30}}>
            <Words text="এমন *বাস্তব কথা* শুনতে" delay={at(78)} per={6} size={96} />
            <Enter delay={at(78) + 30} dir="up" cfg="bouncy"><div style={{alignSelf: 'flex-start', ...H, fontSize: 66, padding: '20px 62px', borderRadius: 999, background: done ? theme.colors.heroSoft : theme.colors.hero, color: done ? theme.colors.text : theme.colors.onHero, transform: `scale(${1 - 0.07 * Math.sin(press * Math.PI)})`, boxShadow: done ? 'none' : glow, border: `3px solid ${theme.colors.hero}`, display: 'inline-block'}}>{done ? '✓ সাবস্ক্রাইবড' : 'সাবস্ক্রাইব'}</div></Enter>
          </div>
          <Enter delay={at(78) + 8} cfg="bouncy" from={0.6} float={5} style={{flexShrink: 0}}>
            <div style={{width: 560, height: 560, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 0 120px ${theme.colors.heroGlow}, ${theme.shadow}`}}><Img src={staticFile('logo.png')} style={{width: '100%', height: '100%', objectFit: 'cover'}} /></div>
          </Enter>
        </div>
      </Stage>
      <Sfx at={at(78) + 8} type="chime" />
      <Sfx at={at(78) + 60} type="click" />
    </>
  );
};

// ৩৪ — সমাপ্তি (cue 79)
export const End: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const glw = 0.75 + Math.sin(f / 18) * 0.25;
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
        <Enter delay={at(79)} cfg="bouncy" from={0.55} float={4}>
          <div style={{width: 600, height: 600, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 0 ${150 * glw}px ${theme.colors.heroGlow}, ${theme.shadow}`}}><Img src={staticFile('logo.png')} style={{width: '100%', height: '100%', objectFit: 'cover'}} /></div>
        </Enter>
        <Words text="Better Mind, Bigger Life." delay={at(79) + 22} per={7} size={104} align="center" />
      </div>
      <Sfx at={at(79)} type="chime" />
      <Sfx at={at(79) + 22} type="pop" vol={0.7} />
    </Stage>
  );
};
