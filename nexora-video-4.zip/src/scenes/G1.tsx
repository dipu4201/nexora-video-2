import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Stage} from '../components/Ui';
import {Counter, DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Check, ClockIcon, Controller, Cross, Door, Flag, Heart, Lock, Moon, Person, Phone, Repeat, Shield, Sparkle} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {BlurBG, C, Flash, H, PhotoCard, glow} from '../components/Kit';

const warn = `0 0 90px ${theme.colors.accentGlow}, ${theme.shadow}`;

// ১ — হুক: "আর এক ম্যাচ—" (cue 1–2)
export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const pulse = 1 + Math.sin(f / 6) * 0.03;
  return (
    <>
      <BlurBG src="images/shock-3am.jpg" dim={0.5} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Words text="আর এক *ম্যাচ—*" delay={at(1)} per={9} size={210} />
            <Enter delay={at(2)} dir="up" dist={30}><Chip dark style={{fontSize: 46}}>এই তিনটা শব্দ</Chip></Enter>
            <Words text="কতবার শুরু করেছ?" delay={at(2) + 8} per={6} size={96} />
            <Enter delay={at(2) + 34} dir="up" cfg="bouncy">
              <div style={{alignSelf: 'flex-start', transform: `scale(${pulse})`, ...H, fontSize: 56, padding: '16px 52px', borderRadius: 20, background: theme.colors.hero, color: theme.colors.onHero, boxShadow: glow, display: 'inline-flex', gap: 18, alignItems: 'center'}}><Repeat size={60} color={theme.colors.onHero} /> আবার খেলো</div>
            </Enter>
          </div>
          <Enter delay={at(1) - 4} dir="left" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/shock-3am.jpg" w={800} h={600} pos="50% 35%" /></Enter>
        </div>
      </Stage>
      <Flash at={at(1) + 1} />
      <Sfx at={at(1)} type="thud" />
      <Sfx at={at(2)} type="whoosh" rate={1.1} vol={0.8} />
      <Sfx at={at(2) + 34} type="click" />
    </>
  );
};

// ২ — রাত ৩টা বেজে গেছে (cue 3)
export const ThreeAM: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const hit = at(3) + Math.round(len(3) * 0.55);
  const shake = f >= hit && f < hit + 10 ? Math.sin(f * 3) * 14 : 0;
  const flick = f < at(3) + 24 ? (Math.floor(f / 3) % 2 ? 1 : 0.25) : 1;
  return (
    <>
      <BlurBG src="images/bed-phone.jpg" dim={0.6} />
      <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
        <Enter delay={at(3)} cfg="bouncy" from={0.6}>
          <Card dark={false} style={{padding: '24px 90px', transform: `translateX(${shake}px)`, boxShadow: warn, borderColor: theme.colors.accent}}>
            <span style={{...H, fontSize: 380, lineHeight: 1.15, color: theme.colors.accent, opacity: flick, fontVariantNumeric: 'tabular-nums', textShadow: `0 0 50px ${theme.colors.accentGlow}`}}>৩:০০</span>
          </Card>
        </Enter>
        <div style={{marginTop: 40}}><Words text="রাত ৩টা বেজে গেছে!" delay={at(3) + 10} per={6} size={110} align="center" /></div>
        <Enter delay={at(3) + Math.round(len(3) * 0.6)} dir="up" style={{marginTop: 26}}><Chip style={{fontSize: 46}}>কতবার চমকে উঠেছ?</Chip></Enter>
      </Stage>
      <Flash at={hit} color={theme.colors.accent} />
      <Sfx at={at(3)} type="pop" />
      <Sfx at={hit} type="thud" />
    </>
  );
};

// ৩ — গেম ছাড়তে বলব না (cue 4–5)
export const NotDelete: React.FC = () => {
  const {at} = useScene();
  const games = [{t: 'পাবজি', d: at(4) + 18}, {t: 'ফ্রি ফায়ার', d: at(4) + 30}];
  return (
    <Stage style={C}>
      <Words text="আমি তোমাকে গেম *ছাড়তে* বলব না" delay={at(4)} per={5} size={96} />
      <div style={{display: 'flex', gap: 50, marginTop: 56}}>
        {games.map((g) => (
          <Enter key={g.t} delay={g.d} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card style={{height: 360, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22}}>
              <Controller size={170} /><span style={{...H, fontSize: 84}}>{g.t}</span>
              <Chip dark style={{fontSize: 40}}>থাকুক</Chip>
            </Card>
          </Enter>
        ))}
      </div>
      <Enter delay={at(5)} dir="up" cfg="bouncy" style={{marginTop: 44, alignSelf: 'center'}}><Card dark style={{padding: '16px 70px', boxShadow: glow}}><span style={{...H, fontSize: 80}}>কোনোটাই না</span></Card></Enter>
      <Sfx at={at(4)} type="whoosh" vol={0.7} />
      {games.map((g, i) => <Sfx key={g.t} at={g.d} type="pop" rate={1 + i * 0.07} vol={0.8} />)}
      <Sfx at={at(5)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৪ — হিসাব মাঝখানে আসবে (cue 6–8)
export const MathPromise: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const run = useEase(at(7), len(7) + 20, 'inOut');
  const mark = useSpring(at(7) + 10, 'bouncy');
  return (
    <Stage style={C}>
      <Words text="আমি শুধু একটা *হিসাব* দেখাবো" delay={at(6)} per={5} size={100} />
      <Enter delay={at(7)} dir="up" style={{marginTop: 70}}>
        <Card style={{padding: '70px 60px', position: 'relative'}}>
          <div style={{height: 26, borderRadius: 26, background: theme.colors.heroSoft, position: 'relative'}}>
            <div style={{width: `${run * 50}%`, height: '100%', borderRadius: 26, background: theme.colors.hero}} />
            <div style={{position: 'absolute', left: '50%', top: -90, transform: `translateX(-50%) scale(${mark})`, opacity: clamp01(mark)}}>
              <Card dark style={{padding: '12px 36px', boxShadow: warn}}><span style={{...H, fontSize: 56}}>হিসাব</span></Card>
            </div>
            <div style={{position: 'absolute', left: '50%', top: -6, width: 6, height: 38, background: theme.colors.accent, borderRadius: 3}} />
          </div>
          <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 24, ...H, fontWeight: theme.weight.strong, fontSize: 40, color: theme.colors.textDim}}><span>শুরু</span><span>এই ভিডিওর মাঝখানে</span><span>শেষ</span></div>
        </Card>
      </Enter>
      <Enter delay={at(8)} dir="up" cfg="bouncy" style={{marginTop: 50, alignSelf: 'center'}}><Chip dark style={{fontSize: 56, padding: '14px 56px'}}>তুমি নিজেই ঠিক করবে</Chip></Enter>
      <Sfx at={at(6)} type="whoosh" vol={0.7} />
      <Sfx at={at(7) + 10} type="pop" />
      <Sfx at={at(8)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৫ — তুমি চালাচ্ছো, নাকি গেম তোমাকে? (cue 9–10)
export const WhoDrives: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const flip = useEase(at(10) + 40, 20, 'inOut');
  return (
    <>
      <BlurBG src="images/thinking.jpg" dim={0.7} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(9) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/thinking.jpg" w={740} h={560} pos="50% 40%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Enter delay={at(9)} dir="down" dist={24}><Chip dark>একটা প্রশ্ন</Chip></Enter>
            <Words text="তুমি গেম *চালাচ্ছো*" delay={at(10)} per={6} size={96} />
            <Enter delay={at(10) + 30} dir="up" cfg="bouncy"><div style={{...H, fontSize: 52, color: theme.colors.textDim}}>নাকি</div></Enter>
            <Enter delay={at(10) + 44} dir="up" cfg="bouncy"><Card dark style={{padding: '22px 44px', boxShadow: warn, display: 'inline-block', transform: `scale(${1 + flip * 0.05})`}}><span style={{...H, fontSize: 80}}>গেম তোমাকে চালাচ্ছে?</span></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(9)} type="pop" />
      <Sfx at={at(10)} type="whoosh" vol={0.7} />
      <Sfx at={at(10) + 44} type="thud" vol={0.7} />
    </>
  );
};

// ৬ — আরিফ: ২৪, রাত ১২টা, কাল কাজ (cue 11–14)
export const ArifIntro: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/room-wide.jpg" dim={0.55} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <div style={{width: 760, display: 'flex', flexDirection: 'column', gap: 26, flexShrink: 0}}>
            <Enter delay={at(11)} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 28, padding: '24px 44px'}}><Person size={90} fill={theme.colors.heroSoft} /><span style={{...H, fontSize: 84}}>আরিফ</span></Card></Enter>
            <Enter delay={at(12)} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'baseline', gap: 22, padding: '14px 44px'}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>বয়স</span><Counter from={0} to={24} delay={at(12) + 6} dur={26} style={{...H, fontSize: 130, color: theme.colors.hero}} /></Card></Enter>
            <Enter delay={at(13)} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 28, padding: '20px 44px'}}><ClockIcon size={84} color={theme.colors.hero} /><span style={{...H, fontSize: 80}}>রাত ১২টা</span></Card></Enter>
            <Enter delay={at(14)} dir="right" dist={60}><Card dark style={{display: 'flex', alignItems: 'center', gap: 28, padding: '20px 44px', boxShadow: warn}}><Flag size={80} fill={theme.colors.onHero} color={theme.colors.onHero} /><span style={{...H, fontSize: 64}}>কাল সকালে কাজ</span></Card></Enter>
          </div>
          <Enter delay={at(11) - 4} dir="left" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/room-wide.jpg" w={900} h={500} pos="40% 50%" /></Enter>
        </div>
      </Stage>
      <Sfx at={at(11)} type="pop" vol={0.8} />
      <Sfx at={at(12)} type="pop" rate={1.05} vol={0.8} />
      <Sfx at={at(13)} type="pop" rate={1.1} vol={0.8} />
      <Sfx at={at(14)} type="thud" vol={0.6} />
    </>
  );
};

// ৭ — ম্যাচের চক্র: জিত/হার, আরেকটা (cue 15–18)
export const MatchLoop: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const rows = [
    {t: 'শুধু একটা ম্যাচ, তারপর ঘুম', d: at(15), icon: <Controller size={80} />},
    {t: 'হার', d: at(16), icon: <Cross size={70} color={theme.colors.accent} />},
    {t: 'হার মেনে নেওয়া যায় না, আরেকটা', d: at(17), icon: <Repeat size={74} />},
    {t: 'এবার জয়, তাই আরও একটা', d: at(18), icon: <Check size={70} />},
  ];
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <Enter delay={at(15) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/earphones.jpg" w={700} h={560} pos="50% 50%" /></Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
          {rows.map((r, i) => (
            <Enter key={r.t} delay={r.d} dir="right" dist={70} cfg="bouncy">
              <Card dark={i === 3} style={{display: 'flex', alignItems: 'center', gap: 28, padding: '22px 38px', boxShadow: i === 3 ? glow : theme.shadow}}>{r.icon}<span style={{...H, fontWeight: theme.weight.strong, fontSize: 52, lineHeight: 1.3}}>{r.t}</span></Card>
            </Enter>
          ))}
        </div>
      </div>
      {rows.map((r, i) => <Sfx key={r.t} at={r.d} type={i === 1 ? 'thud' : 'pop'} rate={1 + i * 0.05} vol={0.7} />)}
    </Stage>
  );
};

// ৮ — আরও একটা ম্যাচের কারণ: ফর্ম, বন্ধু, র‍্যাঙ্ক (cue 19–20)
export const Reasons: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const bar = useEase(at(20), 30, 'out');
  const chase = Math.sin(f / 7) * 2;
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 36}}>
        <Enter delay={at(19)} dir="up" cfg="bouncy" style={{flex: 1}}><Card style={{height: 240, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 22}}><Sparkle size={80} /><span style={{...H, fontSize: 64}}>আজ ফর্মে আছি</span></Card></Enter>
        <Enter delay={at(19) + Math.round(len(19) / 2)} dir="up" cfg="bouncy" style={{flex: 1}}><Card style={{height: 240, display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 22}}><Person size={80} fill={theme.colors.heroSoft} /><span style={{...H, fontSize: 56, textAlign: 'center', lineHeight: 1.3}}>স্কোয়াড অনলাইনে</span></Card></Enter>
      </div>
      <Enter delay={at(20)} dir="up" style={{marginTop: 40}}>
        <Card dark style={{padding: '44px 56px', boxShadow: glow}}>
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24}}><span style={{...H, fontSize: 72}}>র‍্যাঙ্ক</span><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>আরেকটু বাকি…</span></div>
          <div style={{height: 46, borderRadius: 46, background: 'rgba(11,11,13,0.3)', overflow: 'hidden'}}><div style={{width: `${bar * 92 + chase}%`, height: '100%', borderRadius: 46, background: theme.colors.onHero}} /></div>
        </Card>
      </Enter>
      <Sfx at={at(19)} type="pop" />
      <Sfx at={at(19) + Math.round(len(19) / 2)} type="pop" rate={1.06} />
      <Sfx at={at(20)} type="whoosh" rate={1.1} vol={0.7} />
    </Stage>
  );
};

// ৯ — ভোর ৫টা (cue 21–22)
export const Dawn: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/alarm-5am.jpg" dim={0.5} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(21) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/alarm-5am.jpg" w={900} h={500} pos="40% 50%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 30}}>
            <Words text="জানলার বাইরে *আলো*" delay={at(21)} per={6} size={96} />
            <Enter delay={at(22)} dir="up" cfg="bouncy"><Card dark style={{padding: '8px 54px', boxShadow: warn, display: 'inline-block'}}><span style={{...H, fontSize: 200, lineHeight: 1.2}}>৫:০০</span></Card></Enter>
            <Enter delay={at(22) + 16} dir="up"><Chip style={{fontSize: 52}}>ভোর হয়ে গেছে</Chip></Enter>
          </div>
        </div>
      </Stage>
      <Flash at={at(22)} />
      <Sfx at={at(21)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(22)} type="thud" />
    </>
  );
};

// ১০ — সকালের ক্লান্তি (cue 23–24)
export const ClassTired: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/class-tired.jpg" dim={0.55} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Enter delay={at(23)} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '24px 40px'}}><Moon size={76} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>সকালে চোখ খোলে না</span></Card></Enter>
            <Enter delay={at(23) + 30} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '24px 40px'}}><Cross size={64} color={theme.colors.accent} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>ক্লাসে মাথা ভারী</span></Card></Enter>
            <Enter delay={at(24)} dir="up" cfg="bouncy"><Card dark style={{padding: '34px 44px', boxShadow: warn}}><Words text="আজ রাতে *কখন খেলবো?*" delay={at(24) + 6} per={6} size={84} color={theme.colors.onHero} hlColor="rgba(255,90,54,0.35)" /></Card></Enter>
          </div>
          <Enter delay={at(23) - 4} dir="left" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/class-tired.jpg" w={700} h={620} pos="50% 30%" /></Enter>
        </div>
      </Stage>
      <Sfx at={at(23)} type="pop" vol={0.8} />
      <Sfx at={at(23) + 30} type="pop" rate={0.92} vol={0.8} />
      <Sfx at={at(24)} type="thud" vol={0.7} />
    </>
  );
};

// ১১ — আরিফ কি খারাপ ছেলে? না। (cue 25–28)
export const NotBad: React.FC = () => {
  const {at} = useScene();
  const chain = useEase(at(28) + 14, 30, 'inOut');
  return (
    <>
      <BlurBG src="images/bed-phone.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(25) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/bed-phone.jpg" w={640} h={620} pos="55% 45%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Words text="আরিফ কি খারাপ ছেলে?" delay={at(25)} per={5} size={80} weight={theme.weight.strong} color={theme.colors.textDim} />
            <Enter delay={at(26)} cfg="bouncy" from={0.4}><span style={{...H, fontSize: 200, color: theme.colors.hero, lineHeight: 1.1, textShadow: `0 0 50px ${theme.colors.heroGlow}`}}>না।</span></Enter>
            <Words text="সে শুধু একটা খেলা খেলছিল" delay={at(27)} per={5} size={70} />
            <Enter delay={at(28)} dir="up" cfg="bouncy"><Card dark style={{display: 'flex', alignItems: 'center', gap: 26, padding: '24px 40px', boxShadow: warn}}><Lock size={80} fill={theme.colors.onHero} color={theme.colors.onHero} /><span style={{...H, fontSize: 58, lineHeight: 1.3}}>কিন্তু খেলাটা তাকে ছাড়ছিল না</span></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(25)} type="pop" vol={0.7} />
      <Sfx at={at(26)} type="thud" vol={0.7} />
      <Sfx at={at(28)} type="whoosh" rate={0.9} vol={0.7} />
    </>
  );
};

// ১২ — গেম খারাপ নয়; সমস্যা: থামার সিদ্ধান্ত হাতে নেই (cue 29–31)
export const NotWrong: React.FC = () => {
  const {at, len} = useScene();
  const chips = ['বন্ধুদের সঙ্গে হাসি', 'টিমওয়ার্ক', 'জেতার আনন্দ'].map((t, i) => ({t, d: at(30) + Math.round((i * len(30)) / 3)}));
  const slide = useEase(at(31) + 14, 40, 'inOut');
  return (
    <>
      <BlurBG src="images/friends-bench.jpg" dim={0.65} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(29) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/friends-bench.jpg" w={640} h={700} pos="50% 40%" /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
            <Enter delay={at(29)} dir="down" dist={24}><Chip dark style={{fontSize: 44}}>গেম খেলা খারাপ কিছু নয়</Chip></Enter>
            {chips.map((c) => <Enter key={c.t} delay={c.d} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '16px 34px'}}><Check size={54} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 52}}>{c.t}</span></Card></Enter>)}
            <Enter delay={at(31)} dir="up" cfg="bouncy">
              <Card style={{padding: '26px 38px', marginTop: 12}}>
                <div style={{...H, fontWeight: theme.weight.strong, fontSize: 48, marginBottom: 16}}>থামার সিদ্ধান্ত</div>
                <div style={{position: 'relative', height: 34, borderRadius: 34, background: theme.colors.heroSoft}}>
                  <div style={{position: 'absolute', top: -10, left: `${interpolate(slide, [0, 1], [2, 84])}%`, width: 54, height: 54, borderRadius: '50%', background: slide > 0.6 ? theme.colors.accent : theme.colors.hero, boxShadow: glow}} />
                </div>
                <div style={{display: 'flex', justifyContent: 'space-between', marginTop: 14, ...H, fontWeight: theme.weight.strong, fontSize: 38, color: theme.colors.textDim}}><span>তোমার হাতে</span><span>আর নেই</span></div>
              </Card>
            </Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(29)} type="pop" vol={0.7} />
      {chips.map((c, i) => <Sfx key={c.t} at={c.d} type="pop" rate={1 + i * 0.06} vol={0.75} />)}
      <Sfx at={at(31) + 14} type="whoosh" rate={0.9} vol={0.7} />
    </>
  );
};

// ১৩ — ইচ্ছাশক্তি নয়, ডিজাইন (cue 32–33)
export const Design: React.FC = () => {
  const {at, len} = useScene();
  const a = useEase(at(33) + 6, 50, 'out'), b = useEase(at(33) + 20, 60, 'out');
  return (
    <Stage style={C}>
      <Enter delay={at(32)} dir="left" dist={60}><div style={{...H, fontSize: 90, color: theme.colors.textDim}}>শুধু <Struck delay={at(32) + 28}>ইচ্ছাশক্তির</Struck> ব্যাপার নয়</div></Enter>
      <Enter delay={at(33)} dir="up" cfg="bouncy" style={{marginTop: 50}}>
        <Card dark style={{padding: '44px 56px', boxShadow: glow}}>
          <div style={{display: 'flex', flexDirection: 'column', gap: 34}}>
            <div><div style={{...H, fontSize: 56, marginBottom: 14}}>খেলতে ভালো লাগা</div><div style={{height: 36, borderRadius: 36, background: 'rgba(11,11,13,0.3)'}}><div style={{width: `${a * 88}%`, height: '100%', borderRadius: 36, background: theme.colors.onHero}} /></div></div>
            <div><div style={{...H, fontSize: 56, marginBottom: 14}}>বারবার ফিরে আসার টান</div><div style={{height: 36, borderRadius: 36, background: 'rgba(11,11,13,0.3)'}}><div style={{width: `${b * 94}%`, height: '100%', borderRadius: 36, background: theme.colors.accent}} /></div></div>
          </div>
        </Card>
      </Enter>
      <Enter delay={at(33) + 50} dir="up" style={{marginTop: 34, alignSelf: 'flex-start'}}><Chip style={{fontSize: 46}}>এমনভাবেই বানানো</Chip></Enter>
      <Sfx at={at(32)} type="pop" />
      <Sfx at={at(32) + 28} type="click" />
      <Sfx at={at(33)} type="whoosh" vol={0.7} />
    </Stage>
  );
};

// ১৪ — রিওয়ার্ড-চক্র: Hub/Process loop (cue 34–35)
export const RewardLoop: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const cx = 960, cy = 540, rx = 560, ry = 300;
  const t3 = (i: number) => at(34) + Math.round((i * len(34)) / 3);
  const nodes = [{t: 'ম্যাচের পর রিওয়ার্ড', x: cx, y: cy - ry, d: t3(0)}, {t: 'র‍্যাঙ্কের সিঁড়ি', x: cx + rx, y: cy, d: t3(1)}, {t: 'লগইন বোনাস', x: cx, y: cy + ry, d: t3(2)}, {t: 'শোধ না তুলে উঠবো কীভাবে?', x: cx - rx, y: cy, d: at(35)}];
  const ring = `M${cx} ${cy - ry} A${rx} ${ry} 0 0 1 ${cx + rx} ${cy} A${rx} ${ry} 0 0 1 ${cx} ${cy + ry} A${rx} ${ry} 0 0 1 ${cx - rx} ${cy} A${rx} ${ry} 0 0 1 ${cx} ${cy - ry}`;
  const ang = (f / 70) * Math.PI * 2 - Math.PI / 2;
  return (
    <Stage pad={0}>
      <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
        <DrawPath d={ring} delay={at(34)} dur={Math.max(60, len(34, 35) - 10)} color={theme.colors.line} width={10} />
        <circle cx={cx + Math.cos(ang) * rx} cy={cy + Math.sin(ang) * ry} r={15} fill={theme.colors.hero} opacity={useEase(at(35), 10)} />
      </svg>
      {nodes.map((n, i) => (
        <div key={n.t} style={{position: 'absolute', left: n.x - 210, top: n.y - 62, width: 420}}>
          <Enter delay={n.d} cfg="bouncy" from={0.8}><Card dark={i === 3} style={{height: 124, padding: '0 22px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: i === 3 ? warn : theme.shadow}}><span style={{...H, fontSize: i === 3 ? 42 : 46, textAlign: 'center', lineHeight: 1.25}}>{n.t}</span></Card></Enter>
        </div>
      ))}
      <div style={{position: 'absolute', left: 0, right: 0, top: cy - 70, display: 'flex', justifyContent: 'center'}}><Words text="*ফিরে আসা*" delay={at(35) + 10} per={8} size={130} align="center" /></div>
      {nodes.map((n, i) => <Sfx key={n.t} at={n.d} type="pop" rate={1 + i * 0.05} vol={0.75} />)}
      <Sfx at={at(35) + 10} type="chime" vol={0.8} />
    </Stage>
  );
};

// ১৫ — স্কোয়াড লবি: "তুই না থাকলে অসম্পূর্ণ" (cue 36–38)
export const Squad: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const pulse = 0.6 + Math.sin(f / 6) * 0.4;
  return (
    <Stage style={C}>
      <Enter delay={at(36)} dir="down" dist={24}><Chip dark>স্কোয়াড</Chip></Enter>
      <div style={{display: 'flex', gap: 34, marginTop: 36}}>
        {[0, 1, 2, 3].map((i) => (
          <Enter key={i} delay={at(36) + 8 + i * 8} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card dark={i === 3} style={{height: 340, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, boxShadow: i === 3 ? `0 0 ${50 + pulse * 70}px ${theme.colors.heroGlow}` : theme.shadow, borderStyle: i === 3 ? 'dashed' : 'solid'}}>
              <Person size={150} fill={i === 3 ? 'transparent' : theme.colors.heroSoft} color={i === 3 ? theme.colors.onHero : theme.colors.text} />
              <span style={{...H, fontSize: 54}}>{i === 3 ? 'তুমি?' : 'বন্ধু'}</span>
            </Card>
          </Enter>
        ))}
      </div>
      <Enter delay={at(37)} dir="up" cfg="bouncy" style={{marginTop: 40, alignSelf: 'center'}}><Card style={{padding: '24px 56px', borderRadius: 60}}><span style={{...H, fontSize: 66}}>“তুই না থাকলে স্কোয়াড অসম্পূর্ণ”</span></Card></Enter>
      <Enter delay={at(38)} dir="up" style={{marginTop: 28, alignSelf: 'center'}}><Chip style={{fontSize: 48}}>থামা আরও কঠিন হয়ে যায়</Chip></Enter>
      <Sfx at={at(36) + 8} type="pop" vol={0.7} />
      <Sfx at={at(36) + 32} type="pop" rate={1.1} />
      <Sfx at={at(37)} type="whoosh" vol={0.7} />
      <Sfx at={at(38)} type="thud" vol={0.6} />
    </Stage>
  );
};

// ১৬ — নিজেকে দুর্বল ভেবো না (cue 39–40)
export const NotWeak: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Enter delay={at(39)} dir="left" dist={70}><Card style={{display: 'flex', alignItems: 'center', gap: 40, padding: '38px 60px'}}><Cross size={90} color={theme.colors.accent} /><span style={{...H, fontSize: 100, color: theme.colors.textDim}}><Struck delay={at(39) + 36}>নিজেকে দুর্বল ভাবা</Struck></span></Card></Enter>
      <Enter delay={at(40)} dir="right" dist={70} cfg="bouncy" style={{marginTop: 46}}>
        <Card dark style={{display: 'flex', alignItems: 'center', gap: 40, padding: '48px 60px', boxShadow: glow}}><Shield size={140} fill={theme.colors.onHero} color={theme.colors.onHero} /><div><div style={{...H, fontSize: 80, lineHeight: 1.3}}>তোমাকে ধরে রাখার জন্যই সাজানো</div><div style={{...H, fontWeight: theme.weight.strong, fontSize: 52, marginTop: 8, opacity: 0.85}}>এমন কিছুর সঙ্গে তুমি লড়ছ</div></div></Card>
      </Enter>
      <Sfx at={at(39)} type="pop" />
      <Sfx at={at(39) + 36} type="click" />
      <Sfx at={at(40)} type="chime" />
    </Stage>
  );
};
