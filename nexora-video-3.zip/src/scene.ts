import React, {createContext, useContext} from 'react';
import {LEAD, TRANS, cueEnd, cueStart} from './timing';

export type SceneInfo = {start: number; dur: number; from: number; to: number};

export const SceneCtx = createContext<SceneInfo>({start: 0, dur: 1, from: 1, to: 1});

// সিনের ভেতরের সময় সবসময় SRT cue থেকে আসে (LEAD ফ্রেম আগে)।
export const useScene = () => {
  const info = useContext(SceneCtx);
  const at = (n: number, extra = 0) => Math.max(0, cueStart(n) - LEAD - info.start) + extra;
  const len = (n: number, m = n) => cueEnd(m) - cueStart(n);
  return {...info, at, len};
};

// gapFrom: SRT-এ cue-র মাঝে লম্বা ফাঁক থাকলে সেই ফাঁকের জন্য আলাদা "শ্বাস" সিন (শুরু = ওই cue-র শেষ)
export type SceneDef = {id: string; from: number; to: number; C: React.FC; gapFrom?: number};

export const sceneStarts = (defs: SceneDef[]) =>
  defs.map((s, i) => (i === 0 ? 0 : s.gapFrom !== undefined ? cueEnd(s.gapFrom) : Math.max(0, cueStart(s.from) - LEAD)));
export const sceneDurs = (starts: number[], total: number) =>
  starts.map((st, i) => (i === starts.length - 1 ? total - st : starts[i + 1] - st + TRANS));
