// theme.ts — রং, ইজিং, spring প্রিসেট ও ফন্টের একমাত্র উৎস। কম্পোনেন্টে সরাসরি হেক্স নয়।
import {Easing} from 'remotion';

export const theme = {
  colors: {
    // স্কিম ১ — Nexora Gold Night
    bg: '#07080C',
    bgAlt: '#0E1018',
    hero: '#F2B84B', // হিরো সোনালি (প্রতি ফ্রেমে সর্বোচ্চ একটি জোরালো উপাদান)
    accent: '#FFD98A',
    text: '#F5EFE3',
    textDim: 'rgba(245,239,227,0.66)',
    textFaint: 'rgba(245,239,227,0.28)',
    onHero: '#07080C',
    card: 'rgba(24,26,36,0.84)',
    cardSolid: '#14161E',
    line: 'rgba(245,239,227,0.14)',
    accentSoft: 'rgba(255,217,138,0.30)',
    accentGlow: 'rgba(255,217,138,0.40)',
    heroSoft: 'rgba(242,184,75,0.16)',
    heroGlow: 'rgba(242,184,75,0.45)',
    vignette: 'rgba(0,0,0,0.6)',
    shadow: 'rgba(0,0,0,0.65)',
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
    body: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
  },
  weight: {hero: 700, strong: 600, body: 500},
  size: {h1: 148, h2: 108, h3: 76, body: 54, label: 38, small: 30},
  radius: 36,
  shadow: '0 36px 70px -26px rgba(0,0,0,0.8), 0 6px 18px -8px rgba(0,0,0,0.55)',
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;
