import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from '../components/Ui';
import {DrawPath, Enter, Struck, Words, clamp01, useEase, useSpring} from '../components/Motion';
import {Book, Check, Cross, Door, Flag, Heart, Key, Lock, Person, Repeat, Shield, Sparkle, Sun} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {C, H, PhotoBG, glow} from '../components/Kit';

// ৩৭ — শৃঙ্খলা মানে ফিরে আসতে শেখা (cue 89–91)
export const Again: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const pts = [[60, 120], [260, 150], [440, 280], [560, 140], [740, 90], [900, 240], [1040, 90], [1200, 40]];
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ');
  const t = useEase(at(90) + 10, len(90, 91) - 20, 'inOut');
  const idx = Math.min(pts.length - 2, Math.floor(t * (pts.length - 1)));
  const lt = t * (pts.length - 1) - idx;
  const px = pts[idx][0] + (pts[idx + 1][0] - pts[idx][0]) * lt, py = pts[idx][1] + (pts[idx + 1][1] - pts[idx][1]) * lt;
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
          <Enter delay={at(89)} dir="down" dist={24}><Chip dark>তারপর আবার শুরু করো</Chip></Enter>
          <Enter delay={at(90)} dir="left" dist={50}><div style={{...H, fontSize: 70, color: theme.colors.textDim}}>শৃঙ্খলা মানে <Struck delay={at(90) + 30}>কখনো না থামা</Struck></div></Enter>
          <Enter delay={at(91)} dir="right" dist={50} cfg="bouncy"><Card dark style={{display: 'flex', alignItems: 'center', gap: 26, padding: '30px 44px', boxShadow: glow}}><Repeat size={90} color={theme.colors.onHero} /><span style={{...H, fontSize: 64, lineHeight: 1.35}}>থেমে গেলে আবার নিজের পথে ফিরে আসতে শেখা</span></Card></Enter>
          <Enter delay={at(90) + 10} dir="up"><Card style={{padding: 22}}>
            <svg width={920} height={260} viewBox="0 0 1260 300" style={{overflow: 'visible'}}>
              <DrawPath d={d} delay={at(90) + 10} dur={len(90, 91) - 20} color={theme.colors.text} width={10} />
              <circle cx={px} cy={py} r={20 + Math.sin(f / 5) * 2} fill={theme.colors.hero} opacity={clamp01(t * 30)} />
            </svg></Card></Enter>
        </div>
        <Enter delay={at(89) - 4} dir="left" dist={80} style={{width: 640, height: 820, flexShrink: 0}}>
          <Photo src="images/sunrise-path.jpg" w={640} h={820} pos="48% 50%" />
        </Enter>
      </div>
      <Sfx at={at(89)} type="pop" vol={0.7} />
      <Sfx at={at(90) + 30} type="click" />
      <Sfx at={at(91)} type="chime" />
    </Stage>
  );
};

// ৩৮ — সফলতার নতুন সংজ্ঞা (cue 92–94)
export const Success: React.FC = () => {
  const {at} = useScene();
  const pillars = [{t: 'নিজের সম্ভাবনা কাজে লাগানো', h: 300, d: at(93), icon: <Sparkle size={80} />}, {t: 'নিজের দায়িত্ব পালন', h: 380, d: at(93) + 40, icon: <Flag size={80} />}, {t: 'নিজের কাছে সৎ থাকা', h: 460, d: at(94), icon: <Shield size={84} fill={theme.colors.hero} />}];
  return (
    <Stage style={C}>
      <Enter delay={at(92)} dir="left" dist={60}>
        <div style={{...H, fontSize: 80, color: theme.colors.textDim}}>সফলতা মানে <Struck delay={at(92) + 30}>সবাইকে হারিয়ে দেওয়া</Struck> নয়</div>
      </Enter>
      <div style={{display: 'flex', alignItems: 'flex-end', gap: 36, marginTop: 56, height: 520}}>
        {pillars.map((p, i) => {
          const g = useSpring(p.d, 'smooth');
          return (
            <div key={p.t} style={{flex: 1, height: p.h * g, opacity: clamp01(g * 2)}}>
              <Card dark={i === 2} style={{height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20, textAlign: 'center', boxShadow: i === 2 ? glow : theme.shadow}}>
                {p.icon}<span style={{...H, fontWeight: theme.weight.strong, fontSize: 50, lineHeight: 1.35}}>{p.t}</span>
              </Card>
            </div>
          );
        })}
      </div>
      <Sfx at={at(92)} type="pop" vol={0.7} />
      <Sfx at={at(92) + 30} type="click" />
      {pillars.map((p, i) => <Sfx key={p.t} at={p.d} type="pop" rate={0.95 + i * 0.06} vol={0.75} />)}
    </Stage>
  );
};

// ৩৯ — শুরু হাতে ছিল না, গন্তব্য এখনো হাতে (cue 95–96)
export const Hands: React.FC = () => {
  const {at} = useScene();
  const open = useEase(at(96) + 20, 30, 'inOut');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 60}}>
        <Enter delay={at(95)} dir="right" dist={60} style={{flex: 1}}>
          <Card style={{height: 520, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28, opacity: 0.88}}>
            <Lock size={190} /><span style={{...H, fontSize: 70, color: theme.colors.textDim, textAlign: 'center', lineHeight: 1.3}}>কোথা থেকে শুরু</span><Chip>হাতে ছিল না</Chip>
          </Card>
        </Enter>
        <Enter delay={at(96)} dir="left" dist={60} cfg="bouncy" style={{flex: 1}}>
          <Card dark style={{height: 520, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28, boxShadow: glow}}>
            <Lock size={190} open={open > 0.5} fill={theme.colors.bg} color={theme.colors.onHero} /><span style={{...H, fontSize: 70, textAlign: 'center', lineHeight: 1.3}}>কোথায় যাবে</span><Chip style={{background: 'rgba(7,8,12,0.18)', color: theme.colors.onHero}}>অনেকটা তোমার হাতে</Chip>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(95)} type="pop" vol={0.8} />
      <Sfx at={at(96)} type="whoosh" vol={0.7} />
      <Sfx at={at(96) + 24} type="chime" />
    </Stage>
  );
};

// ৪০ — অতীত একটা অংশ, ভবিষ্যতের পৃষ্ঠা এখনো লেখা হয়নি (cue 97–98)
export const BookScene: React.FC = () => {
  const {at, len} = useScene();
  const write = useEase(at(98) + 20, Math.max(40, len(98) - 30), 'inOut');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 0, alignSelf: 'center'}}>
        <Enter delay={at(97)} dir="right" dist={50}>
          <Card style={{width: 700, height: 600, borderRadius: '40px 8px 8px 40px', display: 'flex', flexDirection: 'column', gap: 24, padding: '56px 60px'}}>
            <Chip>অতীত</Chip>
            {[90, 70, 85, 60, 78, 50].map((w, i) => <div key={i} style={{height: 16, borderRadius: 8, background: theme.colors.line, width: `${w}%`}} />)}
            <span style={{...H, fontWeight: theme.weight.strong, fontSize: 52, marginTop: 'auto'}}>গল্পের একটা অংশ</span>
          </Card>
        </Enter>
        <Enter delay={at(98)} dir="left" dist={50}>
          <Card dark style={{width: 700, height: 600, borderRadius: '8px 40px 40px 8px', display: 'flex', flexDirection: 'column', gap: 24, padding: '56px 60px', boxShadow: glow}}>
            <Chip style={{background: 'rgba(7,8,12,0.18)', color: theme.colors.onHero}}>ভবিষ্যৎ</Chip>
            <div style={{height: 16, borderRadius: 8, background: 'rgba(7,8,12,0.35)', width: `${write * 60}%`}} />
            <span style={{...H, fontSize: 56, marginTop: 'auto', lineHeight: 1.35}}>প্রতিটি পৃষ্ঠা এখনো লেখা হয়নি</span>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(97)} type="pop" vol={0.8} />
      <Sfx at={at(98)} type="whoosh" rate={1.05} vol={0.7} />
      <Sfx at={at(98) + 24} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৪১ — হয়তো জীবন কঠিন, কেউ বুঝছে না, ফল পাওনি (cue 99–101)
export const HardNow: React.FC = () => {
  const {at} = useScene();
  const lines = [{t: 'হয়তো এখন জীবন কঠিন', d: at(99)}, {t: 'হয়তো কেউ তোমার সংগ্রামটা বুঝতে পারছে না', d: at(100)}, {t: 'হয়তো অনেকদিন চেষ্টা করেও ফল পাওনি', d: at(101)}];
  return (
    <PhotoBG src="images/dark-laptop.jpg" pos="60% 50%" side="left" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 30, width: 1050}}>
          {lines.map((l) => <Words key={l.t} text={l.t} delay={l.d} per={4} size={74} weight={theme.weight.strong} />)}
        </div>
      </Stage>
      {lines.map((l) => <Sfx key={l.t} at={l.d} type="pop" vol={0.55} />)}
    </PhotoBG>
  );
};

// ৪২ — আমি বলব না সব সহজ হবে (cue 102–103)
export const Honest: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Enter delay={at(102)} dir="down" dist={24}><Chip dark>আমি তোমাকে বলব না</Chip></Enter>
      <div style={{display: 'flex', flexDirection: 'column', gap: 30, marginTop: 40}}>
        <Enter delay={at(102) + 8} dir="left" dist={70}><Card style={{display: 'flex', alignItems: 'center', gap: 36, padding: '36px 56px'}}><Cross size={80} /><span style={{...H, fontSize: 80, color: theme.colors.textDim}}><Struck delay={at(102) + 44}>সবকিছু সহজ হয়ে যাবে</Struck></span></Card></Enter>
        <Enter delay={at(103)} dir="right" dist={70}><Card style={{display: 'flex', alignItems: 'center', gap: 36, padding: '36px 56px'}}><Cross size={80} /><span style={{...H, fontSize: 70, color: theme.colors.textDim, lineHeight: 1.35}}><Struck delay={at(103) + 44}>শুধু ইচ্ছাশক্তিতেই সব সমস্যার সমাধান</Struck></span></Card></Enter>
      </div>
      <Sfx at={at(102)} type="pop" vol={0.7} />
      <Sfx at={at(102) + 44} type="click" />
      <Sfx at={at(103) + 44} type="click" rate={0.92} />
    </Stage>
  );
};

// ৪৩ — তোমার হাতে এখনো যা আছে (cue 104–108)
export const InHand: React.FC = () => {
  const {at} = useScene();
  const items = [{t: 'কিছু সিদ্ধান্ত', d: at(105), icon: <Check size={70} />}, {t: 'কিছু অভ্যাস বদলানোর সুযোগ', d: at(106), icon: <Repeat size={74} />}, {t: 'কিছু নতুন দক্ষতা শেখার সুযোগ', d: at(107), icon: <Book size={80} />}, {t: 'আজকের দিনটাকে ভালোভাবে ব্যবহার', d: at(108), icon: <Sun size={82} />}];
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <div style={{width: 640, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 30}}>
          <Enter delay={at(104)} dir="down" dist={24}><Chip dark>একটা কথা মনে করিয়ে দিই</Chip></Enter>
          <Words text="তোমার হাতে এখনো *আছে*" delay={at(104) + 6} per={6} size={104} />
        </div>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
          {items.map((it, i) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}><Card dark={i === 3} style={{display: 'flex', alignItems: 'center', gap: 30, padding: '24px 42px', boxShadow: i === 3 ? glow : theme.shadow}}>{it.icon}<span style={{...H, fontWeight: theme.weight.strong, fontSize: 58}}>{it.t}</span></Card></Enter>
          ))}
        </div>
      </div>
      <Sfx at={at(104)} type="pop" vol={0.7} />
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 + i * 0.05} vol={0.75} />)}
    </Stage>
  );
};

// ৪৪ — মনের ভার একা বইতে না পারলে কথা বলো (cue 109–110)
export const Support: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Words text="মনের ভার একা বইতে না পারলে" delay={at(109)} per={5} size={84} weight={theme.weight.strong} />
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 50, marginTop: 56}}>
        <Enter delay={at(109) + 40} dir="right" dist={60}><Card style={{width: 560, height: 380, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22}}><Person size={160} fill={theme.colors.heroSoft} /><span style={{...H, fontSize: 66}}>বিশ্বস্ত মানুষ</span></Card></Enter>
        <Enter delay={at(109) + 56} cfg="bouncy" from={0.4}><Heart size={110} /></Enter>
        <Enter delay={at(109) + 70} dir="left" dist={60}><Card dark style={{width: 560, height: 380, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, boxShadow: glow}}><Person size={160} fill={theme.colors.onHero} color={theme.colors.onHero} /><span style={{...H, fontSize: 66}}>বিশেষজ্ঞ</span></Card></Enter>
      </div>
      <Enter delay={at(110)} dir="up" cfg="bouncy" style={{marginTop: 44, alignSelf: 'center'}}><Chip style={{fontSize: 56, padding: '14px 52px'}}>সেটা হার মানা নয়</Chip></Enter>
      <Sfx at={at(109) + 40} type="pop" vol={0.7} />
      <Sfx at={at(109) + 70} type="pop" rate={1.06} vol={0.7} />
      <Sfx at={at(110)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৪৫ — নিজেকে আরেকটা সুযোগ দাও (cue 111–114)
export const Chance: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/sunrise-path.jpg" pos="50% 55%" side="left">
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 30, width: 1100}}>
          <Words text="নিজেকে আরেকটা *সুযোগ* দাও" delay={at(111)} per={6} size={100} />
          <Enter delay={at(112)} dir="left" dist={50}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 66, color: theme.colors.textDim}}>আজই <Struck delay={at(112) + 26}>সফল হতে হবে</Struck> না</div></Enter>
          <Enter delay={at(113)} dir="left" dist={50}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 66, color: theme.colors.textDim}}>আজই <Struck delay={at(113) + 26}>প্রমাণ করতে হবে</Struck> না</div></Enter>
          <Enter delay={at(114)} dir="up" cfg="bouncy"><Card dark style={{padding: '26px 46px', alignSelf: 'flex-start', boxShadow: glow}}><span style={{...H, fontSize: 66}}>হাল ছেড়ে দিও না</span></Card></Enter>
        </div>
      </Stage>
      <Sfx at={at(111)} type="whoosh" rate={0.95} vol={0.7} />
      <Sfx at={at(112) + 26} type="click" />
      <Sfx at={at(113) + 26} type="click" rate={0.93} />
      <Sfx at={at(114)} type="chime" vol={0.8} />
    </PhotoBG>
  );
};

// ৪৬ — পাঁচ বছর পরের উত্তর আজ রাতের সিদ্ধান্তে (cue 115)
export const FiveYears: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const t = useEase(at(115) + 20, len(115) - 40, 'inOut');
  return (
    <Stage style={C}>
      <Words text="পাঁচ বছর পর তুমি কোথায় থাকবে?" delay={at(115)} per={4} size={80} weight={theme.weight.strong} color={theme.colors.textDim} />
      <Enter delay={at(115) + 16} dir="up" style={{marginTop: 50}}>
        <Card style={{padding: '40px 50px'}}>
          <svg width={1560} height={340} viewBox="0 0 1560 340" style={{overflow: 'visible'}}>
            <DrawPath d="M80 270 C 500 270, 700 230, 1000 150 S 1380 70, 1480 60" delay={at(115) + 20} dur={len(115) - 40} color={theme.colors.text} width={10} />
            <circle cx={80} cy={270} r={26} fill={theme.colors.hero} />
            <circle cx={1480} cy={60} r={20 + t * 60} fill={theme.colors.hero} opacity={0.25 + t * 0.6} />
          </svg>
        </Card>
      </Enter>
      <div style={{display: 'flex', gap: 40, marginTop: 36, alignItems: 'center'}}>
        <Enter delay={at(115) + 40} dir="up"><Chip dark style={{fontSize: 52}}>আজ রাতের একটা ছোট সিদ্ধান্ত</Chip></Enter>
        <Enter delay={at(115) + 90} dir="up" cfg="bouncy"><Chip style={{fontSize: 52}}>উত্তর লুকিয়ে আছে এখানেই</Chip></Enter>
      </div>
      <Sfx at={at(115)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(115) + 40} type="pop" />
      <Sfx at={at(115) + 90} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৪৭ — কেউ আসবে না আর ভয়ের নয়, চাবি তোমার হাতে (cue 116–117)
export const KeyScene: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const open = useEase(at(117) + 24, 40, 'inOut');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Enter delay={at(116)} dir="left" dist={50}><div style={{...H, fontSize: 76, lineHeight: 1.3, color: theme.colors.textDim}}>“কেউ আসবে না” — <Struck delay={at(116) + 36}>ভয়ের</Struck> নয়</div></Enter>
          <Enter delay={at(117)} dir="up" cfg="bouncy"><Card dark style={{padding: '36px 50px', boxShadow: glow}}><span style={{...H, fontSize: 80, lineHeight: 1.3}}>জীবনের চাবিটা এখনো তোমার হাতে</span></Card></Enter>
        </div>
        <div style={{position: 'relative', width: 640, height: 640, flexShrink: 0}}>
          <Enter delay={at(116)} cfg="bouncy" from={0.6}><div style={{position: 'absolute', left: 80, top: 0}}><Door size={460} open={open} /></div></Enter>
          <Enter delay={at(117) + 10} cfg="bouncy" from={0.4}><div style={{position: 'absolute', left: 190 + Math.sin(f / 14) * 6, top: 380, filter: `drop-shadow(0 0 30px ${theme.colors.heroGlow})`}}><Key size={300} /></div></Enter>
        </div>
      </div>
      <Sfx at={at(116)} type="pop" vol={0.7} />
      <Sfx at={at(116) + 36} type="click" />
      <Sfx at={at(117)} type="chime" />
      <Sfx at={at(117) + 24} type="whoosh" rate={0.9} vol={0.6} />
    </Stage>
  );
};

// ৪৮ — একটা ছোট কাজ বেছে নাও, প্রথম পদক্ষেপ (cue 118)
export const Pick: React.FC = () => {
  const {at, len} = useScene();
  const tick = useSpring(at(118) + Math.round(len(118) * 0.6), 'bouncy');
  return (
    <Stage style={C}>
      <Words text="একটা *ছোট কাজ* বেছে নাও" delay={at(118)} per={6} size={104} />
      <Enter delay={at(118) + 30} dir="up" cfg="bouncy" style={{marginTop: 50}}>
        <Card dark style={{display: 'flex', alignItems: 'center', gap: 44, padding: '50px 64px', boxShadow: glow}}>
          <div style={{width: 130, height: 130, borderRadius: 38, border: `7px solid ${theme.colors.onHero}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0}}><div style={{transform: `scale(${tick})`, opacity: clamp01(tick)}}><Check size={90} color={theme.colors.onHero} /></div></div>
          <div><div style={{...H, fontSize: 76, lineHeight: 1.3}}>অনেকদিন ধরে পিছিয়ে দিচ্ছ</div><div style={{...H, fontWeight: theme.weight.strong, fontSize: 56, marginTop: 8, opacity: 0.8}}>আজই তার প্রথম পদক্ষেপটা নাও</div></div>
        </Card>
      </Enter>
      <Sfx at={at(118)} type="whoosh" vol={0.7} />
      <Sfx at={at(118) + 30} type="pop" />
      <Sfx at={at(118) + Math.round(len(118) * 0.6)} type="click" />
    </Stage>
  );
};

// ৪৯ — কমেন্ট বক্স (টাইপরাইটার শুধু ইনপুট UI-তে) (cue 119–120)
export const CommentBox: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const words = 'কোন কাজটা বেছে নিলে?'.split(' ');
  const start = at(119) + 30, per = Math.max(6, Math.floor((len(119) - 20) / words.length));
  const shown = Math.max(0, Math.min(words.length, Math.floor((f - start) / per) + 1));
  const press = useEase(at(120) + 40, 10, 'out');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(120)} dir="down" dist={24}><Chip dark>নিচের কমেন্টে</Chip></Enter>
        <Words text="লিখে *জানাও*" delay={at(120) + 6} per={7} size={92} />
      </div>
      <Enter delay={at(119)} dir="up" cfg="bouncy" style={{marginTop: 46}}>
        <Card style={{padding: '40px 44px'}}>
          <div style={{display: 'flex', gap: 34, alignItems: 'flex-start'}}>
            <div style={{width: 100, height: 100, borderRadius: '50%', background: theme.colors.hero, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Person size={64} color={theme.colors.onHero} fill="transparent" /></div>
            <div style={{flex: 1, minHeight: 170, borderRadius: 28, border: `3px solid ${theme.colors.line}`, background: theme.colors.bgAlt, padding: '26px 36px', ...H, fontWeight: theme.weight.strong, fontSize: 66, lineHeight: 1.5}}>
              {words.slice(0, shown).join(' ')}
              <span style={{display: 'inline-block', width: 5, height: 68, background: theme.colors.hero, marginLeft: 8, verticalAlign: 'middle', opacity: f % 30 < 18 ? 1 : 0}} />
            </div>
          </div>
          <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: 24}}>
            <div style={{...H, fontSize: 46, padding: '12px 46px', borderRadius: 999, background: theme.colors.hero, color: theme.colors.onHero, transform: `scale(${1 - 0.06 * Math.sin(press * Math.PI)})`, boxShadow: press > 0.5 ? glow : 'none'}}>পাঠাও</div>
          </div>
        </Card>
      </Enter>
      <Sfx at={at(119)} type="whoosh" rate={1.05} vol={0.7} />
      <Sfx at={at(120)} type="pop" />
      <Sfx at={at(120) + 40} type="click" />
    </Stage>
  );
};

// ৫০ — তোমার নতুন শুরুটা আজই হোক (cue 121)
export const NewStart: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/road-sunrise.jpg" pos="50% 55%" side="full" zoomOut>
      <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
        <Words text="তোমার *নতুন শুরুটা* আজই হোক" delay={at(121)} per={6} size={128} align="center" />
      </Stage>
      <Sfx at={at(121)} type="whoosh" rate={0.9} />
      <Sfx at={at(121) + 40} type="chime" />
    </PhotoBG>
  );
};

// ৫১ — সমাপ্তি: লোগো ও ট্যাগলাইন (cue 122)
export const End: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const glw = 0.75 + Math.sin(f / 18) * 0.25;
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
        <Enter delay={at(122)} cfg="bouncy" from={0.55} float={4}>
          <div style={{width: 600, height: 600, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 0 ${150 * glw}px ${theme.colors.heroGlow}, ${theme.shadow}`}}>
            <Img src={staticFile('logo.png')} style={{width: '100%', height: '100%', objectFit: 'cover'}} />
          </div>
        </Enter>
        <Words text="Better Mind, Bigger Life." delay={at(122) + 22} per={7} size={104} align="center" />
      </div>
      <Sfx at={at(122)} type="chime" />
      <Sfx at={at(122) + 22} type="pop" vol={0.7} />
    </Stage>
  );
};
