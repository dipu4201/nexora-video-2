import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from '../components/Ui';
import {Counter, DrawPath, Enter, MaskLine, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Battery, Check, ClockIcon, Cross, Door, Doc, Flag, Key, Lock, Mountain, Moon, Phone, Repeat, Sparkle, Heart, Person, Sun} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {C, H, PhotoBG, QuoteScene, glow} from '../components/Kit';

// ১ — হুক: পাঁচ বছর পরেও একই জায়গায় (cue 1–2)
export const Hook: React.FC = () => {
  const {at, len} = useScene();
  return (
    <PhotoBG src="images/dark-laptop.jpg" pos="60% 50%" side="left">
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 30, width: 1100}}>
          <Words text="পাঁচ বছর পরেও" delay={at(1)} per={7} size={120} weight={theme.weight.strong} color={theme.colors.textDim} />
          <Words text="*ঠিক এই জায়গায়?*" delay={at(2)} per={8} size={170} />
          <div style={{display: 'flex', gap: 22, marginTop: 20}}>
            {[0, 1, 2, 3, 4].map((i) => (
              <Enter key={i} delay={at(1) + 14 + Math.round((i * (len(1, 2) - 20)) / 5)} cfg="bouncy" from={0.4}>
                <div style={{width: 74, height: 74, borderRadius: '50%', border: `4px solid ${theme.colors.hero}`, background: theme.colors.heroSoft}} />
              </Enter>
            ))}
          </div>
        </div>
      </Stage>
      <Sfx at={at(1)} type="thud" vol={0.7} />
      <Sfx at={at(2)} type="whoosh" rate={0.9} />
    </PhotoBG>
  );
};

// ২ — একই স্বপ্ন, একই অজুহাত, একই ক্লান্তি; "একদিন" আসে না (cue 3–5)
export const SameSame: React.FC = () => {
  const {at, len} = useScene();
  const items = ['স্বপ্ন', 'অজুহাত', 'ক্লান্তি'].map((t, i) => ({t, d: at(3) + Math.round((i * len(3)) / 3)}));
  const fade = useEase(at(5) + 20, 30, 'inOut');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 36}}>
        {items.map((it) => (
          <Enter key={it.t} delay={it.d} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card style={{height: 300, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16}}>
              <Chip>একই</Chip><span style={{...H, fontSize: 96}}>{it.t}</span>
            </Card>
          </Enter>
        ))}
      </div>
      <div style={{display: 'flex', alignItems: 'center', gap: 36, marginTop: 50}}>
        <Enter delay={at(4)} dir="right" dist={50}><Card dark style={{padding: '26px 46px', boxShadow: glow}}><span style={{...H, fontSize: 64}}>একদিন সব বদলে যাবে</span></Card></Enter>
        <Enter delay={at(5)} dir="left" dist={50}>
          <Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '22px 40px', opacity: 1 - fade * 0.55}}><ClockIcon size={80} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 58, color: theme.colors.textDim}}>সেই দিনটা আসছে না</span></Card>
        </Enter>
      </div>
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 - i * 0.05} vol={0.75} />)}
      <Sfx at={at(4)} type="whoosh" vol={0.7} />
      <Sfx at={at(5)} type="thud" vol={0.6} />
    </Stage>
  );
};

// ৩ — "জান কেন?" (cue 6)
export const JanKeno: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 70}}>
        <Words text="জান *কেন?*" delay={at(6)} per={9} size={230} />
        <Enter delay={at(6) + 14} cfg="bouncy" from={0.3}>
          <div style={{width: 300, height: 300, borderRadius: '50%', background: theme.colors.hero, boxShadow: glow, display: 'flex', alignItems: 'center', justifyContent: 'center', ...H, fontSize: 230, color: theme.colors.onHero, lineHeight: 1.2, transform: `scale(${1 + Math.sin(f / 9) * 0.03})`}}>?</div>
        </Enter>
      </div>
      <Sfx at={at(6)} type="whoosh" rate={0.9} />
      <Sfx at={at(6) + 14} type="pop" />
    </Stage>
  );
};

// ৪ — অপেক্ষা: ফোন কল, সুযোগ, একজন মানুষ (cue 7–9)
export const Waiting: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const items = [{t: 'একটা ফোন কল', d: at(7)}, {t: 'একটা সুযোগ', d: at(8)}, {t: 'এমন একজন মানুষ', d: at(8) + 40}];
  const ring = Math.sin(f * 1.2) * 6 * clamp01((f - at(7)) / 8);
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
          <Enter delay={at(7) - 4} dir="down" dist={24}><Chip dark>এখনো অপেক্ষা করছো</Chip></Enter>
          {items.map((it, i) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}>
              <Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '28px 44px'}}>
                {i === 0 ? <div style={{transform: `rotate(${ring}deg)`}}><Phone size={80} /></div> : i === 1 ? <Door size={80} /> : <Person size={80} fill={theme.colors.heroSoft} />}
                <span style={{...H, fontWeight: theme.weight.strong, fontSize: 64}}>{it.t}</span>
              </Card>
            </Enter>
          ))}
        </div>
        <Enter delay={at(9)} dir="left" dist={70} cfg="bouncy" style={{width: 800, flexShrink: 0}}>
          <Card dark style={{padding: '50px 54px', borderRadius: 56, boxShadow: glow}}>
            <Words text="“চলো, আমি তোমার জীবনটা *ঠিক করে দিচ্ছি।*”" delay={at(9) + 8} per={5} size={78} color={theme.colors.onHero} hlColor="rgba(7,8,12,0.22)" />
          </Card>
        </Enter>
      </div>
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 + i * 0.05} vol={0.75} />)}
      <Sfx at={at(9)} type="whoosh" rate={1.05} vol={0.8} />
    </Stage>
  );
};

// ৫ — কেউ আসবে না (cue 10–11)
export const Nobody: React.FC = () => {
  const {at} = useScene();
  const strike = at(11) + 40;
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <Enter delay={at(10)} dir="down" dist={24}><Chip dark>একটা কঠিন কথা</Chip></Enter>
      <div style={{display: 'flex', alignItems: 'center', gap: 70, marginTop: 40}}>
        <Enter delay={at(11) - 4} cfg="bouncy" from={0.6}><Door size={380} /></Enter>
        <MaskLine delay={at(11)}>
          <div style={{...H, fontSize: 210, color: theme.colors.text, lineHeight: 1.4}}>কেউ <span style={{color: theme.colors.hero}}>আসবে না।</span></div>
        </MaskLine>
      </div>
      <Sfx at={at(10)} type="pop" vol={0.7} />
      <Sfx at={at(11)} type="thud" />
    </Stage>
  );
};

// ৬ — নিষ্ঠুর কথার ভেতরে মুক্তি (cue 12)
export const Freedom: React.FC = () => {
  const {at, len} = useScene();
  const open = useEase(at(12) + Math.round(len(12) * 0.5), 40, 'inOut');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 100}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Enter delay={at(12)} dir="down" dist={24}><Chip>শেষ পর্যন্ত শোনো</Chip></Enter>
          <Words text="নিষ্ঠুর কথাটার ভেতরই লুকিয়ে আছে একটা *মুক্তি*" delay={at(12) + 6} per={5} size={100} />
        </div>
        <Enter delay={at(12) + 10} cfg="bouncy" from={0.6} style={{flexShrink: 0}}>
          <div style={{width: 520, height: 520, borderRadius: '50%', background: theme.colors.heroSoft, border: `2px solid ${theme.colors.line}`, boxShadow: `0 0 ${60 + open * 120}px ${theme.colors.heroGlow}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Lock size={300} open={open > 0.5} fill={theme.colors.cardSolid} />
          </div>
        </Enter>
      </div>
      <Sfx at={at(12)} type="pop" />
      <Sfx at={at(12) + Math.round(len(12) * 0.5) + 20} type="chime" />
    </Stage>
  );
};

// ৭ — আরিফের বয়স ২৪, রাত গভীর, ফোনের আলো (cue 13–15)
export const ArifIntro: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/bed-alarm.jpg" pos="55% 40%" side="right">
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', height: '100%', gap: 30, width: 900}}>
          <Enter delay={at(13)} dir="down" dist={30}>
            <Card dark style={{display: 'flex', alignItems: 'baseline', gap: 22, padding: '14px 48px', boxShadow: glow}}>
              <span style={{...H, fontSize: 70}}>আরিফের বয়স</span>
              <Counter from={0} to={24} delay={at(13) + 8} dur={34} style={{...H, fontSize: 170, lineHeight: 1.2}} />
            </Card>
          </Enter>
          <Words text="রাত গভীর।" delay={at(14)} per={8} size={120} />
          <Enter delay={at(15)} dir="up">
            <Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '22px 40px'}}><Phone size={72} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>ঘরে একটাই আলো, ফোনের স্ক্রিন</span></Card>
          </Enter>
        </div>
      </Stage>
      <Sfx at={at(13)} type="pop" />
      <Sfx at={at(14)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(15)} type="pop" rate={0.95} />
    </PhotoBG>
  );
};

// ৮ — ফোনের ফিডে সবাই এগোচ্ছে, আরিফ শুধু স্ক্রল (cue 16–18)
export const Feed: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const posts = [{t: 'নতুন চাকরি', d: at(16)}, {t: 'নতুন গাড়ি', d: at(17)}, {t: 'সাজানো জীবন', d: at(17) + Math.round(len(17) / 2)}];
  const scroll = (f - at(18)) * 1.4;
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 100}}>
        <Enter delay={at(16) - 4} dir="up" cfg="bouncy" style={{flexShrink: 0}}>
          <Card style={{width: 500, height: 860, padding: 20, borderRadius: 70, overflow: 'hidden', position: 'relative'}}>
            <div style={{position: 'absolute', left: 20, right: 20, top: 20 - Math.max(0, scroll), display: 'flex', flexDirection: 'column', gap: 24}}>
              {posts.concat(posts, posts).map((p, i) => (
                <div key={i} style={{height: 250, borderRadius: 36, background: i % 2 ? theme.colors.heroSoft : theme.colors.accentSoft, display: 'flex', alignItems: 'center', gap: 22, padding: 28, opacity: i < 3 ? clamp01((f - posts[i].d) / 10) : 1}}>
                  <div style={{width: 84, height: 84, borderRadius: '50%', background: theme.colors.hero, flexShrink: 0}} />
                  <div style={{flex: 1}}><div style={{height: 22, borderRadius: 11, background: theme.colors.line, width: '80%'}} /><div style={{height: 22, borderRadius: 11, background: theme.colors.line, width: '55%', marginTop: 18}} /></div>
                </div>
              ))}
            </div>
          </Card>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
          <Words text="সবাই *এগিয়ে* যাচ্ছে" delay={at(16)} per={6} size={96} />
          {posts.map((p) => (
            <Enter key={p.t} delay={p.d} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '20px 40px', alignSelf: 'flex-start'}}><Sparkle size={56} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>{p.t}</span></Card></Enter>
          ))}
          <Enter delay={at(18)} dir="up" cfg="bouncy"><Card dark style={{padding: '24px 46px', alignSelf: 'flex-start', boxShadow: glow}}><span style={{...H, fontSize: 64}}>আরিফ শুধু স্ক্রল করছে</span></Card></Enter>
        </div>
      </div>
      {posts.map((p, i) => <Sfx key={p.t} at={p.d} type="pop" rate={1 + i * 0.05} vol={0.7} />)}
      <Sfx at={at(18)} type="thud" vol={0.6} />
    </Stage>
  );
};

// ৯ — আরিফেরও স্বপ্ন ছিল (cue 19–20)
export const Dreams: React.FC = () => {
  const {at, len} = useScene();
  const items = [{t: 'নিজের পায়ে দাঁড়ানো', icon: <Flag size={70} />}, {t: 'পরিবারের মুখে হাসি', icon: <Heart size={70} />}, {t: 'ভয়হীন ভবিষ্যৎ', icon: <Sun size={74} />}].map((x, i) => ({...x, d: at(20) + 10 + Math.round((i * (len(20) - 20)) / 3)}));
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <Enter delay={at(19) - 4} dir="left" dist={80} style={{width: 760, height: 760, flexShrink: 0}}>
          <Photo src="images/road-sunrise.jpg" w={760} h={760} pos="50% 50%" />
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
          <Words text="আরিফেরও *স্বপ্ন* ছিল" delay={at(19)} per={7} size={100} />
          {items.map((it) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}>
              <Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '26px 42px'}}>{it.icon}<span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>{it.t}</span></Card>
            </Enter>
          ))}
        </div>
      </div>
      <Sfx at={at(19)} type="chime" vol={0.7} />
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 + i * 0.06} vol={0.75} />)}
    </Stage>
  );
};

// ১০ — "কাল থেকে" চক্র (cue 21–24)
export const Tomorrow: React.FC = () => {
  const {at, len} = useScene();
  const chips = ['শুরু করব', 'পড়ব', 'কাজ করব', 'নিজেকে বদলাবো'].map((t, i) => ({t, d: at(21) + 6 + Math.round((i * (len(21, 22) - 10)) / 4)}));
  const flip = useEase(at(23), 18, 'inOut');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
          {chips.map((c) => (
            <Enter key={c.t} delay={c.d} dir="right" dist={60}>
              <Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '24px 40px', alignSelf: 'flex-start'}}>
                <span style={{...H, fontSize: 60, color: theme.colors.hero}}>কাল থেকে</span><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>{c.t}</span>
              </Card>
            </Enter>
          ))}
        </div>
        <div style={{width: 640, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 34, flexShrink: 0}}>
          <Enter delay={at(23)} cfg="bouncy" from={0.5}>
            <Card style={{width: 480, height: 400, padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column', transform: `rotateX(${flip * 12}deg)`}}>
              <div style={{background: theme.colors.hero, color: theme.colors.onHero, ...H, fontSize: 100, textAlign: 'center', padding: '10px 0', lineHeight: 1.3}}>কাল</div>
              <div style={{flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', ...H, fontSize: 80, color: theme.colors.text}}>এল</div>
            </Card>
          </Enter>
          <Enter delay={at(24)} dir="up"><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '20px 40px'}}><Repeat size={70} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 52}}>আবার আগের মতোই</span></Card></Enter>
        </div>
      </div>
      {chips.map((c, i) => <Sfx key={c.t} at={c.d} type="pop" rate={1 + i * 0.05} vol={0.7} />)}
      <Sfx at={at(23)} type="thud" vol={0.7} />
      <Sfx at={at(24)} type="pop" rate={0.9} />
    </Stage>
  );
};

// ১১ — সময় নয়, বিশ্বাস হারাচ্ছিল (cue 25–26)
export const Trust: React.FC = () => {
  const {at, len} = useScene();
  const t = useEase(at(26) + 30, len(26) - 50, 'inOut');
  const steps = Math.floor(t * 5) / 5;
  return (
    <Stage style={C}>
      <Enter delay={at(25)} dir="down" dist={24}><Chip dark>সবচেয়ে কষ্টের কথা</Chip></Enter>
      <Enter delay={at(26)} dir="up" style={{marginTop: 40}}>
        <Card style={{padding: '40px 54px', display: 'flex', flexDirection: 'column', gap: 34}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 30}}><ClockIcon size={70} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56, width: 420}}>সময়</span>
            <div style={{flex: 1, height: 36, borderRadius: 36, background: theme.colors.heroSoft}}><div style={{width: '30%', height: '100%', borderRadius: 36, background: theme.colors.textFaint}} /></div></div>
          <div style={{display: 'flex', alignItems: 'center', gap: 30}}><Heart size={70} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56, width: 420}}>নিজের উপর বিশ্বাস</span>
            <div style={{flex: 1, height: 36, borderRadius: 36, background: theme.colors.heroSoft, overflow: 'hidden'}}><div style={{width: `${100 - steps * 85}%`, height: '100%', borderRadius: 36, background: theme.colors.hero}} /></div></div>
        </Card>
      </Enter>
      <Enter delay={at(26) + 30} dir="up" style={{marginTop: 36, alignSelf: 'flex-start'}}><Chip style={{fontSize: 46}}>প্রতিবার প্রতিশ্রুতি ভাঙার সঙ্গে</Chip></Enter>
      <Sfx at={at(25)} type="pop" />
      <Sfx at={at(26)} type="whoosh" rate={0.9} vol={0.7} />
      {[0, 1, 2, 3, 4].map((i) => <Sfx key={i} at={at(26) + 30 + Math.round(((i + 1) * (len(26) - 50)) / 5)} type="click" rate={0.9 - i * 0.03} vol={0.5} />)}
    </Stage>
  );
};

// ১২ — ভেতরের প্রশ্ন (cue 27–28)
export const Question: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/desk-thinking.jpg" pos="70% 40%" side="left" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 36, width: 1000}}>
          <Enter delay={at(27)} dir="down" dist={24}><Chip>ভেতরে ভেতরে একটা প্রশ্ন বড় হচ্ছিল</Chip></Enter>
          <Words text="আমি কি সত্যিই *কিছু করতে পারব?*" delay={at(28)} per={6} size={120} />
        </div>
      </Stage>
      <Sfx at={at(27)} type="pop" vol={0.7} />
      <Sfx at={at(28)} type="whoosh" rate={0.95} />
    </PhotoBG>
  );
};

// ১৩ — জাদুকরী মুহূর্ত নয়, একটা ছোট সিদ্ধান্ত (cue 29–30)
export const SmallDecision: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Enter delay={at(29)} dir="left" dist={70}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 40, padding: '38px 60px'}}><Sparkle size={110} fill={theme.colors.textFaint} color={theme.colors.textDim} /><span style={{...H, fontSize: 96, color: theme.colors.textDim}}><Struck delay={at(29) + 44}>জাদুকরী মুহূর্ত</Struck></span></Card>
      </Enter>
      <Enter delay={at(30)} dir="right" dist={70} cfg="bouncy" style={{marginTop: 50}}>
        <Card dark style={{display: 'flex', alignItems: 'center', gap: 40, padding: '50px 60px', boxShadow: glow}}><Check size={110} color={theme.colors.onHero} /><span style={{...H, fontSize: 112}}>একটা ছোট সিদ্ধান্ত</span></Card>
      </Enter>
      <Sfx at={at(29)} type="pop" />
      <Sfx at={at(29) + 44} type="click" />
      <Sfx at={at(30)} type="chime" />
    </Stage>
  );
};

// ১৪ — ম্যান্ডেলার উক্তি (cue 31–32)
export const Mandela: React.FC = () => (
  <>
    <QuoteScene img="images/quote-mandela.png" w={760} h={628} a={31} b={32} chip="নেলসন ম্যান্ডেলার নামে প্রচলিত" bn="কোনো কাজ শেষ না হওয়া পর্যন্ত সেটাকে প্রায়ই অসম্ভব মনে হয়।" />
    <MandelaSfx />
  </>
);
const MandelaSfx: React.FC = () => { const {at} = useScene(); return (<><Sfx at={at(31)} type="whoosh" rate={0.95} /><Sfx at={at(32)} type="chime" vol={0.8} /></>); };

// ১৫ — পাহাড়: একটা পা, তারপর আরেকটা (cue 33–37)
export const MountainScene: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const climb = useEase(at(36), len(36, 37) - 10, 'inOut');
  const steps = Math.min(6, Math.floor(climb * 7));
  const pts = [[100, 560], [300, 470], [480, 400], [640, 330], [800, 250], [940, 170], [1060, 100]];
  return (
    <Stage>
      <div style={{display: 'flex', alignItems: 'center', gap: 30}}>
        <Enter delay={at(33)} dir="down" dist={24}><Chip dark>একটু ভাবো</Chip></Enter>
        <Words text="কাজটা *পাহাড়ের মতো* বড়" delay={at(34)} per={6} size={80} />
      </div>
      <Enter delay={at(34)} dir="up" style={{marginTop: 24}}>
        <Card style={{padding: 20, position: 'relative'}}>
          <svg width={1500} height={620} viewBox="0 0 1500 620" style={{overflow: 'visible'}}>
            <path d="M40 600 L560 120 L720 300 L900 160 L1400 600 Z" fill={theme.colors.heroSoft} stroke={theme.colors.text} strokeWidth={5} strokeLinejoin="round" />
            <DrawPath d={pts.map((p, i) => `${i ? 'L' : 'M'}${p[0] + 80} ${p[1]}`).join(' ')} delay={at(35)} dur={30} color={theme.colors.textFaint} width={8} />
            {pts.slice(0, steps + 1).map((p, i) => <circle key={i} cx={p[0] + 80} cy={p[1] - 6} r={i === steps ? 24 : 12} fill={i === steps ? theme.colors.hero : theme.colors.accent} />)}
            <g transform="translate(1080 -10)" opacity={useEase(at(37), 16)}><Flag size={120} /></g>
          </svg>
        </Card>
      </Enter>
      <div style={{display: 'flex', gap: 34, marginTop: 24, alignItems: 'center'}}>
        <Enter delay={at(35)} dir="up"><div style={{...H, fontSize: 56, color: theme.colors.textDim}}><Struck delay={at(35) + 30}>একবারে পার</Struck></div></Enter>
        <Enter delay={at(36)} dir="up" cfg="bouncy"><Chip dark style={{fontSize: 48}}>একটা পা, তারপর আরেকটা</Chip></Enter>
        <Enter delay={at(37)} dir="up" cfg="bouncy"><Chip style={{fontSize: 48}}>কঠিন ≠ অসম্ভব</Chip></Enter>
      </div>
      <Sfx at={at(33)} type="pop" />
      <Sfx at={at(34)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(35) + 30} type="click" />
      {[0, 1, 2, 3, 4, 5].map((i) => <Sfx key={i} at={at(36) + Math.round(((i + 1) * (len(36, 37) - 10)) / 7)} type="click" rate={1 + i * 0.05} vol={0.5} />)}
      <Sfx at={at(37)} type="chime" />
    </Stage>
  );
};

// ১৬ — স্টিভ জবসের উক্তি (cue 38–39)
export const Jobs: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <QuoteScene img="images/quote-jobs.png" w={780} h={613} a={38} b={39} chip="স্টিভ জবস · স্ট্যানফোর্ড, ২০০৫" bn="তোমার সময় সীমিত, তাই অন্য কারো জীবনযাপন করতে গিয়ে সেই সময় নষ্ট করো না।" />
      <Sfx at={at(38)} type="whoosh" rate={0.95} />
      <Sfx at={at(39)} type="chime" vol={0.8} />
    </>
  );
};

// ১৭ — অন্যের জীবন দেখার স্রোত (cue 40, ফাঁকসহ লম্বা)
export const Scroll: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const off = (f * 3.2) % 330;
  return (
    <Stage pad={0}>
      <div style={{position: 'absolute', right: 0, top: 0, width: 1000, height: 1080, overflow: 'hidden', maskImage: 'linear-gradient(90deg, transparent, black 25%)', WebkitMaskImage: 'linear-gradient(90deg, transparent, black 25%)'}}>
        <div style={{position: 'absolute', left: 280, top: -330 + off, display: 'flex', flexDirection: 'column', gap: 40}}>
          {Array.from({length: 7}).map((_, i) => (
            <div key={i} style={{width: 620, height: 290, borderRadius: 44, background: i % 2 ? theme.colors.heroSoft : theme.colors.accentSoft, border: `1.5px solid ${theme.colors.line}`, display: 'flex', alignItems: 'center', gap: 28, padding: 36}}>
              <div style={{width: 110, height: 110, borderRadius: '50%', background: theme.colors.hero, opacity: 0.7, flexShrink: 0}} />
              <div style={{flex: 1}}><div style={{height: 28, borderRadius: 14, background: theme.colors.line, width: '85%'}} /><div style={{height: 28, borderRadius: 14, background: theme.colors.line, width: '60%', marginTop: 22}} /></div>
            </div>
          ))}
        </div>
      </div>
      <div style={{position: 'absolute', left: 110, top: 0, bottom: 0, width: 900, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 32}}>
        <Enter delay={at(40)} dir="down" dist={24}><Chip dark>আজ</Chip></Enter>
        <Words text="অন্যের জীবন দেখা এত *সহজ*" delay={at(40) + 6} per={6} size={104} />
        <Enter delay={at(40) + 50} dir="up"><Chip style={{fontSize: 46}}>আগে কখনো এত সহজ ছিল না</Chip></Enter>
      </div>
      <Sfx at={at(40)} type="whoosh" vol={0.7} />
      <Sfx at={at(40) + 50} type="pop" />
    </Stage>
  );
};
