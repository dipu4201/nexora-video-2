import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from '../components/Ui';
import {DrawPath, Enter, MaskLine, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Battery, Book, Check, ClockIcon, Cross, Doc, Flag, Heart, Key, Lock, Moon, Person, Phone, Repeat, Scale, Sparkle, Sun, RainCloud, Shield} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {C, H, PhotoBG, QuoteScene, glow} from '../components/Kit';

// ১৮ — দেখতে দেখতে নিজের জীবন পড়ে থাকে (cue 41)
export const LifeLeft: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const dim = useEase(at(41) + 20, Math.max(40, len(41) - 30), 'inOut');
  const off = (f * 3) % 330;
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{width: 640, height: 820, overflow: 'hidden', borderRadius: 48, position: 'relative', flexShrink: 0, border: `1.5px solid ${theme.colors.line}`, background: theme.colors.card}}>
          <div style={{position: 'absolute', left: 30, top: -330 + off, display: 'flex', flexDirection: 'column', gap: 36}}>
            {Array.from({length: 6}).map((_, i) => <div key={i} style={{width: 580, height: 290, borderRadius: 40, background: i % 2 ? theme.colors.heroSoft : theme.colors.accentSoft, display: 'flex', alignItems: 'center', gap: 26, padding: 32}}><div style={{width: 100, height: 100, borderRadius: '50%', background: theme.colors.hero, opacity: 0.7}} /><div style={{flex: 1}}><div style={{height: 26, borderRadius: 13, background: theme.colors.line, width: '85%'}} /></div></div>)}
          </div>
        </div>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Words text="দেখতে দেখতে নিজের জীবনটা *পড়ে থাকে*" delay={at(41)} per={5} size={90} />
          <Enter delay={at(41) + 20} dir="up">
            <Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '30px 46px', opacity: 1 - dim * 0.6, filter: `grayscale(${dim})`}}><Doc size={110} /><span style={{...H, fontSize: 70}}>তোমার নিজের জীবন</span></Card>
          </Enter>
          <Enter delay={at(41) + 60} dir="up"><Chip style={{fontSize: 44}}>আমরা টের পাই না</Chip></Enter>
        </div>
      </div>
      <Sfx at={at(41)} type="whoosh" vol={0.7} />
      <Sfx at={at(41) + 60} type="pop" vol={0.7} />
    </Stage>
  );
};

// ১৯ — অনুপ্রাণিত হও, কিন্তু মেপো না (cue 42–43)
export const Compare: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 60}}>
        <Enter delay={at(42)} dir="right" dist={60} cfg="bouncy" style={{flex: 1}}>
          <Card dark style={{height: 480, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24, boxShadow: glow}}><Sparkle size={150} color={theme.colors.onHero} fill={theme.colors.onHero} /><span style={{...H, fontSize: 88}}>অনুপ্রাণিত হও</span><Chip style={{background: 'rgba(7,8,12,0.18)', color: theme.colors.onHero}}>অন্যের সাফল্য দেখে</Chip></Card>
        </Enter>
        <Enter delay={at(43)} dir="left" dist={60} style={{flex: 1}}>
          <Card style={{height: 480, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24, opacity: 0.9}}><Scale size={170} /><span style={{...H, fontSize: 80, color: theme.colors.textDim}}><Struck delay={at(43) + 36}>নিজের মূল্য মাপা</Struck></span><Chip>অন্যের সঙ্গে</Chip></Card>
        </Enter>
      </div>
      <Sfx at={at(42)} type="pop" />
      <Sfx at={at(43)} type="pop" rate={0.94} vol={0.8} />
      <Sfx at={at(43) + 36} type="click" />
    </Stage>
  );
};

// ২০ — আলাদা যাত্রা, গতকালের চেয়ে একটু এগোনো (cue 44–46)
export const YourPath: React.FC = () => {
  const {at, len} = useScene();
  const paths = ['M80 360 C 260 360, 300 120, 520 140', 'M80 360 C 300 360, 380 300, 520 260', 'M80 360 C 240 380, 400 420, 520 400'];
  const stair = useSpring(at(46), 'bouncy');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <div style={{flex: 1}}>
          <Words text="জীবন, পরিস্থিতি, যাত্রা—সবই *আলাদা*" delay={at(44)} per={5} size={82} />
          <Enter delay={at(44) + 20} dir="up" style={{marginTop: 20}}>
            <Card style={{padding: 20}}>
              <svg width={640} height={480} viewBox="0 0 640 480" style={{overflow: 'visible'}}>
                {paths.map((d, i) => <DrawPath key={i} d={d} delay={at(44) + 24 + i * 12} dur={40} color={i === 1 ? theme.colors.hero : theme.colors.textFaint} width={9} />)}
                <circle cx={80} cy={360} r={18} fill={theme.colors.accent} />
              </svg>
            </Card>
          </Enter>
          <Enter delay={at(45)} dir="up" style={{marginTop: 26}}><div style={{...H, fontSize: 60, color: theme.colors.textDim}}><Struck delay={at(45) + 30}>অন্য কারো মতো হওয়া</Struck></div></Enter>
        </div>
        <div style={{width: 760, flexShrink: 0, display: 'flex', alignItems: 'flex-end', gap: 30, height: 620}}>
          <Enter delay={at(46)} dir="up" style={{flex: 1}}><Card style={{height: 240, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56, textAlign: 'center', lineHeight: 1.3}}>গতকালের<br />তুমি</span></Card></Enter>
          <div style={{flex: 1, transform: `translateY(${(1 - stair) * 60}px)`, opacity: clamp01(stair)}}><Card dark style={{height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, boxShadow: glow}}><span style={{...H, fontSize: 56, textAlign: 'center', lineHeight: 1.3}}>আজকের<br />তুমি</span><span style={{...H, fontSize: 90}}>↑</span></Card></div>
        </div>
      </div>
      <Sfx at={at(44)} type="whoosh" rate={0.95} vol={0.7} />
      <Sfx at={at(45) + 30} type="click" />
      <Sfx at={at(46)} type="pop" />
      <Sfx at={at(46) + 8} type="chime" vol={0.8} />
    </Stage>
  );
};

// ২১ — সেই রাতে একটা সিদ্ধান্ত, বড় প্রতিজ্ঞা নয় (cue 47–48)
export const Decision: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/desk-thinking.jpg" pos="65% 40%" side="left">
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 34, width: 1000}}>
          <Enter delay={at(47)} dir="down" dist={24}><Chip dark><Moon size={44} color={theme.colors.onHero} fill={theme.colors.onHero} /> সেই রাতে</Chip></Enter>
          <Words text="আরিফ একটা *সিদ্ধান্ত* নিল" delay={at(47) + 6} per={6} size={104} />
          <Enter delay={at(48)} dir="up"><Card style={{padding: '26px 44px', alignSelf: 'flex-start'}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 58, color: theme.colors.textDim}}><Struck delay={at(48) + 30}>বড় প্রতিজ্ঞা</Struck></span></Card></Enter>
        </div>
      </Stage>
      <Sfx at={at(47)} type="pop" vol={0.7} />
      <Sfx at={at(48)} type="pop" rate={0.95} />
      <Sfx at={at(48) + 30} type="click" />
    </PhotoBG>
  );
};

// ২২ — "কাল থেকে সব বদলে ফেলবো" বলতে বলতে ক্লান্ত (cue 49–50)
export const TiredPledge: React.FC = () => {
  const {at, len} = useScene();
  const drain = useEase(at(50), Math.max(40, len(50) - 10), 'inOut');
  return (
    <Stage style={C}>
      <Enter delay={at(49)} dir="left" dist={70}>
        <Card style={{padding: '44px 60px'}}><span style={{...H, fontSize: 92, color: theme.colors.textDim}}>“<Struck delay={at(49) + 30}>কাল থেকে সব বদলে ফেলবো</Struck>”</span></Card>
      </Enter>
      <Enter delay={at(50)} dir="up" cfg="bouncy" style={{marginTop: 44}}>
        <Card dark style={{display: 'flex', alignItems: 'center', gap: 50, padding: '36px 60px', boxShadow: glow}}>
          <Battery size={260} color={theme.colors.onHero} fill={theme.colors.onHero} level={Math.max(0.04, 0.9 - drain * 0.86)} />
          <span style={{...H, fontSize: 92}}>বলতে বলতে ক্লান্ত</span>
        </Card>
      </Enter>
      <Sfx at={at(49)} type="pop" />
      <Sfx at={at(49) + 30} type="click" />
      <Sfx at={at(50)} type="thud" vol={0.6} />
    </Stage>
  );
};

// ২৩ — আজ একটা কাজ, মাত্র একটা (cue 51–52)
export const OneThing: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const p = useSpring(at(52), 'bouncy');
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', alignItems: 'center', gap: 90}}>
        <Enter delay={at(51)} cfg="bouncy" from={0.4}>
          <div style={{width: 440, height: 440, borderRadius: '50%', background: theme.colors.hero, boxShadow: `0 0 ${110 + Math.sin(f / 10) * 20}px ${theme.colors.heroGlow}`, display: 'flex', alignItems: 'center', justifyContent: 'center', ...H, fontSize: 330, color: theme.colors.onHero, lineHeight: 1.2}}>১</div>
        </Enter>
        <div>
          <Words text="আজ একটা *কাজ*" delay={at(51) + 6} per={7} size={130} />
          <div style={{transform: `scale(${p})`, opacity: clamp01(p), transformOrigin: '0 50%', marginTop: 16}}><Chip dark style={{fontSize: 70, padding: '14px 50px'}}>মাত্র একটা</Chip></div>
        </div>
      </div>
      <Sfx at={at(51)} type="thud" vol={0.7} />
      <Sfx at={at(52)} type="chime" />
    </Stage>
  );
};

// ২৪ — ছোট ছোট কাজ: ফোন বন্ধ, বিছানা, ডেস্ক, নোটবুক (cue 53–55)
export const Actions: React.FC = () => {
  const {at, len} = useScene();
  const items = ['ফোন বন্ধ', 'বিছানা গোছানো', 'ডেস্কে বসা', 'নোটবুকে তিনটা কাজ'].map((t, i) => ({t, d: at(53) + 6 + Math.round((i * (len(53) - 10)) / 4)}));
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
          {items.map((it) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}>
              <Card style={{display: 'flex', alignItems: 'center', gap: 28, padding: '24px 42px'}}>
                <div style={{width: 64, height: 64, borderRadius: 20, background: theme.colors.hero, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${useSpring(it.d + 8, 'bouncy')})`}}><Check size={40} color={theme.colors.onHero} /></div>
                <span style={{...H, fontWeight: theme.weight.strong, fontSize: 58}}>{it.t}</span>
              </Card>
            </Enter>
          ))}
          <Enter delay={at(55)} dir="up"><Chip dark style={{fontSize: 46}}>কয়েক সপ্তাহ পিছিয়ে দেওয়া কাজটাই প্রথম</Chip></Enter>
        </div>
        <Enter delay={at(53) - 4} dir="left" dist={80} style={{width: 760, height: 700, flexShrink: 0}}>
          <Photo src="images/writing-flannel.jpg" w={760} h={700} pos="45% 55%" />
        </Enter>
      </div>
      {items.map((it, i) => <Sfx key={it.t} at={it.d + 8} type="click" rate={1 + i * 0.05} vol={0.7} />)}
      <Sfx at={at(54)} type="pop" />
      <Sfx at={at(55)} type="chime" vol={0.7} />
    </Stage>
  );
};

// ২৫ — সহজ ছিল না, তবু প্রতিবার ফিরে এল (cue 56–58)
export const ReturnLoop: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const t = useEase(at(56) + 10, len(56, 58) - 30, 'inOut');
  const path = 'M80 260 L1380 260';
  const x = 80 + 1300 * t;
  const off = [0, 1, 2].map((k) => { const c = 0.2 + k * 0.28; const d = Math.abs(t - c); return d < 0.08 ? Math.sin((1 - d / 0.08) * Math.PI) * 130 * (k % 2 ? -1 : 1) : 0; });
  const y = 260 + off.reduce((a, b) => a + b, 0);
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(56)} dir="down" dist={24}><Chip>সহজ ছিল না</Chip></Enter>
        <Words text="বারবার মন অন্যদিকে… তবু *ফিরে এল*" delay={at(57)} per={5} size={78} />
      </div>
      <Enter delay={at(56)} dir="up" style={{marginTop: 40}}>
        <Card style={{padding: 26}}>
          <svg width={1520} height={520} viewBox="0 0 1520 520" style={{overflow: 'visible'}}>
            <path d={path} stroke={theme.colors.line} strokeWidth={10} strokeLinecap="round" strokeDasharray="4 20" />
            <DrawPath d={path} delay={at(56) + 10} dur={len(56, 58) - 30} color={theme.colors.textFaint} width={8} />
            <circle cx={x} cy={y} r={26 + Math.sin(f / 5) * 2} fill={theme.colors.hero} opacity={clamp01(t * 30)} />
          </svg>
        </Card>
      </Enter>
      <Enter delay={at(58)} dir="up" cfg="bouncy" style={{marginTop: 30, alignSelf: 'flex-start'}}><Card dark style={{display: 'flex', alignItems: 'center', gap: 22, padding: '18px 40px', boxShadow: glow}}><Repeat size={60} color={theme.colors.onHero} /><span style={{...H, fontSize: 56}}>প্রতিবার সে আবার ফিরে এল</span></Card></Enter>
      <Sfx at={at(56)} type="pop" vol={0.7} />
      <Sfx at={at(57)} type="whoosh" vol={0.6} />
      <Sfx at={at(58)} type="chime" />
    </Stage>
  );
};

// ২৬ — জীবন বদলায়নি, কিন্তু প্রতিশ্রুতি রাখা হয়েছিল (cue 59–62)
export const PromiseKept: React.FC = () => {
  const {at} = useScene();
  const pop = useSpring(at(61) + 20, 'bouncy');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <Enter delay={at(59) - 4} dir="right" dist={80} style={{width: 880, height: 720, flexShrink: 0, position: 'relative'}}>
          <Photo src="images/writing-warm.jpg" w={880} h={720} pos="40% 50%" zoomOut />
          <div style={{position: 'absolute', right: 30, bottom: 30, transform: `scale(${pop})`, opacity: clamp01(pop)}}><div style={{width: 160, height: 160, borderRadius: '50%', background: theme.colors.hero, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: glow}}><Check size={100} color={theme.colors.onHero} /></div></div>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
          <Enter delay={at(59)} dir="left" dist={50}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 64, color: theme.colors.textDim}}>জীবন <Struck delay={at(59) + 30}>বদলে যায়নি</Struck></div></Enter>
          <Enter delay={at(60)} dir="up"><div style={{...H, fontSize: 80, lineHeight: 1.3}}>কিন্তু <span style={{color: theme.colors.hero}}>একটা জিনিস</span> বদলেছিল</div></Enter>
          <Enter delay={at(61)} dir="up" cfg="bouncy"><Card dark style={{padding: '26px 40px', boxShadow: glow}}><span style={{...H, fontSize: 56, lineHeight: 1.4}}>নিজের কাছে দেওয়া একটা ছোট প্রতিশ্রুতি রাখতে পেরেছিল</span></Card></Enter>
          <Enter delay={at(62)} dir="up"><Chip style={{fontSize: 46}}>নতুন করে শুরুর জন্য এটুকুই যথেষ্ট</Chip></Enter>
        </div>
      </div>
      <Sfx at={at(59)} type="pop" vol={0.7} />
      <Sfx at={at(61)} type="whoosh" vol={0.7} />
      <Sfx at={at(61) + 20} type="chime" />
      <Sfx at={at(62)} type="pop" rate={1.08} vol={0.7} />
    </Stage>
  );
};

// ২৭ — অনেক বাকি, অপূর্ণ, আফসোস — এখুনি সব ঠিক করতে হবে না (cue 63–66)
export const Heavy: React.FC = () => {
  const {at} = useScene();
  const lift = useEase(at(66) + 12, 30, 'inOut');
  const cards = [{t: 'অনেক কাজ বাকি', d: at(63)}, {t: 'অনেক স্বপ্ন অপূর্ণ', d: at(64)}, {t: 'অনেক ভুলের আফসোস', d: at(65)}];
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <Enter delay={at(63) - 4} dir="right" dist={80} style={{width: 640, height: 780, flexShrink: 0}}>
          <Photo src="images/bed-sad.jpg" w={640} h={780} pos="55% 40%" />
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
          {cards.map((c, i) => (
            <Enter key={c.t} delay={c.d} dir="down" dist={90} cfg="bouncy">
              <div style={{transform: `translateY(${-lift * 20 * (3 - i)}px)`, opacity: 1 - lift * 0.5}}>
                <Card style={{display: 'flex', alignItems: 'center', gap: 28, padding: '30px 44px'}}><Doc size={80} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 62}}>{c.t}</span></Card>
              </div>
            </Enter>
          ))}
          <Enter delay={at(66)} dir="up" cfg="bouncy"><Card dark style={{padding: '30px 48px', boxShadow: glow}}><span style={{...H, fontSize: 66}}>এখুনি সব ঠিক করতে হবে না</span></Card></Enter>
        </div>
      </div>
      {cards.map((c, i) => <Sfx key={c.t} at={c.d} type="thud" rate={1.1 - i * 0.08} vol={0.55} />)}
      <Sfx at={at(66)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ২৮ — শ্বাসের বিরতি: SRT-র ফাঁক (cue 66 → 67), শুধু ভিজ্যুয়াল
export const Breath: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <PhotoBG src="images/road-sunrise.jpg" pos="50% 55%" side="full" panX={-40}>
      <AbsoluteFill>
        {Array.from({length: 26}).map((_, i) => {
          const sx = (i * 197) % 1920, sp = 0.25 + ((i * 53) % 10) / 22, size = 4 + (i % 4) * 2;
          const y = 1080 - ((f * sp * 1.4 + i * 83) % 1180);
          return <div key={i} style={{position: 'absolute', left: sx + Math.sin(f / 40 + i) * 24, top: y, width: size, height: size, borderRadius: '50%', background: theme.colors.accent, opacity: 0.35 + 0.3 * Math.sin(f / 20 + i)}} />;
        })}
      </AbsoluteFill>
    </PhotoBG>
  );
};

// ২৯ — পরের সঠিক পদক্ষেপ (cue 67)
export const NextStep: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const stones = [150, 480, 810, 1140, 1470];
  const lit = useEase(at(67) + 30, 20, 'out');
  return (
    <Stage style={C}>
      <Words text="শুধু পরের *সঠিক পদক্ষেপটা* নাও" delay={at(67)} per={6} size={104} />
      <Enter delay={at(67) + 10} dir="up" style={{marginTop: 56}}>
        <Card style={{padding: 26}}>
          <svg width={1620} height={300} viewBox="0 0 1620 300">
            <path d="M0 220 L1620 220" stroke={theme.colors.line} strokeWidth={6} strokeDasharray="4 18" />
            {stones.map((x, i) => <ellipse key={i} cx={x} cy={170} rx={96} ry={40} fill={i < 2 ? theme.colors.hero : i === 2 ? theme.colors.hero : theme.colors.cardSolid} stroke={theme.colors.text} strokeWidth={5} opacity={i === 2 ? 0.45 + lit * 0.55 : i < 2 ? 0.9 : 0.5} />)}
            <circle cx={stones[1] + (stones[2] - stones[1]) * lit} cy={110 - Math.sin(lit * Math.PI) * 70} r={26} fill={theme.colors.accent} />
          </svg>
        </Card>
      </Enter>
      <Sfx at={at(67)} type="whoosh" rate={0.95} />
      <Sfx at={at(67) + 50} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৩০ — মোহাম্মদ আলীর উক্তি (cue 68–69)
export const Ali: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <QuoteScene img="images/quote-ali.png" w={820} h={500} a={68} b={69} chip="মোহাম্মদ আলীর নামে প্রচলিত" bn="দিন গুণো না, দিনগুলোকে অর্থবহ করে তোলো।" />
      <Sfx at={at(68)} type="whoosh" rate={0.95} />
      <Sfx at={at(69)} type="chime" vol={0.8} />
    </>
  );
};

// ৩১ — আজকের দিনটাও জীবনের অংশ (cue 70–71)
export const Today: React.FC = () => {
  const {at, len} = useScene();
  const days = Array.from({length: 7});
  return (
    <Stage style={C}>
      <Words text="আজকের দিনটা হয়তো সবচেয়ে বড় দিন নয়" delay={at(70)} per={4} size={76} weight={theme.weight.strong} color={theme.colors.textDim} />
      <div style={{display: 'flex', gap: 26, marginTop: 56}}>
        {days.map((_, i) => {
          const d = at(70) + 14 + Math.round((i * (len(70) - 20)) / 7);
          const today = i === 3;
          const glowP = today ? useEase(at(71), 20) : 0;
          return (
            <Enter key={i} delay={d} dir="up" cfg="bouncy" style={{flex: 1}}>
              <Card dark={today && glowP > 0.4} style={{height: 250, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: today && glowP > 0.4 ? glow : theme.shadow, transform: `scale(${today ? 1 + glowP * 0.1 : 1})`}}>
                <div style={{width: 70, height: 70, borderRadius: '50%', background: today && glowP > 0.4 ? theme.colors.onHero : theme.colors.heroSoft}} />
              </Card>
            </Enter>
          );
        })}
      </div>
      <Enter delay={at(71)} dir="up" cfg="bouncy" style={{marginTop: 50, alignSelf: 'center'}}><Chip dark style={{fontSize: 64, padding: '16px 56px'}}>এই দিনটাও তোমার জীবনের অংশ</Chip></Enter>
      <Sfx at={at(70)} type="whoosh" vol={0.6} />
      <Sfx at={at(71)} type="chime" />
    </Stage>
  );
};

// ৩২ — আজ কী শিখলে, কী চেষ্টা করলে, কোন কাজটা এগোলো (cue 72–74)
export const Prompts: React.FC = () => {
  const {at} = useScene();
  const qs = [{t: 'আজ তুমি কী শিখলে?', d: at(72)}, {t: 'কী চেষ্টা করলে?', d: at(73)}, {t: 'কোন ছোট কাজটা তোমাকে একটু এগিয়ে দিল?', d: at(74)}];
  return (
    <Stage style={C}>
      <div style={{display: 'flex', flexDirection: 'column', gap: 28}}>
        {qs.map((q, i) => (
          <Enter key={q.t} delay={q.d} dir="right" dist={70} cfg="bouncy">
            <Card dark={i === 2} style={{display: 'flex', alignItems: 'center', gap: 36, padding: '34px 54px', boxShadow: i === 2 ? glow : theme.shadow}}>
              <span style={{...H, fontSize: 110, color: i === 2 ? theme.colors.onHero : theme.colors.hero, width: 90}}>{toBn(i + 1)}</span>
              <span style={{...H, fontWeight: theme.weight.strong, fontSize: 70}}>{q.t}</span>
            </Card>
          </Enter>
        ))}
      </div>
      {qs.map((q, i) => <Sfx key={q.t} at={q.d} type="pop" rate={1 + i * 0.06} vol={0.8} />)}
    </Stage>
  );
};

// ৩৩ — ছোট ছোট প্রচেষ্টার দেওয়াল (cue 75–77)
export const Effort: React.FC = () => {
  const {at, len} = useScene();
  const rows = 5, cols = 8, total = rows * cols;
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
          <Words text="প্রতিদিন অসাধারণ হতে হবে না" delay={at(75)} per={4} size={76} weight={theme.weight.strong} color={theme.colors.textDim} />
          <Enter delay={at(76)} dir="up" cfg="bouncy"><Card dark style={{padding: '30px 48px', boxShadow: glow}}><span style={{...H, fontSize: 70, lineHeight: 1.35}}>“আজ আমি চেষ্টা করেছি”</span></Card></Enter>
          <Enter delay={at(77) + 30} dir="up"><Chip style={{fontSize: 46}}>যেগুলো কেউ দেখে না</Chip></Enter>
        </div>
        <Enter delay={at(75)} dir="left" dist={50} style={{width: 860, flexShrink: 0}}>
          <Card style={{padding: 34}}>
            <div style={{display: 'grid', gridTemplateColumns: `repeat(${cols}, 1fr)`, gap: 12}}>
              {Array.from({length: total}).map((_, i) => {
                const order = (rows - 1 - Math.floor(i / cols)) * cols + (i % cols);
                const d = at(77) + Math.round((order * (len(77) - 30)) / total);
                const p = useSpring(d, 'snappy');
                return <div key={i} style={{height: 74, borderRadius: 14, background: order % 7 === 0 ? theme.colors.accent : theme.colors.hero, opacity: clamp01(p * 1.4) * 0.9, transform: `translateY(${(1 - p) * -40}px) scale(${0.7 + p * 0.3})`}} />;
              })}
            </div>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(75)} type="pop" vol={0.7} />
      <Sfx at={at(76)} type="chime" vol={0.8} />
      <Sfx at={at(77)} type="whoosh" rate={1.1} vol={0.6} />
    </Stage>
  );
};

// ৩৪ — সব দিন মোটিভেটেড থাকবে না (cue 78–82)
export const Truth: React.FC = () => {
  const {at} = useScene();
  const items = [
    {t: 'কিছুই করতে ইচ্ছা করবে না', d: at(80), icon: <Battery size={110} level={0.05} />},
    {t: 'চেষ্টা করেও ফল পাবে না', d: at(81), icon: <RainCloud size={120} />},
    {t: 'মনে হবে সবাই এগিয়ে', d: at(82), icon: <Person size={110} fill={theme.colors.heroSoft} />},
  ];
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 40}}>
        <Enter delay={at(78)} dir="down" dist={24}><Chip dark>একটা সত্যি কথা</Chip></Enter>
        <Words text="সব দিন *মোটিভেটেড* থাকবে না" delay={at(79)} per={5} size={88} />
      </div>
      <div style={{display: 'flex', gap: 36, marginTop: 56}}>
        {items.map((it) => (
          <Enter key={it.t} delay={it.d} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card style={{height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26, textAlign: 'center'}}>{it.icon}<span style={{...H, fontWeight: theme.weight.strong, fontSize: 56, lineHeight: 1.35}}>{it.t}</span></Card>
          </Enter>
        ))}
      </div>
      <Sfx at={at(78)} type="pop" vol={0.7} />
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="thud" rate={1.05 - i * 0.06} vol={0.5} />)}
    </Stage>
  );
};

// ৩৫ — সেই দিনগুলোতে নিজের যত্ন (cue 83–86)
export const Care: React.FC = () => {
  const {at} = useScene();
  const items = [{t: 'বিশ্রাম নাও', d: at(84), icon: <Moon size={80} />}, {t: 'পরিকল্পনাটা আবার দেখো', d: at(85), icon: <Book size={90} />}, {t: 'দরকারে সাহায্য চাও', d: at(86), icon: <Person size={84} fill={theme.colors.heroSoft} />}];
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{width: 760, display: 'flex', flexDirection: 'column', gap: 30, flexShrink: 0}}>
          <Enter delay={at(83)} cfg="bouncy" from={0.5}><Heart size={200} /></Enter>
          <div style={{...H, fontSize: 84, color: theme.colors.textDim, lineHeight: 1.3}}>নিজেকে <Struck delay={at(83) + 26}>ঘৃণা</Struck> করো না</div>
        </div>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
          {items.map((it) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '30px 46px'}}>{it.icon}<span style={{...H, fontWeight: theme.weight.strong, fontSize: 64}}>{it.t}</span></Card></Enter>
          ))}
        </div>
      </div>
      <Sfx at={at(83)} type="pop" vol={0.7} />
      <Sfx at={at(83) + 26} type="click" vol={0.8} />
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 + i * 0.05} vol={0.7} />)}
    </Stage>
  );
};

// ৩৬ — সাহায্য চাওয়া দুর্বলতা নয় (cue 87–88)
export const Help: React.FC = () => {
  const {at, len} = useScene();
  const who = ['বন্ধু', 'পরিবার', 'শিক্ষক', 'বিশেষজ্ঞ'].map((t, i) => ({t, d: at(88) + Math.round((i * len(88)) / 4)}));
  return (
    <Stage style={C}>
      <Enter delay={at(87)} dir="left" dist={70}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 36, padding: '34px 56px'}}><Cross size={76} /><span style={{...H, fontSize: 80, color: theme.colors.textDim}}>সাহায্য চাওয়া = <Struck delay={at(87) + 40}>দুর্বলতা</Struck></span></Card>
      </Enter>
      <div style={{display: 'flex', gap: 30, marginTop: 56}}>
        {who.map((w, i) => (
          <Enter key={w.t} delay={w.d} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card dark={i === 3} style={{height: 330, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, boxShadow: i === 3 ? glow : theme.shadow}}><Person size={140} fill={i === 3 ? theme.colors.onHero : theme.colors.heroSoft} color={i === 3 ? theme.colors.onHero : theme.colors.text} /><span style={{...H, fontSize: 64}}>{w.t}</span></Card>
          </Enter>
        ))}
      </div>
      <Enter delay={at(88) + 30} dir="up" style={{marginTop: 44, alignSelf: 'center'}}><Chip style={{fontSize: 46}}>সাহায্য নেওয়াও একটা সিদ্ধান্ত</Chip></Enter>
      <Sfx at={at(87)} type="pop" />
      <Sfx at={at(87) + 40} type="click" />
      {who.map((w, i) => <Sfx key={w.t} at={w.d} type="pop" rate={1 + i * 0.05} vol={0.7} />)}
    </Stage>
  );
};
