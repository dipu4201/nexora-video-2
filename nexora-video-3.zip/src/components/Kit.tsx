import React from 'react';
import {AbsoluteFill, Img, staticFile} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from './Ui';
import {Enter, Words} from './Motion';

export const H: React.CSSProperties = {fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, letterSpacing: 0};
export const C: React.CSSProperties = {justifyContent: 'center'};
export const glow = `0 0 90px ${theme.colors.heroGlow}, ${theme.shadow}`;

// পূর্ণ-পর্দা ছবি + পাঠ্যের পাশে গাঢ় গ্রেডিয়েন্ট
export const PhotoBG: React.FC<{src: string; pos?: string; zoomOut?: boolean; side?: 'left' | 'right' | 'full'; panX?: number; children?: React.ReactNode}> = ({
  src, pos = 'center', zoomOut, side = 'left', panX, children,
}) => {
  const g = side === 'left' ? `linear-gradient(90deg, ${theme.colors.bg}F2 0%, ${theme.colors.bg}B8 45%, transparent 88%)`
    : side === 'right' ? `linear-gradient(270deg, ${theme.colors.bg}F2 0%, ${theme.colors.bg}B8 45%, transparent 88%)`
    : `linear-gradient(180deg, ${theme.colors.bg}99, ${theme.colors.bg}CC)`;
  return (
    <AbsoluteFill>
      <Photo src={src} radius={0} pos={pos} zoomOut={zoomOut} panX={panX} style={{position: 'absolute', inset: 0, boxShadow: 'none', border: 'none'}} />
      <AbsoluteFill style={{background: g}} />
      {children}
    </AbsoluteFill>
  );
};

// উক্তির কার্ড: ছবি + বাংলা অনুবাদ (cue a: প্রসঙ্গ, cue b: উক্তি)
export const QuoteScene: React.FC<{img: string; w: number; h: number; a: number; b: number; chip: string; bn: string}> = ({img, w, h, a, b, chip, bn}) => {
  const {at} = useScene();
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <Enter delay={at(a) - 2} dir="right" dist={70} cfg="bouncy" style={{flexShrink: 0}}>
          <Card style={{padding: 14, borderRadius: 40, boxShadow: glow, overflow: 'hidden'}}>
            <Img src={staticFile(img)} style={{width: w, height: h, borderRadius: 28, objectFit: 'cover', display: 'block'}} />
          </Card>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Enter delay={at(a)} dir="down" dist={24}><Chip dark>{chip}</Chip></Enter>
          <Enter delay={at(b)} dir="up"><div style={{...H, fontSize: 150, lineHeight: 0.8, color: theme.colors.hero}}>“</div></Enter>
          <Words text={bn} delay={at(b) + 6} per={4} size={78} />
        </div>
      </div>
    </Stage>
  );
};
