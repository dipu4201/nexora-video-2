import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
// ধীর নেটে ফন্ট লোড হতে সময় লাগে, তাই সময়সীমা বাড়ানো
Config.setDelayRenderTimeoutInMilliseconds(300000);
