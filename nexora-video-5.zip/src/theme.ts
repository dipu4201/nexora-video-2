// theme.ts — রং, ইজিং, spring প্রিসেট ও ফন্টের একমাত্র উৎস। কম্পোনেন্টে সরাসরি হেক্স নয়।
import {Easing} from 'remotion';

export const theme = {
  colors: {
    // স্কিম ৩ — Rain Window Slate
    bg: '#151A22',
    bgAlt: '#1C222C',
    hero: '#8EA7C8', // হিরো ধূসর-নীল (প্রতি ফ্রেমে সর্বোচ্চ একটি জোরালো উপাদান)
    accent: '#F2B880',
    text: '#EDF1F6',
    textDim: 'rgba(237,241,246,0.66)',
    textFaint: 'rgba(237,241,246,0.28)',
    onHero: '#10141B',
    card: 'rgba(32,40,52,0.88)',
    cardSolid: '#1E2530',
    line: 'rgba(237,241,246,0.15)',
    accentSoft: 'rgba(242,184,128,0.26)',
    accentGlow: 'rgba(242,184,128,0.45)',
    heroSoft: 'rgba(142,167,200,0.17)',
    heroGlow: 'rgba(142,167,200,0.45)',
    vignette: 'rgba(0,0,0,0.5)',
    shadow: 'rgba(0,0,0,0.6)',
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
    body: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
  },
  weight: {hero: 700, strong: 600, body: 500},
  size: {h1: 148, h2: 108, h3: 76, body: 54, label: 38, small: 30},
  radius: 36,
  shadow: '0 36px 70px -26px rgba(0,0,0,0.78), 0 6px 18px -8px rgba(0,0,0,0.5)',
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;
