import React from 'react';
import {Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Stage} from '../components/Ui';
import {DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Check, ClockIcon, Cross, Heart, Mute, Person, Repeat, Sparkle} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {BlurBG, C, H, PhotoBG, PhotoCard, glow} from '../components/Kit';

const peach = `0 0 80px ${theme.colors.accentGlow}, ${theme.shadow}`;

// ১৪ — তাহলে কী করবে? তিনটা ছোট কাজ (cue 32–33)
export const ThreeSteps: React.FC = () => {
  const {at} = useScene();
  const steps = ['তুলনার রাস্তা সরু করো', 'নিজের সঙ্গে নিজেকে মেলাও', '৩০ দিনের ছোট লক্ষ্য'];
  return (
    <Stage style={C}>
      <Words text="তাহলে কী করবে?" delay={at(32)} per={7} size={120} />
      <Enter delay={at(33)} dir="up" style={{marginTop: 20}}><Chip dark style={{fontSize: 56, padding: '12px 56px'}}>তিনটা ছোট কাজ</Chip></Enter>
      <div style={{display: 'flex', gap: 30, marginTop: 56}}>
        {steps.map((s, i) => (
          <Enter key={s} delay={at(33) + 18 + i * 14} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card dark={i === 0} style={{height: 330, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', boxShadow: i === 0 ? glow : theme.shadow}}>
              <span style={{...H, fontSize: 130, lineHeight: 1.1, color: i === 0 ? theme.colors.onHero : theme.colors.accent}}>{toBn(i + 1)}</span>
              <span style={{...H, fontSize: 52, lineHeight: 1.35}}>{s}</span>
            </Card>
          </Enter>
        ))}
      </div>
      <Sfx at={at(32)} type="whoosh" vol={0.7} />
      <Sfx at={at(33)} type="pop" />
      {steps.map((s, i) => <Sfx key={s} at={at(33) + 18 + i * 14} type="pop" rate={1 + i * 0.07} vol={0.75} />)}
    </Stage>
  );
};

// ১৫ — ধাপ ১: তুলনার রাস্তা সরু করো, পোস্ট মিউট (cue 34–36)
export const Step1: React.FC = () => {
  const {at} = useScene();
  const narrow = useEase(at(34) + 8, 36, 'inOut');
  const mute = useEase(at(35) + 20, 14, 'out');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
          <Enter delay={at(34)} dir="down" dist={24}><Chip dark>ধাপ ১</Chip></Enter>
          <Words text="তুলনার রাস্তা *সরু* করো" delay={at(34) + 6} per={6} size={100} />
          <Enter delay={at(36)} dir="left" dist={50}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 56, color: theme.colors.textDim}}><Struck delay={at(36) + 26}>বন্ধুকে হিংসা</Struck></div></Enter>
          <Enter delay={at(36) + 20} dir="up" cfg="bouncy"><Card dark style={{padding: '22px 44px', boxShadow: glow, display: 'inline-block'}}><span style={{...H, fontSize: 60}}>নিজের মনকে বাঁচানো</span></Card></Enter>
        </div>
        <div style={{width: 820, flexShrink: 0, display: 'flex', flexDirection: 'column', gap: 30}}>
          <Enter delay={at(34)} dir="left" dist={60}>
            <Card style={{padding: 26}}>
              <svg width={760} height={220} viewBox="0 0 760 220"><path d={`M20 ${110 - 96 * (1 - narrow)} L740 ${110 - 20 * (1 - narrow)} L740 ${110 + 20 * (1 - narrow)} L20 ${110 + 96 * (1 - narrow)} Z`} fill={theme.colors.heroSoft} stroke={theme.colors.hero} strokeWidth="5" /><circle cx={60 + 600 * narrow} cy="110" r="18" fill={theme.colors.accent} /></svg>
            </Card>
          </Enter>
          <Enter delay={at(35)} dir="up" cfg="bouncy">
            <Card style={{padding: '26px 34px'}}>
              <div style={{display: 'flex', alignItems: 'center', gap: 24, opacity: 1 - mute * 0.65, filter: `grayscale(${mute})`}}>
                <div style={{width: 90, height: 90, borderRadius: '50%', background: theme.colors.hero, flexShrink: 0}} />
                <div style={{flex: 1}}><div style={{height: 22, borderRadius: 11, background: theme.colors.line, width: '85%'}} /><div style={{height: 22, borderRadius: 11, background: theme.colors.line, width: '55%', marginTop: 16}} /></div>
                <Mute size={90} fill={mute > 0.5 ? theme.colors.accentSoft : theme.colors.heroSoft} color={mute > 0.5 ? theme.colors.accent : theme.colors.text} />
              </div>
              <Chip style={{marginTop: 18, fontSize: 42}}>মন ভারী হয় যে পোস্টে → মিউট</Chip>
            </Card>
          </Enter>
        </div>
      </div>
      <Sfx at={at(34)} type="pop" />
      <Sfx at={at(34) + 8} type="whoosh" rate={0.95} vol={0.6} />
      <Sfx at={at(35) + 20} type="click" />
      <Sfx at={at(36) + 26} type="click" rate={0.92} vol={0.8} />
      <Sfx at={at(36) + 20} type="chime" vol={0.8} />
    </Stage>
  );
};

// ১৬ — ধাপ ২: গত বছরের তুমি → আজকের তুমি (cue 37–38)
export const Step2a: React.FC = () => {
  const {at} = useScene();
  const climb = useSpring(at(38), 'bouncy');
  return (
    <>
      <BlurBG src="images/floor-writing.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Enter delay={at(37)} dir="down" dist={24}><Chip dark>ধাপ ২</Chip></Enter>
            <Words text="নিজের সঙ্গে *নিজেকে* মেলাও" delay={at(37) + 6} per={6} size={96} />
            <div style={{display: 'flex', alignItems: 'flex-end', gap: 26, height: 340, marginTop: 14}}>
              <Enter delay={at(38)} dir="up" style={{flex: 1}}><Card style={{height: 170, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 48, textAlign: 'center', lineHeight: 1.3}}>গত বছরের তুমি</span></Card></Enter>
              <div style={{flex: 1, transform: `translateY(${(1 - climb) * 70}px)`, opacity: clamp01(climb)}}><Card dark style={{height: 290, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6, boxShadow: glow}}><span style={{...H, fontSize: 48, textAlign: 'center', lineHeight: 1.3}}>আজকের তুমি</span><span style={{...H, fontSize: 96}}>↑</span></Card></div>
            </div>
          </div>
          <Enter delay={at(37) - 4} dir="left" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/floor-writing.jpg" w={760} h={520} pos="55% 50%" zoomOut /></Enter>
        </div>
      </Stage>
      <Sfx at={at(37)} type="pop" />
      <Sfx at={at(38)} type="whoosh" vol={0.7} />
      <Sfx at={at(38) + 14} type="chime" vol={0.8} />
    </>
  );
};

// ১৭ — নতুন কিছু শেখা, অভ্যাস বদল, এগিয়ে যাওয়া (cue 39–41)
export const Step2b: React.FC = () => {
  const {at} = useScene();
  const tiles = [{src: 'images/study-books.jpg', t: 'নতুন কিছু শিখেছ?', d: at(39), pos: '50% 40%'}, {src: 'images/running.jpg', t: 'খারাপ অভ্যাস বদলেছ?', d: at(40), pos: '50% 40%'}, {src: 'images/drawing.jpg', t: 'এটাই এগিয়ে যাওয়া', d: at(41), pos: '50% 40%'}];
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 34}}>
        {tiles.map((t, i) => (
          <Enter key={t.t} delay={t.d} dir="up" cfg="bouncy" style={{flex: 1}}>
            <div style={{display: 'flex', flexDirection: 'column', gap: 20}}>
              <PhotoCard src={t.src} w={540} h={520} pos={t.pos} />
              <Card dark={i === 2} style={{padding: '22px 30px', textAlign: 'center', boxShadow: i === 2 ? glow : theme.shadow}}><span style={{...H, fontSize: 52}}>{t.t}</span></Card>
            </div>
          </Enter>
        ))}
      </div>
      {tiles.map((t, i) => <Sfx key={t.t} at={t.d} type="pop" rate={1 + i * 0.07} vol={0.8} />)}
      <Sfx at={at(41) + 6} type="chime" vol={0.8} />
    </Stage>
  );
};

// ১৮ — ধাপ ৩: ৩০ দিন, রোজ ৩০ মিনিট (cue 42–45)
export const Step3: React.FC = () => {
  const {at, len} = useScene();
  const span = len(44, 45) - 20;
  const R = 150, circ = 2 * Math.PI * R;
  const ring = useEase(at(44) + 6, 40, 'inOut');
  return (
    <>
      <BlurBG src="images/headphones.jpg" dim={0.66} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(42) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/headphones.jpg" w={560} h={560} pos="55% 40%" /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
            <Enter delay={at(42)} dir="down" dist={24}><Chip dark>ধাপ ৩</Chip></Enter>
            <Words text="৩০ দিনের *ছোট লক্ষ্য*" delay={at(42) + 6} per={6} size={92} />
            <Enter delay={at(43)} dir="left" dist={50}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 52, color: theme.colors.textDim}}>সব বদলাতে হবে না</div></Enter>
            <Enter delay={at(44)} dir="up" cfg="bouncy">
              <Card dark style={{display: 'flex', alignItems: 'center', gap: 30, padding: '20px 36px', boxShadow: glow}}>
                <div style={{position: 'relative', width: 180, height: 180}}>
                  <svg width={180} height={180} viewBox="0 0 340 340" style={{transform: 'rotate(-90deg)'}}><circle cx={170} cy={170} r={R} fill="none" stroke="rgba(16,20,27,0.25)" strokeWidth={34} /><circle cx={170} cy={170} r={R} fill="none" stroke={theme.colors.onHero} strokeWidth={34} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - 0.5 * ring)} /></svg>
                </div>
                <span style={{...H, fontSize: 56, lineHeight: 1.3}}>একটা দক্ষতা,<br />রোজ মাত্র ৩০ মিনিট</span>
              </Card>
            </Enter>
            <Card style={{padding: '18px 24px'}}>
              <div style={{display: 'grid', gridTemplateColumns: 'repeat(15, 1fr)', gap: 7}}>
                {Array.from({length: 30}).map((_, i) => {
                  const d = at(44) + 20 + Math.round((i * span) / 30);
                  const p = useSpring(d, 'snappy');
                  return <div key={i} style={{height: 34, borderRadius: 8, background: theme.colors.hero, opacity: 0.25 + clamp01(p) * 0.75, transform: `scale(${0.7 + p * 0.3})`}} />;
                })}
              </div>
            </Card>
            <Enter delay={at(45) + 10} dir="up" cfg="bouncy"><Chip style={{fontSize: 46}}>এক মাস পর ফারাকটা নিজেই দেখবে</Chip></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(42)} type="pop" />
      <Sfx at={at(44)} type="whoosh" vol={0.7} />
      <Sfx at={at(44) + 20 + Math.round(span * 0.9)} type="click" vol={0.6} />
      <Sfx at={at(45) + 10} type="chime" vol={0.8} />
    </>
  );
};

// ১৯ — খাতায় একটা লাইন: "আজ থেকে ৩০ মিনিট" (cue 46–48)
export const Notebook: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/notebook-30.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(46) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/notebook-30.jpg" w={820} h={670} pos="45% 55%" /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Enter delay={at(46)} dir="up"><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '22px 40px'}}><Repeat size={64} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 52}}>ফোন রেখে খাতা খুলল</span></Card></Enter>
            <Enter delay={at(47)} dir="up"><Chip style={{fontSize: 44}}>বড় কিছু লিখল না, শুধু একটা লাইন</Chip></Enter>
            <Enter delay={at(48)} dir="up" cfg="bouncy"><Card dark style={{padding: '34px 44px', boxShadow: glow}}><span style={{...H, fontSize: 84, lineHeight: 1.3}}>আজ থেকে ৩০ মিনিট</span></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(46)} type="pop" />
      <Sfx at={at(47)} type="whoosh" rate={0.95} vol={0.6} />
      <Sfx at={at(48)} type="click" />
      <Sfx at={at(48) + 6} type="chime" vol={0.8} />
    </>
  );
};

// ২০ — সে পিছিয়ে ছিল না (cue 49–50)
export const NotBehind: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/morning-curtain.jpg" pos="40% 50%" side="right" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', height: '100%', gap: 26, width: 1000}}>
          <Enter delay={at(49)} dir="left" dist={50}><div style={{...H, fontSize: 84, color: theme.colors.textDim}}>সে <Struck delay={at(49) + 30}>পিছিয়ে ছিল</Struck> না</div></Enter>
          <Words text="শুধু অন্যের পথে তাকিয়ে," delay={at(50)} per={5} size={66} weight={theme.weight.strong} color={theme.colors.textDim} />
          <Words text="*নিজের পথে* হাঁটা শুরু করেনি" delay={at(50) + 28} per={5} size={96} />
        </div>
      </Stage>
      <Sfx at={at(49)} type="pop" vol={0.8} />
      <Sfx at={at(49) + 30} type="click" />
      <Sfx at={at(50)} type="whoosh" rate={0.95} vol={0.6} />
      <Sfx at={at(50) + 28} type="chime" vol={0.8} />
    </PhotoBG>
  );
};

// ২১ — চাপ বেড়ে গেলে বিশ্বস্ত কারো সঙ্গে কথা বলো (cue 51)
export const Help: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/phone-call.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(51) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/phone-call.jpg" w={860} h={600} pos="62% 45%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Enter delay={at(51)} dir="down" dist={24}><Chip style={{fontSize: 42}}>চাপ এতটাই বাড়লে, কিছুই ভালো না লাগলে</Chip></Enter>
            <Words text="*বিশ্বস্ত কারো* সঙ্গে কথা বলো" delay={at(51) + 14} per={6} size={90} />
            <Enter delay={at(51) + 70} dir="up" cfg="bouncy"><Card dark style={{padding: '22px 44px', boxShadow: glow, display: 'inline-block'}}><span style={{...H, fontSize: 60}}><Struck delay={at(51) + 96}>দুর্বলতা</Struck> নয়</span></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(51)} type="pop" vol={0.7} />
      <Sfx at={at(51) + 70} type="chime" vol={0.8} />
      <Sfx at={at(51) + 96} type="click" vol={0.8} />
    </>
  );
};

// ২২ — কমেন্ট বক্স + তুমি একা নও (cue 52–53)
export const CommentBox: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const words = 'তোমার বয়স কত? কোন জায়গায় পিছিয়ে মনে হয়?'.split(' ');
  const start = at(52) + 30, per = 7;
  const shown = Math.max(0, Math.min(words.length, Math.floor((f - start) / per) + 1));
  const press = useEase(start + per * words.length + 6, 10, 'out');
  return (
    <>
      <BlurBG src="images/teaching.jpg" dim={0.68} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 30}}><Enter delay={at(52)} dir="down" dist={24}><Chip dark>নিচের কমেন্টে</Chip></Enter><Words text="লিখে *জানাও*" delay={at(52) + 6} per={7} size={84} /></div>
            <Enter delay={at(52) + 14} dir="up" cfg="bouncy">
              <Card style={{padding: '30px 34px'}}>
                <div style={{display: 'flex', gap: 24, alignItems: 'flex-start'}}>
                  <div style={{width: 84, height: 84, borderRadius: '50%', background: theme.colors.hero, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Person size={54} color={theme.colors.onHero} fill="transparent" /></div>
                  <div style={{flex: 1, minHeight: 190, borderRadius: 24, border: `3px solid ${theme.colors.line}`, background: theme.colors.bgAlt, padding: '20px 28px', ...H, fontWeight: theme.weight.strong, fontSize: 50, lineHeight: 1.5}}>
                    {words.slice(0, shown).join(' ')}<span style={{display: 'inline-block', width: 5, height: 52, background: theme.colors.hero, marginLeft: 8, verticalAlign: 'middle', opacity: f % 30 < 18 ? 1 : 0}} />
                  </div>
                </div>
                <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: 20}}><div style={{...H, fontSize: 42, padding: '10px 40px', borderRadius: 999, background: theme.colors.hero, color: theme.colors.onHero, transform: `scale(${1 - 0.06 * Math.sin(press * Math.PI)})`, boxShadow: press > 0.5 ? glow : 'none'}}>পাঠাও</div></div>
              </Card>
            </Enter>
          </div>
          <Enter delay={at(53) - 4} dir="left" dist={80} style={{flexShrink: 0}}>
            <div style={{display: 'flex', flexDirection: 'column', gap: 22, alignItems: 'center'}}>
              <PhotoCard src="images/teaching.jpg" w={560} h={460} pos="50% 40%" />
              <Enter delay={at(53)} dir="up" cfg="bouncy"><Card dark style={{padding: '16px 56px', boxShadow: glow}}><span style={{...H, fontSize: 72}}>তুমি একা নও</span></Card></Enter>
            </div>
          </Enter>
        </div>
      </Stage>
      <Sfx at={at(52)} type="pop" />
      <Sfx at={start + per * words.length + 6} type="click" />
      <Sfx at={at(53)} type="chime" />
    </>
  );
};

// ২৩ — সাবস্ক্রাইব + লোগো (cue 54)
export const Subscribe: React.FC = () => {
  const {at} = useScene();
  const press = useEase(at(54) + 56, 12, 'out');
  const done = press > 0.6;
  return (
    <>
      <BlurBG src="images/reading-rain.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 30}}>
            <Words text="এমন *বাস্তব কথা* শুনতে" delay={at(54)} per={6} size={96} />
            <Enter delay={at(54) + 30} dir="up" cfg="bouncy"><div style={{alignSelf: 'flex-start', ...H, fontSize: 66, padding: '20px 62px', borderRadius: 999, background: done ? theme.colors.heroSoft : theme.colors.hero, color: done ? theme.colors.text : theme.colors.onHero, transform: `scale(${1 - 0.07 * Math.sin(press * Math.PI)})`, boxShadow: done ? 'none' : glow, border: `3px solid ${theme.colors.hero}`, display: 'inline-block'}}>{done ? '✓ সাবস্ক্রাইবড' : 'সাবস্ক্রাইব'}</div></Enter>
          </div>
          <Enter delay={at(54) + 8} cfg="bouncy" from={0.6} float={5} style={{flexShrink: 0}}>
            <div style={{width: 560, height: 560, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 0 120px ${theme.colors.heroGlow}, ${theme.shadow}`}}><Img src={staticFile('logo.png')} style={{width: '100%', height: '100%', objectFit: 'cover'}} /></div>
          </Enter>
        </div>
      </Stage>
      <Sfx at={at(54) + 8} type="chime" />
      <Sfx at={at(54) + 56} type="click" />
    </>
  );
};

// ২৪ — সমাপ্তি (cue 55)
export const End: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const glw = 0.75 + Math.sin(f / 18) * 0.25;
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
        <Enter delay={at(55)} cfg="bouncy" from={0.55} float={4}>
          <div style={{width: 600, height: 600, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 0 ${150 * glw}px ${theme.colors.heroGlow}, ${theme.shadow}`}}><Img src={staticFile('logo.png')} style={{width: '100%', height: '100%', objectFit: 'cover'}} /></div>
        </Enter>
        <Words text="Better Mind, Bigger Life." delay={at(55) + 22} per={7} size={104} align="center" />
      </div>
      <Sfx at={at(55)} type="chime" />
      <Sfx at={at(55) + 22} type="pop" vol={0.7} />
    </Stage>
  );
};
