import {SceneDef} from '../scene';
import {ArifBed, Ceiling, Feed, ForYou, ForgetPath, HighlightReel, Hook, Iceberg, NotRace, OwnPath, Reaction, Unfair, WhereWrong} from './C1';
import {CommentBox, End, Help, Notebook, NotBehind, Step1, Step2a, Step2b, Step3, Subscribe, ThreeSteps} from './C2';

export const SCENES: SceneDef[] = [
  {id: 'hook', from: 1, to: 2, C: Hook},
  {id: 'whereWrong', from: 3, to: 3, C: WhereWrong},
  {id: 'forYou', from: 4, to: 5, C: ForYou},
  {id: 'arifBed', from: 6, to: 8, C: ArifBed},
  {id: 'feed', from: 9, to: 13, C: Feed},
  {id: 'reaction', from: 14, to: 15, C: Reaction},
  {id: 'ceiling', from: 16, to: 17, C: Ceiling},
  {id: 'unfair', from: 18, to: 19, C: Unfair},
  {id: 'iceberg', from: 20, to: 23, C: Iceberg},
  {id: 'highlightReel', from: 24, to: 26, C: HighlightReel},
  {id: 'notRace', from: 27, to: 28, C: NotRace},
  {id: 'ownPath', from: 29, to: 30, C: OwnPath},
  {id: 'forgetPath', from: 31, to: 31, C: ForgetPath},
  {id: 'threeSteps', from: 32, to: 33, C: ThreeSteps},
  {id: 'step1', from: 34, to: 36, C: Step1},
  {id: 'step2a', from: 37, to: 38, C: Step2a},
  {id: 'step2b', from: 39, to: 41, C: Step2b},
  {id: 'step3', from: 42, to: 45, C: Step3},
  {id: 'notebook', from: 46, to: 48, C: Notebook},
  {id: 'notBehind', from: 49, to: 50, C: NotBehind},
  {id: 'help', from: 51, to: 51, C: Help},
  {id: 'comment', from: 52, to: 53, C: CommentBox},
  {id: 'subscribe', from: 54, to: 54, C: Subscribe},
  {id: 'end', from: 55, to: 55, C: End},
];
