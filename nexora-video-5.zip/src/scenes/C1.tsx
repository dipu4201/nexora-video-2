import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Stage} from '../components/Ui';
import {Counter, DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Check, ClockIcon, Cross, Door, Doc, Flag, Heart, Lock, Moon, Person, Phone, Repeat, Sparkle, Scale} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {BlurBG, C, H, PhotoBG, PhotoCard, glow} from '../components/Kit';

const peach = `0 0 80px ${theme.colors.accentGlow}, ${theme.shadow}`;

// ১ — হুক: সবাই এগোচ্ছে, তুমি একই জায়গায় (cue 1–2)
export const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const chips = ['চাকরি', 'ব্যবসা', 'নতুন কিছু কেনা'].map((t, i) => ({t, d: at(2) + Math.round((i * len(2)) / 3)}));
  const pulse = 1 + Math.sin(f / 7) * 0.08;
  return (
    <Stage>
      <div style={{height: 460, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 6}}>
        <Words text="সবাই *এগিয়ে* যাচ্ছে" delay={at(1)} per={7} size={150} />
        <Words text="শুধু তুমি একই জায়গায়?" delay={at(1) + 30} per={6} size={96} weight={theme.weight.strong} color={theme.colors.textDim} />
      </div>
      <Enter delay={at(1) + 10} dir="up" style={{position: 'absolute', left: 110, right: 110, top: 520}}>
        <Card style={{height: 360, padding: 0, position: 'relative', overflow: 'hidden'}}>
          {[0, 1, 2, 3, 4].map((l) => {
            const you = l === 2;
            const speed = 3 + l * 1.4 + (l > 2 ? 1 : 0);
            const x = you ? 80 : 80 + Math.min(1500, Math.max(0, (f - at(1) - 20) * speed));
            return (
              <div key={l} style={{position: 'absolute', left: 0, right: 0, top: 24 + l * 68, height: 60}}>
                <div style={{position: 'absolute', left: 40, right: 40, top: 30, height: 3, background: theme.colors.line}} />
                <div style={{position: 'absolute', left: x, top: 0, width: 60, height: 60, borderRadius: '50%', background: you ? theme.colors.hero : theme.colors.textFaint, boxShadow: you ? `0 0 ${30 * pulse}px ${theme.colors.heroGlow}` : 'none', transform: you ? `scale(${pulse})` : 'none'}} />
                {you && <div style={{position: 'absolute', left: 160, top: 6, ...H, fontSize: 40, color: theme.colors.hero}}>তুমি</div>}
              </div>
            );
          })}
        </Card>
      </Enter>
      <div style={{position: 'absolute', left: 110, right: 110, bottom: 70, display: 'flex', gap: 24}}>
        {chips.map((c) => <Enter key={c.t} delay={c.d} dir="up" cfg="bouncy"><Chip style={{fontSize: 42}}>{c.t}</Chip></Enter>)}
      </div>
      <Sfx at={at(1)} type="whoosh" vol={0.7} />
      <Sfx at={at(1) + 30} type="pop" vol={0.7} />
      {chips.map((c, i) => <Sfx key={c.t} at={c.d} type="pop" rate={1 + i * 0.06} vol={0.7} />)}
    </Stage>
  );
};

// ২ — আমি কোথায় ভুল করলাম? (cue 3)
export const WhereWrong: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/monitor-fb.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(3) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/monitor-fb.jpg" w={700} h={570} pos="45% 45%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
            <Enter delay={at(3)} dir="down" dist={24}><Chip dark><Phone size={44} color={theme.colors.onHero} fill="transparent" /> ফোন হাতে ভাবছো</Chip></Enter>
            <Enter delay={at(3) + 12} dir="up" cfg="bouncy"><Card style={{padding: '36px 50px', borderRadius: 60}}><Words text="আমি কোথায় *ভুল* করলাম?" delay={at(3) + 18} per={6} size={96} /></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(3)} type="pop" vol={0.7} />
      <Sfx at={at(3) + 12} type="whoosh" rate={0.95} vol={0.7} />
    </>
  );
};

// ৩ — এই ভিডিও তোমার জন্য; শেষে একটা কথা (cue 4–5)
export const ForYou: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const fill = useEase(at(5) + 20, Math.max(40, len(5) - 30), 'inOut');
  return (
    <Stage style={C}>
      <Enter delay={at(4)} dir="down" dist={24}><Chip>যদি এমন লাগে</Chip></Enter>
      <div style={{marginTop: 24}}><Words text="এই ভিডিও *তোমার জন্য*" delay={at(4) + 6} per={7} size={130} /></div>
      <Enter delay={at(5)} dir="up" cfg="bouncy" style={{marginTop: 60}}>
        <Card style={{padding: '50px 60px', boxShadow: peach}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 36, marginBottom: 36}}>
            <Lock size={110} color={theme.colors.accent} />
            <span style={{...H, fontSize: 70, lineHeight: 1.3}}>শেষে এমন একটা কথা, যা আজ রাতের চিন্তা বদলে দিতে পারে</span>
          </div>
          <div style={{height: 24, borderRadius: 24, background: theme.colors.heroSoft, position: 'relative'}}>
            <div style={{width: `${fill * 100}%`, height: '100%', borderRadius: 24, background: theme.colors.hero}} />
            <div style={{position: 'absolute', right: -6, top: -18, width: 60, height: 60, borderRadius: '50%', background: theme.colors.accent, boxShadow: `0 0 ${30 + Math.sin(f / 6) * 10}px ${theme.colors.accentGlow}`, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Sparkle size={34} color={theme.colors.onHero} fill={theme.colors.onHero} /></div>
          </div>
        </Card>
      </Enter>
      <Sfx at={at(4)} type="pop" />
      <Sfx at={at(5)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(5) + 30} type="chime" vol={0.8} />
    </Stage>
  );
};

// ৪ — আরিফ, ২৪, রাত ১১টা, বিছানায় ফেসবুক (cue 6–8)
export const ArifBed: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/bed-phone.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <div style={{width: 800, display: 'flex', flexDirection: 'column', gap: 26, flexShrink: 0}}>
            <Enter delay={at(6)} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'baseline', gap: 26, padding: '16px 48px'}}><span style={{...H, fontSize: 84}}>আরিফের বয়স</span><Counter from={0} to={24} delay={at(6) + 10} dur={30} style={{...H, fontSize: 150, color: theme.colors.hero}} /></Card></Enter>
            <Enter delay={at(7)} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 28, padding: '22px 48px'}}><Moon size={90} fill={theme.colors.accent} /><span style={{...H, fontSize: 90}}>রাত ১১টা</span></Card></Enter>
            <Enter delay={at(8)} dir="right" dist={60} cfg="bouncy"><Card dark style={{display: 'flex', alignItems: 'center', gap: 28, padding: '22px 48px', boxShadow: glow}}><Phone size={84} color={theme.colors.onHero} fill="transparent" /><span style={{...H, fontSize: 62, lineHeight: 1.3}}>বিছানায় শুয়ে ফেসবুক স্ক্রল</span></Card></Enter>
          </div>
          <Enter delay={at(6) - 4} dir="left" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/bed-phone.jpg" w={800} h={660} pos="55% 50%" /></Enter>
        </div>
      </Stage>
      <Sfx at={at(6)} type="pop" vol={0.8} />
      <Sfx at={at(7)} type="pop" rate={0.92} vol={0.8} />
      <Sfx at={at(8)} type="whoosh" vol={0.7} />
    </>
  );
};

// ৫ — ফেসবুক ফিড: একের পর এক সাফল্যের পোস্ট (cue 9–13)
export const Feed: React.FC = () => {
  const {at} = useScene();
  const posts = [
    {t: 'বিদেশে চাকরি', d: at(10), icon: <Flag size={70} />},
    {t: 'নতুন বাইক', d: at(11), icon: <Sparkle size={70} />},
    {t: 'নিজের ব্যবসা', d: at(12), icon: <Door size={70} />},
    {t: 'বিয়ের ছবি', d: at(13), icon: <Heart size={70} />},
  ];
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <Enter delay={at(9) - 4} dir="up" cfg="bouncy" style={{flexShrink: 0}}>
          <Card style={{width: 520, height: 880, padding: 22, borderRadius: 70, overflow: 'hidden', position: 'relative'}}>
            <div style={{...H, fontSize: 52, color: theme.colors.hero, padding: '14px 20px'}}>ফেসবুক</div>
            <div style={{display: 'flex', flexDirection: 'column', gap: 20, marginTop: 6}}>
              {posts.map((p, i) => {
                const k = useSpring(p.d, 'bouncy');
                return (
                  <div key={p.t} style={{height: 180, borderRadius: 30, background: i % 2 ? theme.colors.heroSoft : theme.colors.accentSoft, display: 'flex', alignItems: 'center', gap: 22, padding: 24, opacity: clamp01(k * 1.5), transform: `translateY(${(1 - k) * 60}px)`}}>
                    <div style={{width: 90, height: 90, borderRadius: '50%', background: theme.colors.hero, opacity: 0.8, flexShrink: 0}} />
                    <div style={{flex: 1}}><div style={{height: 22, borderRadius: 11, background: theme.colors.line, width: '85%'}} /><div style={{height: 22, borderRadius: 11, background: theme.colors.line, width: '55%', marginTop: 16}} /></div>
                  </div>
                );
              })}
            </div>
          </Card>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
          <Enter delay={at(9)} dir="down" dist={24}><Chip dark>প্রথম পোস্ট—</Chip></Enter>
          {posts.map((p, i) => (
            <Enter key={p.t} delay={p.d} dir="right" dist={70} cfg="bouncy"><Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '22px 42px'}}>{p.icon}<span style={{...H, fontWeight: theme.weight.strong, fontSize: 62}}>{p.t}</span></Card></Enter>
          ))}
        </div>
      </div>
      <Sfx at={at(9)} type="pop" vol={0.7} />
      {posts.map((p, i) => <Sfx key={p.t} at={p.d} type="pop" rate={1 + i * 0.06} vol={0.8} />)}
    </Stage>
  );
};

// ৬ — লাইক, "অভিনন্দন ভাই" — মুখে হাসি, বুকে চাপ (cue 14–15)
export const Reaction: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const words = 'অভিনন্দন ভাই'.split(' ');
  const start = at(14) + 24, per = 14;
  const shown = Math.max(0, Math.min(words.length, Math.floor((f - start) / per) + 1));
  const press = useEase(at(15) + 14, Math.max(40, len(15) - 20), 'inOut');
  return (
    <Stage style={C}>
      <Enter delay={at(14)} dir="up" cfg="bouncy">
        <Card style={{padding: '34px 44px'}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 30}}>
            <Enter delay={at(14) + 6} cfg="bouncy" from={0.3}><Heart size={96} /></Enter>
            <div style={{flex: 1, borderRadius: 24, border: `3px solid ${theme.colors.line}`, background: theme.colors.bgAlt, padding: '20px 30px', ...H, fontWeight: theme.weight.strong, fontSize: 64, minHeight: 100}}>
              {words.slice(0, shown).join(' ')}<span style={{display: 'inline-block', width: 5, height: 60, background: theme.colors.hero, marginLeft: 8, verticalAlign: 'middle', opacity: f % 30 < 18 ? 1 : 0}} />
            </div>
          </div>
        </Card>
      </Enter>
      <div style={{display: 'flex', gap: 50, marginTop: 50}}>
        <Enter delay={at(15)} dir="right" dist={60} style={{flex: 1}}>
          <Card style={{height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>
            <svg width={200} height={200} viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill={theme.colors.accentSoft} stroke={theme.colors.text} strokeWidth="5" /><circle cx="37" cy="42" r="4.5" fill={theme.colors.text} /><circle cx="63" cy="42" r="4.5" fill={theme.colors.text} /><path d="M32 60 Q50 76 68 60" fill="none" stroke={theme.colors.text} strokeWidth="5" strokeLinecap="round" /></svg>
            <span style={{...H, fontSize: 76}}>মুখে হাসি</span>
          </Card>
        </Enter>
        <Enter delay={at(15) + 18} dir="left" dist={60} cfg="bouncy" style={{flex: 1}}>
          <Card dark style={{height: 400, padding: '36px 44px', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 26, boxShadow: glow}}>
            <span style={{...H, fontSize: 76}}>বুকের ভেতর চাপ</span>
            <div style={{height: 46, borderRadius: 46, background: 'rgba(16,20,27,0.3)', overflow: 'hidden'}}><div style={{width: `${10 + press * 82}%`, height: '100%', borderRadius: 46, background: theme.colors.onHero}} /></div>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(14)} type="pop" vol={0.8} />
      <Sfx at={at(14) + 30} type="click" />
      <Sfx at={at(15) + 18} type="thud" vol={0.6} />
    </Stage>
  );
};

// ৭ — সিলিংয়ের দিকে তাকিয়ে প্রশ্ন (cue 16–17)
export const Ceiling: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/blue-room.jpg" pos="45% 55%" side="left" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 30, width: 1100}}>
          <Enter delay={at(16)} dir="down" dist={24}><Chip>ফোন নামিয়ে সিলিংয়ের দিকে</Chip></Enter>
          <Words text="সবাই এতদূর চলে গেল," delay={at(17)} per={5} size={92} weight={theme.weight.strong} color={theme.colors.textDim} />
          <Words text="আর আমি এতদিন *কী করলাম?*" delay={at(17) + 32} per={6} size={120} />
        </div>
      </Stage>
      <Sfx at={at(16)} type="pop" vol={0.7} />
      <Sfx at={at(17)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(17) + 32} type="thud" vol={0.6} />
    </PhotoBG>
  );
};

// ৮ — অন্যের সেরা মুহূর্ত বনাম নিজের পুরো জীবন (cue 18–19)
export const Unfair: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Words text="আরিফ একটা *ভুল* করছিল" delay={at(18)} per={6} size={100} />
      <div style={{display: 'flex', alignItems: 'center', gap: 36, marginTop: 56}}>
        <Enter delay={at(19)} dir="right" dist={60}>
          <Card dark style={{width: 380, height: 380, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, boxShadow: glow}}><Sparkle size={130} color={theme.colors.onHero} fill={theme.colors.onHero} /><span style={{...H, fontSize: 54, textAlign: 'center', lineHeight: 1.3}}>অন্যের<br />সবচেয়ে সুন্দর মুহূর্ত</span></Card>
        </Enter>
        <Enter delay={at(19) + 24} cfg="bouncy" from={0.3}><div style={{width: 110, height: 110, borderRadius: '50%', background: theme.colors.accent, color: theme.colors.onHero, ...H, fontSize: 90, display: 'flex', alignItems: 'center', justifyContent: 'center', lineHeight: 1.2}}>≠</div></Enter>
        <Enter delay={at(19) + 40} dir="left" dist={60} style={{flex: 1}}>
          <Card style={{height: 380, padding: '40px 40px', display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 28}}>
            <div style={{display: 'flex', gap: 12}}>{Array.from({length: 11}).map((_, i) => <div key={i} style={{flex: 1, height: 120, borderRadius: 12, background: i % 3 ? theme.colors.heroSoft : theme.colors.accentSoft}} />)}</div>
            <span style={{...H, fontSize: 64}}>নিজের পুরো জীবন</span>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(18)} type="whoosh" vol={0.7} />
      <Sfx at={at(19)} type="pop" />
      <Sfx at={at(19) + 24} type="thud" vol={0.7} />
      <Sfx at={at(19) + 40} type="pop" rate={0.92} />
    </Stage>
  );
};

// ৯ — হিমশৈল: যা পোস্ট হয় না (cue 20–23)
export const Iceberg: React.FC = () => {
  const {at, len} = useScene();
  const water = 430;
  const hidden = ['কতবার ফেইল', 'ঘুমহীন রাত', 'দুশ্চিন্তা'].map((t, i) => ({t, d: at(22) + Math.round((i * len(22)) / 3)}));
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
        <Enter delay={at(20)} dir="up" style={{flexShrink: 0}}>
          <svg width={900} height={900} viewBox="0 0 900 900" style={{overflow: 'visible'}}>
            <rect x="0" y={water} width="900" height={470} fill={theme.colors.heroSoft} rx="30" />
            <path d="M0 430 L900 430" stroke={theme.colors.hero} strokeWidth="5" strokeDasharray="14 12" />
            <path d="M360 430 L450 250 L520 330 L560 430 Z" fill={theme.colors.text} opacity="0.95" />
            <path d="M300 430 L620 430 L560 700 L450 860 L330 720 Z" fill={theme.colors.hero} opacity="0.45" />
          </svg>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 20}}>
          <Enter delay={at(21)} dir="right" dist={60}><Card dark style={{padding: '22px 40px', boxShadow: glow}}><span style={{...H, fontSize: 56}}>পোস্ট: চাকরির খবর</span></Card></Enter>
          <Enter delay={at(22) - 6} dir="down" dist={20}><Chip style={{fontSize: 42}}>পানির নিচে, যা পোস্ট হয়নি</Chip></Enter>
          {hidden.map((h) => <Enter key={h.t} delay={h.d} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '18px 38px'}}><Cross size={52} color={theme.colors.accent} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 54}}>{h.t}</span></Card></Enter>)}
          <Enter delay={at(23)} dir="up" cfg="bouncy"><Chip dark style={{fontSize: 54, padding: '12px 46px'}}>না, কেউ করে না</Chip></Enter>
        </div>
      </div>
      <Sfx at={at(20)} type="whoosh" vol={0.6} />
      <Sfx at={at(21)} type="pop" />
      {hidden.map((h, i) => <Sfx key={h.t} at={h.d} type="thud" rate={1.1 - i * 0.08} vol={0.5} />)}
      <Sfx at={at(23)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ১০ — সবার সেরা মুহূর্ত বনাম তোমার ভেতরের সব (cue 24–26)
export const HighlightReel: React.FC = () => {
  const {at, len} = useScene();
  const inner = ['সন্দেহ', 'ক্লান্তি', 'ব্যর্থতা'].map((t, i) => ({t, d: at(25) + Math.round((i * len(25)) / 3)}));
  const stamp = useSpring(at(26), 'bouncy');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <Enter delay={at(24)} dir="right" dist={60} style={{width: 700, flexShrink: 0}}>
          <Card style={{padding: 30}}>
            <div style={{display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14}}>{Array.from({length: 9}).map((_, i) => <div key={i} style={{height: 130, borderRadius: 18, background: i % 2 ? theme.colors.accentSoft : theme.colors.heroSoft, border: `2px solid ${theme.colors.line}`}} />)}</div>
            <div style={{...H, fontSize: 52, marginTop: 24, textAlign: 'center'}}>সবার <span style={{color: theme.colors.accent}}>সেরা মুহূর্তের</span> সংগ্রহ</div>
          </Card>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 20, position: 'relative'}}>
          <Enter delay={at(25) - 6} dir="down" dist={20}><Chip dark style={{fontSize: 44}}>তোমার ভেতরের সব</Chip></Enter>
          {inner.map((h) => <Enter key={h.t} delay={h.d} dir="left" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '22px 42px'}}><Cross size={54} /><span style={{...H, fontSize: 64}}>{h.t}</span></Card></Enter>)}
          <div style={{position: 'absolute', right: -10, top: 150, transform: `rotate(-9deg) scale(${stamp})`, opacity: clamp01(stamp)}}><div style={{...H, fontSize: 74, padding: '8px 36px', border: `7px solid ${theme.colors.accent}`, color: theme.colors.accent, borderRadius: 18, background: `${theme.colors.bg}E0`}}>অন্যায্য তুলনা</div></div>
        </div>
      </div>
      <Sfx at={at(24)} type="pop" />
      {inner.map((h, i) => <Sfx key={h.t} at={h.d} type="pop" rate={0.95 + i * 0.06} vol={0.7} />)}
      <Sfx at={at(26)} type="thud" />
    </Stage>
  );
};

// ১১ — জীবন কোনো দৌড় নয় (cue 27–28)
export const NotRace: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const cross = useEase(at(28) + 40, 16, 'out');
  return (
    <Stage style={C}>
      <Words text="জীবন কোনো *দৌড়* নয়" delay={at(27)} per={7} size={130} />
      <Enter delay={at(28)} dir="up" style={{marginTop: 50}}>
        <Card style={{padding: '40px 50px', position: 'relative'}}>
          {[0, 1, 2, 3].map((l) => (
            <div key={l} style={{position: 'relative', height: 70, borderBottom: `3px dashed ${theme.colors.line}`}}>
              <div style={{position: 'absolute', left: 30, top: 8, width: 54, height: 54, borderRadius: '50%', background: l === 1 ? theme.colors.hero : theme.colors.textFaint}} />
            </div>
          ))}
          <div style={{position: 'absolute', right: 80, top: 20, bottom: 20, width: 12, background: `repeating-linear-gradient(0deg, ${theme.colors.text} 0 20px, ${theme.colors.bg} 20px 40px)`, borderRadius: 4}} />
          <div style={{position: 'absolute', left: 14, top: 20, bottom: 20, width: 4, background: theme.colors.accent}} />
          <div style={{position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', opacity: cross}}><Cross size={300} color={theme.colors.accent} sw={8} /></div>
        </Card>
      </Enter>
      <div style={{display: 'flex', gap: 24, marginTop: 36}}>
        <Enter delay={at(28) + 10} dir="up"><Chip style={{fontSize: 44}}>সবাই এক লাইনে</Chip></Enter>
        <Enter delay={at(28) + 24} dir="up"><Chip style={{fontSize: 44}}>ফিনিশ লাইন একটা</Chip></Enter>
      </div>
      <Sfx at={at(27)} type="whoosh" vol={0.7} />
      <Sfx at={at(28) + 10} type="pop" />
      <Sfx at={at(28) + 40} type="thud" vol={0.7} />
    </Stage>
  );
};

// ১২ — আলাদা শুরু, পথ, সময় (cue 29–30)
export const OwnPath: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const paths = [
    {d: 'M60 330 C 260 330, 380 120, 700 150', c: theme.colors.textFaint, t: 0},
    {d: 'M60 420 C 300 420, 520 380, 780 300', c: theme.colors.accent, t: 14},
    {d: 'M60 220 C 240 200, 420 280, 640 260', c: theme.colors.textFaint, t: 28},
  ];
  const keys = [{t: 'শুরুর জায়গা আলাদা', d: at(29)}, {t: 'পথ আলাদা', d: at(29) + 40}, {t: 'সময়ও আলাদা', d: at(29) + 80}];
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
          {keys.map((k) => <Enter key={k.t} delay={k.d} dir="right" dist={60}><Card style={{padding: '24px 44px'}}><span style={{...H, fontSize: 64}}>{k.t}</span></Card></Enter>)}
          <Enter delay={at(30)} dir="up" cfg="bouncy"><Card dark style={{padding: '26px 44px', boxShadow: glow}}><span style={{...H, fontSize: 60, lineHeight: 1.3}}>কেউ আগে পৌঁছায়, কেউ ঠিক সময়ে</span></Card></Enter>
        </div>
        <Enter delay={at(29)} dir="left" dist={60} style={{width: 860, flexShrink: 0}}>
          <Card style={{padding: 26}}>
            <svg width={800} height={500} viewBox="0 0 840 520" style={{overflow: 'visible'}}>
              {paths.map((p, i) => <DrawPath key={i} d={p.d} delay={at(29) + 10 + p.t} dur={50} color={p.c} width={i === 1 ? 11 : 8} />)}
              {[[60, 330], [60, 420], [60, 220]].map((c, i) => <circle key={i} cx={c[0]} cy={c[1]} r={14} fill={i === 1 ? theme.colors.accent : theme.colors.textDim} />)}
            </svg>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(29)} type="whoosh" vol={0.6} />
      {keys.map((k, i) => <Sfx key={k.t} at={k.d} type="pop" rate={1 + i * 0.06} vol={0.7} />)}
      <Sfx at={at(30)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ১৩ — অন্যের রাস্তায় তাকিয়ে নিজের রাস্তা ভুলে যাওয়া (cue 31)
export const ForgetPath: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/reading-rain.jpg" pos="62% 50%" side="left" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 28, width: 1050}}>
          <Words text="পিছিয়ে আছো মনে হয়," delay={at(31)} per={5} size={90} weight={theme.weight.strong} color={theme.colors.textDim} />
          <Words text="যখন অন্যের রাস্তায় তাকিয়ে" delay={at(31) + 30} per={5} size={90} />
          <Words text="*নিজের রাস্তা* ভুলে যাও" delay={at(31) + 64} per={6} size={120} />
        </div>
      </Stage>
      <Sfx at={at(31)} type="whoosh" rate={0.9} vol={0.6} />
      <Sfx at={at(31) + 64} type="chime" vol={0.8} />
    </PhotoBG>
  );
};
