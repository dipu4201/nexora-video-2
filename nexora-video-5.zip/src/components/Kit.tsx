import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from './Ui';
import {Enter, Words} from './Motion';

export const H: React.CSSProperties = {fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, letterSpacing: 0};
export const C: React.CSSProperties = {justifyContent: 'center'};
export const glow = `0 0 90px ${theme.colors.heroGlow}, ${theme.shadow}`;

// পূর্ণ-পর্দা ছবি + পাঠ্যের পাশে গাঢ় গ্রেডিয়েন্ট
export const PhotoBG: React.FC<{src: string; pos?: string; zoomOut?: boolean; side?: 'left' | 'right' | 'full'; panX?: number; children?: React.ReactNode}> = ({
  src, pos = 'center', zoomOut, side = 'left', panX, children,
}) => {
  const g = side === 'left' ? `linear-gradient(90deg, ${theme.colors.bg}F2 0%, ${theme.colors.bg}B8 45%, transparent 88%)`
    : side === 'right' ? `linear-gradient(270deg, ${theme.colors.bg}F2 0%, ${theme.colors.bg}B8 45%, transparent 88%)`
    : `linear-gradient(180deg, ${theme.colors.bg}99, ${theme.colors.bg}CC)`;
  return (
    <AbsoluteFill>
      <Photo src={src} radius={0} pos={pos} zoomOut={zoomOut} panX={panX} style={{position: 'absolute', inset: 0, boxShadow: 'none', border: 'none'}} />
      <AbsoluteFill style={{background: g}} />
      {children}
    </AbsoluteFill>
  );
};

// উক্তির কার্ড: ছবি + বাংলা অনুবাদ (cue a: প্রসঙ্গ, cue b: উক্তি)
export const QuoteScene: React.FC<{img: string; w: number; h: number; a: number; b: number; chip: string; bn: string}> = ({img, w, h, a, b, chip, bn}) => {
  const {at} = useScene();
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <Enter delay={at(a) - 2} dir="right" dist={70} cfg="bouncy" style={{flexShrink: 0}}>
          <Card style={{padding: 14, borderRadius: 40, boxShadow: glow, overflow: 'hidden'}}>
            <Img src={staticFile(img)} style={{width: w, height: h, borderRadius: 28, objectFit: 'cover', display: 'block'}} />
          </Card>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Enter delay={at(a)} dir="down" dist={24}><Chip dark>{chip}</Chip></Enter>
          <Enter delay={at(b)} dir="up"><div style={{...H, fontSize: 150, lineHeight: 0.8, color: theme.colors.hero}}>“</div></Enter>
          <Words text={bn} delay={at(b) + 6} per={4} size={78} />
        </div>
      </div>
    </Stage>
  );
};

// ছোট রেজোলিউশনের ছবির জন্য: ঝাপসা ব্যাকগ্রাউন্ড (পূর্ণ-পর্দা) + তীক্ষ্ণ কার্ড আলাদা করে বসানো হয়
export const BlurBG: React.FC<{src: string; dim?: number}> = ({src, dim = 0.62}) => (
  <AbsoluteFill>
    <Img src={staticFile(src)} style={{width: '100%', height: '100%', objectFit: 'cover', filter: 'blur(38px) brightness(0.5) saturate(1.1)', transform: 'scale(1.25)'}} />
    <AbsoluteFill style={{background: `${theme.colors.bg}${Math.round(dim * 255).toString(16).padStart(2, '0')}`}} />
  </AbsoluteFill>
);

// হলুদ কোণা-বন্ধনী (গেম-HUD ধাঁচ)
export const Brackets: React.FC<{c?: string; s?: number; t?: number}> = ({c = theme.colors.hero, s = 46, t = 6}) => {
  const b = (pos: React.CSSProperties) => <div style={{position: 'absolute', width: s, height: s, ...pos}} />;
  return (
    <>
      {b({left: 14, top: 14, borderLeft: `${t}px solid ${c}`, borderTop: `${t}px solid ${c}`})}
      {b({right: 14, top: 14, borderRight: `${t}px solid ${c}`, borderTop: `${t}px solid ${c}`})}
      {b({left: 14, bottom: 14, borderLeft: `${t}px solid ${c}`, borderBottom: `${t}px solid ${c}`})}
      {b({right: 14, bottom: 14, borderRight: `${t}px solid ${c}`, borderBottom: `${t}px solid ${c}`})}
    </>
  );
};

// ছবির কার্ড: Ken Burns + HUD ব্র্যাকেট
export const PhotoCard: React.FC<{src: string; w: number; h: number; pos?: string; zoomOut?: boolean}> = ({src, w, h, pos = 'center', zoomOut}) => (
  <div style={{position: 'relative', width: w, height: h}}>
    <Photo src={src} w={w} h={h} pos={pos} zoomOut={zoomOut} />
    <Brackets />
  </div>
);

// দ্রুত ফ্ল্যাশ (প্যাটার্ন-ইন্টারাপ্ট)
export const Flash: React.FC<{at: number; color?: string}> = ({at, color = theme.colors.hero}) => {
  const f = useCurrentFrame();
  const o = f >= at && f < at + 7 ? 0.55 * (1 - (f - at) / 7) : 0;
  return <AbsoluteFill style={{background: color, opacity: o, mixBlendMode: 'screen', pointerEvents: 'none'}} />;
};
