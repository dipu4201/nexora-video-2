import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Stage} from '../components/Ui';
import {DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Check, Cross, Doc, Mountain, Phone, Pill, Play, Repeat, Shield, Sparkle, Flag} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {C, H, glow, glowA} from './E';

// চার কারণের ট্র্যাকার (উপরে ডানে)
const Dots: React.FC<{i: number; d: number}> = ({i, d}) => (
  <Enter delay={d} dir="down" dist={24} style={{position: 'absolute', right: 110, top: 80, display: 'flex', gap: 16}}>
    {[0, 1, 2, 3].map((k) => <div key={k} style={{width: k === i ? 70 : 26, height: 26, borderRadius: 26, background: k === i ? theme.colors.accent : theme.colors.line}} />)}
  </Enter>
);
const Badge: React.FC<{n: number; d: number}> = ({n, d}) => (
  <Enter delay={d} cfg="bouncy" from={0.4}>
    <div style={{width: 150, height: 150, borderRadius: '50%', background: theme.colors.hero, boxShadow: glow, display: 'flex', alignItems: 'center', justifyContent: 'center', ...H, fontSize: 100, color: theme.colors.onHero, lineHeight: 1.2}}>{toBn(n)}</div>
  </Enter>
);

// ১৩ — কারণ ১: কাজটা অস্পষ্ট (cue 19–20)
export const Reason1: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const sink = useEase(at(20) + 8, 30, 'inOut');
  const q = Math.sin(f / 8) * 8;
  return (
    <Stage>
      <Dots i={0} d={at(19)} />
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Badge n={1} d={at(19)} />
          <Words text="কাজটা *অস্পষ্ট*" delay={at(19) + 8} per={7} size={124} />
          <Enter delay={at(19) + 150} dir="up"><Chip style={{fontSize: 46}}>কোথা থেকে শুরু?</Chip></Enter>
        </div>
        <div style={{width: 780, flexShrink: 0, position: 'relative', height: 640}}>
          <div style={{position: 'absolute', left: 0, right: 0, top: 40 + sink * 90}}>
            <Enter delay={at(19) + 14} dir="left" dist={60}>
              <Card style={{padding: '60px 50px', textAlign: 'center'}}>
                <div style={{...H, fontSize: 86, filter: `blur(${interpolate(sink, [0, 1], [9, 13])}px)`, opacity: 0.9}}>প্রজেক্ট শেষ করতে হবে</div>
              </Card>
            </Enter>
          </div>
          <Enter delay={at(19) + 60} cfg="bouncy" from={0.3} style={{position: 'absolute', right: 20, top: 10 + q}}>
            <span style={{...H, fontSize: 200, color: theme.colors.accent}}>?</span>
          </Enter>
          <Enter delay={at(20)} dir="up" cfg="bouncy" style={{position: 'absolute', left: 0, right: 0, bottom: 0}}>
            <Card dark style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 26, padding: '28px 40px', boxShadow: glow}}>
              <span style={{...H, fontSize: 70}}>অস্পষ্ট কাজ = ভারী কাজ</span>
            </Card>
          </Enter>
        </div>
      </div>
      <Sfx at={at(19)} type="pop" />
      <Sfx at={at(19) + 14} type="whoosh" vol={0.7} />
      <Sfx at={at(20)} type="thud" vol={0.7} />
    </Stage>
  );
};

// ১৪ — কারণ ২: ভুল হওয়ার ভয় (cue 21–22)
export const Reason2: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage>
      <Dots i={1} d={at(21)} />
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Badge n={2} d={at(21)} />
          <Words text="ভুল হওয়ার *ভয়*" delay={at(21) + 8} per={7} size={124} />
          <Enter delay={at(21) + 40} dir="up"><Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '20px 36px', alignSelf: 'flex-start'}}><Sparkle size={64} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>সবকিছু নিখুঁত হোক</span></Card></Enter>
        </div>
        <div style={{width: 780, flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 34}}>
          <Enter delay={at(21) + 80} cfg="bouncy" from={0.5}>
            <Card dark style={{display: 'flex', alignItems: 'center', gap: 30, padding: '36px 56px', boxShadow: glow}}><Shield size={130} fill={theme.colors.bg} /><span style={{...H, fontSize: 82}}>শুরু না করাই নিরাপদ</span></Card>
          </Enter>
          <Enter delay={at(22)} dir="up" cfg="bouncy">
            <Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '32px 50px'}}>
              <Doc size={110} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>শুরু না করলে <span style={{color: theme.colors.accent}}>ভুলও হয় না</span></span>
            </Card>
          </Enter>
        </div>
      </div>
      <Sfx at={at(21)} type="pop" />
      <Sfx at={at(21) + 40} type="pop" rate={0.95} vol={0.75} />
      <Sfx at={at(21) + 80} type="chime" vol={0.8} />
      <Sfx at={at(22)} type="pop" rate={1.08} />
    </Stage>
  );
};

// ১৫ — কারণ ৩: কঠিন বনাম সহজ-মজার (cue 23)
export const Reason3: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const d2 = at(23) + Math.round(len(23) * 0.3), d3 = at(23) + Math.round(len(23) * 0.62);
  const pull = Math.sin(f / 6) * 14;
  return (
    <Stage>
      <Dots i={2} d={at(23)} />
      <div style={{display: 'flex', alignItems: 'center', gap: 40, marginTop: 20}}>
        <Badge n={3} d={at(23)} />
        <Words text="বিরক্তিকর বা *কঠিন*" delay={at(23) + 8} per={6} size={100} />
      </div>
      <div style={{display: 'flex', gap: 56, marginTop: 56, alignItems: 'center'}}>
        <Enter delay={d2 - 20} dir="right" dist={60} style={{flex: 1}}>
          <Card style={{height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24, opacity: 0.8}}><Mountain size={190} /><span style={{...H, fontSize: 70, color: theme.colors.textDim}}>কঠিন কাজ</span></Card>
        </Enter>
        <Enter delay={d3} dir="left" cfg="bouncy" style={{flexShrink: 0}}>
          <span style={{...H, fontSize: 100, color: theme.colors.accent, display: 'inline-block', transform: `translateX(${pull}px)`}}>→</span>
        </Enter>
        <Enter delay={d2} dir="left" dist={60} cfg="bouncy" style={{flex: 1}}>
          <Card dark style={{height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24, boxShadow: glow}}><Play size={170} color={theme.colors.onHero} fill={theme.colors.onHero} /><span style={{...H, fontSize: 70}}>সহজ আর মজার</span></Card>
        </Enter>
      </div>
      <Enter delay={d3 + 14} dir="up" style={{marginTop: 40, alignSelf: 'center'}}><Chip style={{fontSize: 46}}>মন তখন এটাই খোঁজে</Chip></Enter>
      <Sfx at={at(23)} type="pop" />
      <Sfx at={d2} type="pop" rate={1.06} />
      <Sfx at={d3} type="whoosh" vol={0.7} />
    </Stage>
  );
};

// ১৬ — কারণ ৪: তাৎক্ষণিক আনন্দের টান — এখুনি বনাম অনেক পরে (cue 24)
export const Reason4: React.FC = () => {
  const {at, len} = useScene();
  const run = useEase(at(24) + Math.round(len(24) * 0.45), 60, 'inOut');
  return (
    <Stage>
      <Dots i={3} d={at(24)} />
      <div style={{display: 'flex', alignItems: 'center', gap: 40, marginTop: 20}}>
        <Badge n={4} d={at(24)} />
        <Words text="তাৎক্ষণিক *আনন্দের টান*" delay={at(24) + 8} per={6} size={96} />
      </div>
      <Enter delay={at(24) + 24} dir="up" style={{marginTop: 70}}>
        <Card style={{padding: '60px 70px', position: 'relative', height: 420}}>
          <svg width={1560} height={300} viewBox="0 0 1560 300" style={{overflow: 'visible'}}>
            <path d="M120 150 L1440 150" stroke={theme.colors.line} strokeWidth={8} strokeDasharray="6 22" strokeLinecap="round" />
            <circle cx={120} cy={150} r={64} fill={theme.colors.accent} />
            <circle cx={1440} cy={150} r={64} fill={theme.colors.hero} opacity={0.5 + run * 0.5} />
            <circle cx={120 + 1320 * run} cy={150} r={20} fill={theme.colors.text} opacity={clamp01(run * 20)} />
          </svg>
          <div style={{position: 'absolute', left: 70, top: 56}}><Enter delay={at(24) + 40}><Chip dark style={{fontSize: 46}}><Phone size={50} color={theme.colors.onHero} /> এখুনি আনন্দ</Chip></Enter></div>
          <div style={{position: 'absolute', right: 70, top: 56}}><Enter delay={at(24) + Math.round(len(24) * 0.6)}><Chip style={{fontSize: 46}}><Flag size={50} /> কাজের ফল, অনেক পরে</Chip></Enter></div>
        </Card>
      </Enter>
      <Sfx at={at(24)} type="pop" />
      <Sfx at={at(24) + 40} type="click" />
      <Sfx at={at(24) + Math.round(len(24) * 0.6)} type="pop" rate={0.9} />
    </Stage>
  );
};

// ১৭ — তোমার ক্ষেত্রে কোনটা? রোগ না জানলে ওষুধ ঠিক হয় না (cue 25)
export const WhichOne: React.FC = () => {
  const {at, len} = useScene();
  const labels = ['অস্পষ্ট কাজ', 'ভুলের ভয়', 'কঠিন লাগা', 'তাৎক্ষণিক আনন্দ'];
  const f = useCurrentFrame();
  const spot = Math.floor(Math.max(0, f - at(25) - 40) / 30) % 4;
  return (
    <Stage style={C}>
      <Words text="তোমার ক্ষেত্রে *কোনটা* বেশি সত্য?" delay={at(25)} per={5} size={92} />
      <div style={{display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 30, marginTop: 56}}>
        {labels.map((l, i) => (
          <Enter key={l} delay={at(25) + 22 + i * 8} dir="up" cfg="bouncy">
            <Card dark={f > at(25) + 40 && spot === i} style={{height: 270, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, boxShadow: f > at(25) + 40 && spot === i ? glow : theme.shadow}}>
              <span style={{...H, fontSize: 90, color: f > at(25) + 40 && spot === i ? theme.colors.onHero : theme.colors.accent}}>{toBn(i + 1)}</span>
              <span style={{...H, fontWeight: theme.weight.strong, fontSize: 50, textAlign: 'center', lineHeight: 1.3}}>{l}</span>
            </Card>
          </Enter>
        ))}
      </div>
      <Enter delay={at(25) + Math.round(len(25) * 0.55)} dir="up" style={{marginTop: 56, alignSelf: 'center'}}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 34, padding: '26px 54px'}}><Pill size={110} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>রোগ না জানলে <span style={{color: theme.colors.accent}}>ওষুধ ঠিক হয় না</span></span></Card>
      </Enter>
      <Sfx at={at(25)} type="whoosh" vol={0.7} />
      <Sfx at={at(25) + 22} type="pop" />
      <Sfx at={at(25) + Math.round(len(25) * 0.55)} type="pop" rate={1.06} />
    </Stage>
  );
};

// ১৮ — Process loop: স্বস্তি → অপরাধবোধ → চাপ → আবার ফেলে রাখা (cue 26–28)
export const Cycle: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const cx = 960, cy = 520, rx = 560, ry = 300;
  const t3 = (i: number) => at(26) + Math.round((i * len(26)) / 3);
  const nodes = [
    {t: 'সাময়িক স্বস্তি', x: cx, y: cy - ry, d: t3(0)},
    {t: 'অপরাধবোধ', x: cx + rx, y: cy, d: t3(1)},
    {t: 'সময়ের চাপ', x: cx, y: cy + ry, d: t3(2)},
    {t: 'আবার ফেলে রাখা', x: cx - rx, y: cy, d: at(27)},
  ];
  const ring = `M${cx} ${cy - ry} A${rx} ${ry} 0 0 1 ${cx + rx} ${cy} A${rx} ${ry} 0 0 1 ${cx} ${cy + ry} A${rx} ${ry} 0 0 1 ${cx - rx} ${cy} A${rx} ${ry} 0 0 1 ${cx} ${cy - ry}`;
  const tight = useEase(at(28), 24, 'out');
  const ang = (f / 80) * Math.PI * 2 - Math.PI / 2;
  return (
    <Stage pad={0}>
      <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
        <DrawPath d={ring} delay={at(26)} dur={Math.max(60, len(26, 27) - 10)} color={tight > 0.5 ? theme.colors.accent : theme.colors.line} width={10 + tight * 10} />
        <circle cx={cx + Math.cos(ang) * rx} cy={cy + Math.sin(ang) * ry} r={14} fill={theme.colors.accent} opacity={useEase(at(27), 10)} />
      </svg>
      {nodes.map((n, i) => (
        <div key={n.t} style={{position: 'absolute', left: n.x - 200, top: n.y - 62, width: 400}}>
          <Enter delay={n.d} cfg="bouncy" from={0.8}>
            <Card dark={i === 3} style={{height: 124, padding: '0 24px', display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: i === 3 ? glow : theme.shadow}}>
              <span style={{...H, fontSize: 52}}>{n.t}</span>
            </Card>
          </Enter>
        </div>
      ))}
      <div style={{position: 'absolute', left: 0, right: 0, top: cy - 90, display: 'flex', justifyContent: 'center'}}>
        <Words text="*চক্র*" delay={at(27) + 8} per={8} size={150} align="center" />
      </div>
      <div style={{position: 'absolute', left: 0, right: 0, top: cy + 90, display: 'flex', justifyContent: 'center'}}>
        <Enter delay={at(28)} dir="up"><Chip dark style={{fontSize: 46, padding: '12px 38px'}}>নিজেকে দোষ দিলে চক্র শক্ত</Chip></Enter>
      </div>
      {nodes.map((n, i) => <Sfx key={n.t} at={n.d} type="pop" rate={1 + i * 0.05} vol={0.75} />)}
      <Sfx at={at(27) + 8} type="chime" vol={0.8} />
      <Sfx at={at(28)} type="thud" vol={0.7} />
    </Stage>
  );
};

// ১৯ — 3D carousel-ধাঁচ: চারটি ছোট কাজ (cue 29)
export const FourSteps: React.FC = () => {
  const {at, len} = useScene();
  const steps = ['অনুভূতির নাম দাও', 'কাজ হাস্যকর ছোট করো', 'পাঁচ মিনিটের নিয়ম', 'প্রলোভন দূরে সরাও'];
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 40}}>
        <Words text="চারটি *ছোট কাজ*" delay={at(29)} per={7} size={120} />
        <Enter delay={at(29) + 40} dir="up"><Chip style={{fontSize: 44}}>কোনোটাই জাদু নয়</Chip></Enter>
      </div>
      <div style={{display: 'flex', gap: 30, marginTop: 56, perspective: 1600}}>
        {steps.map((s, i) => {
          const d = at(29) + 24 + Math.round((i * (len(29) - 30)) / 4);
          const p = useSpring(d, 'smooth');
          return (
            <div key={s} style={{flex: 1, opacity: clamp01(p * 1.5), transform: `rotateY(${(1 - p) * (i - 1.5) * -28}deg) translateY(${(1 - p) * 60}px) scale(${0.9 + p * 0.1})`}}>
              <Card dark={i === 0} style={{height: 420, display: 'flex', flexDirection: 'column', justifyContent: 'space-between', boxShadow: i === 0 ? glow : theme.shadow}}>
                <span style={{...H, fontSize: 130, lineHeight: 1.1, color: i === 0 ? theme.colors.accent : theme.colors.accent}}>{toBn(i + 1)}</span>
                <span style={{...H, fontSize: 54, lineHeight: 1.4}}>{s}</span>
              </Card>
            </div>
          );
        })}
      </div>
      <Sfx at={at(29)} type="whoosh" />
      {steps.map((s, i) => <Sfx key={s} at={at(29) + 24 + Math.round((i * (len(29) - 30)) / 4)} type="pop" rate={1 + i * 0.05} vol={0.75} />)}
    </Stage>
  );
};

// ২০ — ধাপ ১: অনুভূতির নাম দাও (cue 30–32)
export const Step1: React.FC = () => {
  const {at, len} = useScene();
  const g = useEase(at(32) + 6, Math.max(40, len(32) - 30), 'inOut');
  const tag = useSpring(at(31), 'bouncy');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{width: 760, display: 'flex', flexDirection: 'column', gap: 30, flexShrink: 0}}>
          <Enter delay={at(30)} dir="down" dist={24}><Chip dark>প্রথম ধাপ</Chip></Enter>
          <Words text="অনুভূতির *নাম দাও*" delay={at(30) + 6} per={7} size={118} />
          <Enter delay={at(30) + 60} dir="up"><Chip style={{fontSize: 44}}>যখন পালিয়ে যেতে ইচ্ছা করত</Chip></Enter>
        </div>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 30}}>
          <Enter delay={at(31)} dir="left" dist={60} cfg="bouncy">
            <Card style={{display: 'flex', alignItems: 'center', gap: 36, padding: '34px 44px'}}>
              <div style={{position: 'relative'}}>
                <svg width={170} height={140} viewBox="0 0 100 80"><path d="M28 62 C14 62 12 44 26 40 C26 24 48 20 56 34 C70 28 84 40 78 56 C90 60 88 74 74 74 L30 74" fill={theme.colors.heroSoft} stroke={theme.colors.text} strokeWidth={5} strokeLinecap="round" strokeLinejoin="round" /></svg>
                <div style={{position: 'absolute', left: 30, top: 70, transform: `scale(${tag}) rotate(-6deg)`, background: theme.colors.accent, color: theme.colors.bg, padding: '2px 22px', borderRadius: 14, ...H, fontSize: 44}}>দুশ্চিন্তা</div>
              </div>
              <div style={{...H, fontWeight: theme.weight.strong, fontSize: 56, lineHeight: 1.4}}>“আমি এখন <span style={{color: theme.colors.accent}}>দুশ্চিন্তা</span> অনুভব করছি।”</div>
            </Card>
          </Enter>
          <Enter delay={at(32)} dir="up">
            <Card style={{padding: '30px 44px'}}>
              <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20}}>
                <span style={{...H, fontWeight: theme.weight.strong, fontSize: 52}}>অস্বস্তি</span><Chip dark style={{fontSize: 42}}>কিছুটা হালকা</Chip>
              </div>
              <div style={{height: 40, borderRadius: 40, background: theme.colors.heroSoft, overflow: 'hidden'}}><div style={{width: `${interpolate(g, [0, 1], [88, 40])}%`, height: '100%', borderRadius: 40, background: theme.colors.accent}} /></div>
            </Card>
          </Enter>
        </div>
      </div>
      <Sfx at={at(30)} type="pop" />
      <Sfx at={at(31) + 6} type="pop" rate={1.08} />
      <Sfx at={at(32)} type="chime" vol={0.8} />
    </Stage>
  );
};

// ২১ — ধাপ ২: কাজ প্রায় হাস্যকর ছোট (cue 33–34)
export const Step2: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(33)} dir="down" dist={24}><Chip dark>দ্বিতীয় ধাপ</Chip></Enter>
        <Words text="কাজ *হাস্যকর ছোট* করো" delay={at(33) + 6} per={6} size={92} />
      </div>
      <div style={{display: 'flex', gap: 56, marginTop: 56, alignItems: 'center'}}>
        <Enter delay={at(34)} dir="right" dist={60} style={{flex: 1}}>
          <Card style={{height: 440, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20, opacity: 0.85}}>
            <div style={{display: 'flex'}}>{[0, 1, 2].map((i) => <div key={i} style={{marginLeft: i ? -50 : 0}}><Doc size={160} /></div>)}</div>
            <span style={{...H, fontSize: 74, color: theme.colors.textDim}}><Struck delay={at(34) + 26}>রিপোর্ট লিখব</Struck></span>
          </Card>
        </Enter>
        <Enter delay={at(34) + 44} dir="left" dist={60} cfg="bouncy" style={{flex: 1}}>
          <Card dark style={{height: 440, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 24, boxShadow: glow}}>
            <Doc size={150} fill={theme.colors.bg} />
            <span style={{...H, fontSize: 64, lineHeight: 1.35, textAlign: 'center'}}>ফাইলটা খুলব আর<br /><span style={{color: theme.colors.accent}}>একটা বাক্য</span> লিখব</span>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(33)} type="pop" />
      <Sfx at={at(34)} type="pop" rate={0.94} vol={0.8} />
      <Sfx at={at(34) + 26} type="click" />
      <Sfx at={at(34) + 44} type="chime" vol={0.8} />
    </Stage>
  );
};

// ২২ — ধাপ ৩: পাঁচ মিনিটের নিয়ম (cue 35–37)
export const Step3: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const R = 190, circ = 2 * Math.PI * R;
  const ring = useEase(at(35) + 14, len(35, 36) - 24, 'inOut');
  const wave = clamp01(((f - at(37)) % 70) / 70);
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 30}}>
          <Enter delay={at(35)} dir="down" dist={24}><Chip dark>তৃতীয় ধাপ</Chip></Enter>
          <Words text="পাঁচ মিনিটের *নিয়ম*" delay={at(35) + 6} per={7} size={112} />
          <Enter delay={at(36)} dir="right" dist={50} cfg="bouncy">
            <Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '24px 40px', alignSelf: 'flex-start'}}><Check size={60} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>থামার অনুমতি আছে</span></Card>
          </Enter>
          <Enter delay={at(37)} dir="right" dist={50}>
            <Card dark style={{display: 'flex', alignItems: 'center', gap: 26, padding: '24px 40px', alignSelf: 'flex-start', boxShadow: glow}}><Repeat size={60} color={theme.colors.onHero} /><span style={{...H, fontSize: 56}}>শুরু হলে থামাটাই কঠিন</span></Card>
          </Enter>
        </div>
        <Enter delay={at(35)} cfg="bouncy" from={0.7} style={{flexShrink: 0}}>
          <div style={{position: 'relative', width: 560, height: 560}}>
            {f > at(37) && <div style={{position: 'absolute', inset: 0, borderRadius: '50%', border: `5px solid ${theme.colors.accent}`, opacity: (1 - wave) * 0.6, transform: `scale(${1 + wave * 0.28})`}} />}
            <svg width={560} height={560} viewBox="0 0 560 560" style={{transform: 'rotate(-90deg)'}}>
              <circle cx={280} cy={280} r={R} fill={theme.colors.card} stroke={theme.colors.heroSoft} strokeWidth={34} />
              <circle cx={280} cy={280} r={R} fill="none" stroke={theme.colors.accent} strokeWidth={34} strokeLinecap="round" strokeDasharray={circ} strokeDashoffset={circ * (1 - ring)} />
            </svg>
            <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', ...H}}>
              <span style={{fontSize: 150, lineHeight: 1.1}}>৫</span><span style={{fontSize: 56, fontWeight: theme.weight.strong}}>মিনিট</span>
            </div>
          </div>
        </Enter>
      </div>
      <Sfx at={at(35)} type="pop" />
      <Sfx at={at(35) + Math.max(30, len(35, 36) - 10)} type="chime" vol={0.8} />
      <Sfx at={at(36)} type="click" />
      <Sfx at={at(37)} type="pop" rate={0.95} />
    </Stage>
  );
};
