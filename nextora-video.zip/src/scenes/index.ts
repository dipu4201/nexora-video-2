import {SceneDef} from '../scene';
import {Agenda, ArifWanted, Discomfort, FourIntro, Guilt, Hook, Label, NotWillpower, PhoneRelief, Psych, TimeSlip, Twist} from './E';
import {Cycle, FourSteps, Reason1, Reason2, Reason3, Reason4, Step1, Step2, Step3, WhichOne} from './F';
import {CommentBox, End, NextNight, Returns, Started, Step4, Subscribe, Support} from './G';

export const SCENES: SceneDef[] = [
  {id: 'hook', from: 1, to: 2, C: Hook},
  {id: 'timeSlip', from: 3, to: 3, C: TimeSlip},
  {id: 'guilt', from: 4, to: 5, C: Guilt},
  {id: 'twist', from: 6, to: 6, C: Twist},
  {id: 'agenda', from: 7, to: 7, C: Agenda},
  {id: 'label', from: 8, to: 9, C: Label},
  {id: 'arifWanted', from: 10, to: 11, C: ArifWanted},
  {id: 'psych', from: 12, to: 12, C: Psych},
  {id: 'discomfort', from: 13, to: 14, C: Discomfort},
  {id: 'phoneRelief', from: 15, to: 16, C: PhoneRelief},
  {id: 'notWillpower', from: 17, to: 17, C: NotWillpower},
  {id: 'fourIntro', from: 18, to: 18, C: FourIntro},
  {id: 'reason1', from: 19, to: 20, C: Reason1},
  {id: 'reason2', from: 21, to: 22, C: Reason2},
  {id: 'reason3', from: 23, to: 23, C: Reason3},
  {id: 'reason4', from: 24, to: 24, C: Reason4},
  {id: 'whichOne', from: 25, to: 25, C: WhichOne},
  {id: 'cycle', from: 26, to: 28, C: Cycle},
  {id: 'fourSteps', from: 29, to: 29, C: FourSteps},
  {id: 'step1', from: 30, to: 32, C: Step1},
  {id: 'step2', from: 33, to: 34, C: Step2},
  {id: 'step3', from: 35, to: 37, C: Step3},
  {id: 'step4', from: 38, to: 39, C: Step4},
  {id: 'nextNight', from: 40, to: 42, C: NextNight},
  {id: 'started', from: 43, to: 44, C: Started},
  {id: 'returns', from: 45, to: 45, C: Returns},
  {id: 'support', from: 46, to: 47, C: Support},
  {id: 'commentBox', from: 48, to: 48, C: CommentBox},
  {id: 'subscribe', from: 49, to: 49, C: Subscribe},
  {id: 'end', from: 50, to: 50, C: End},
];
