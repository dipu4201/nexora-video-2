import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from '../components/Ui';
import {DrawPath, Enter, Struck, Words, clamp01, useEase, useSpring} from '../components/Motion';
import {Check, ClockIcon, Cross, Flag, Heart, Moon, Person, Phone, Repeat, Sparkle} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {C, H, glow, glowA} from './E';

// ২৩ — ধাপ ৪: ফোন অন্য ঘরে, প্রলোভন যত দূরে শুরু তত সহজ (cue 38–39)
export const Step4: React.FC = () => {
  const {at, len} = useScene();
  const move = useEase(at(38) + 24, 36, 'inOut');
  const s = useEase(at(39) + 8, Math.max(40, len(39) - 20), 'inOut');
  const Room: React.FC<{label: string; children?: React.ReactNode; dim?: boolean}> = ({label, children, dim}) => (
    <Card style={{width: 620, height: 400, padding: 26, position: 'relative', opacity: dim ? 0.8 : 1}}>
      <Chip dark={!dim} style={{fontSize: 40}}>{label}</Chip>{children}
    </Card>
  );
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(38)} dir="down" dist={24}><Chip dark>চতুর্থ ধাপ</Chip></Enter>
        <Words text="প্রলোভন *দূরে* সরাও" delay={at(38) + 6} per={6} size={92} />
      </div>
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 60, marginTop: 46, position: 'relative'}}>
        <Enter delay={at(38) + 10} dir="right" dist={50}>
          <Room label="এই ঘর">
            <div style={{position: 'absolute', left: 60, bottom: 50}}>
              <svg width={300} height={190} viewBox="0 0 300 190"><path d="M30 150 L270 150 L240 40 L60 40 Z" fill={theme.colors.heroSoft} stroke={theme.colors.text} strokeWidth={6} strokeLinejoin="round" /></svg>
            </div>
            <div style={{position: 'absolute', right: 60, bottom: 60, opacity: 1 - move}}><Phone size={150} /></div>
          </Room>
        </Enter>
        <div style={{...H, fontSize: 90, color: theme.colors.accent, marginTop: 60}}>→</div>
        <Enter delay={at(38) + 18} dir="left" dist={50}>
          <Room label="অন্য ঘর" dim>
            <div style={{position: 'absolute', left: 230, bottom: 60, opacity: move, transform: `scale(${0.7 + move * 0.3})`}}><Phone size={150} /></div>
          </Room>
        </Enter>
      </div>
      <Enter delay={at(39)} dir="up" style={{marginTop: 46}}>
        <Card style={{display: 'flex', gap: 60, alignItems: 'center', padding: '30px 50px'}}>
          <div style={{flex: 1}}>
            <div style={{...H, fontWeight: theme.weight.strong, fontSize: 48, marginBottom: 12}}>প্রলোভন</div>
            <div style={{height: 34, borderRadius: 34, background: theme.colors.heroSoft, overflow: 'hidden'}}><div style={{width: `${interpolate(s, [0, 1], [92, 12])}%`, height: '100%', borderRadius: 34, background: theme.colors.accent}} /></div>
          </div>
          <div style={{flex: 1}}>
            <div style={{...H, fontWeight: theme.weight.strong, fontSize: 48, marginBottom: 12}}>শুরু করা সহজ</div>
            <div style={{height: 34, borderRadius: 34, background: theme.colors.heroSoft, overflow: 'hidden'}}><div style={{width: `${interpolate(s, [0, 1], [12, 92])}%`, height: '100%', borderRadius: 34, background: theme.colors.hero}} /></div>
          </div>
        </Card>
      </Enter>
      <Sfx at={at(38)} type="pop" />
      <Sfx at={at(38) + 24} type="whoosh" rate={1.1} vol={0.8} />
      <Sfx at={at(38) + 60} type="thud" vol={0.6} />
      <Sfx at={at(39)} type="pop" rate={1.05} />
    </Stage>
  );
};

// ২৪ — পরের রাত: আবার সেই ল্যাপটপ, এবার ভিন্ন কথা (cue 40–42)
export const NextNight: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const pull = Math.sin(f / 5) * 12 * clamp01((f - at(41)) / 8) * (1 - useEase(at(42) - 4, 10, 'in'));
  return (
    <Stage>
      <div style={{display: 'flex', alignItems: 'center', gap: 70}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
          <Enter delay={at(40)} dir="down" dist={30}><Chip style={{fontSize: 44, padding: '12px 36px'}}><Moon size={50} /> ১১:০০</Chip></Enter>
          <Words text="পরের দিন রাত ১১টা" delay={at(40) + 6} per={6} size={92} />
          <Enter delay={at(41)} dir="up" cfg="bouncy">
            <Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '22px 36px', alignSelf: 'flex-start'}}>
              <div style={{transform: `translateX(${pull}px)`}}><Phone size={74} /></div><span style={{...H, fontWeight: theme.weight.strong, fontSize: 54}}>পালানোর টান আবার এল</span>
            </Card>
          </Enter>
        </div>
        <Enter delay={at(40) - 4} dir="left" dist={80} style={{width: 760, height: 470, flexShrink: 0}}>
          <Photo src="images/laptop-typing.jpg" w={760} h={470} pos="42% 50%" zoomOut />
        </Enter>
      </div>
      <Enter delay={at(42)} dir="up" cfg="bouncy" style={{marginTop: 44}}>
        <Card dark style={{padding: '36px 54px', boxShadow: glow}}>
          <Words text="“আজ শুধু *ফাইলটা খুলব* আর পাঁচ মিনিট কাজ করব।”" delay={at(42) + 8} per={4} size={68} color={theme.colors.onHero} hlColor="rgba(255,184,77,0.4)" />
        </Card>
      </Enter>
      <Sfx at={at(40)} type="pop" />
      <Sfx at={at(41)} type="pop" rate={0.92} />
      <Sfx at={at(42)} type="whoosh" rate={1.05} vol={0.8} />
    </Stage>
  );
};

// ২৫ — শুরু হয়েছে: সবচেয়ে বড় জয় (cue 43–44)
export const Started: React.FC = () => {
  const {at, len} = useScene();
  const bar = useEase(at(43) + 30, 50, 'out');
  const items = ['ফোন বাইরে', 'টাইমার চালু'].map((t, i) => ({t, d: at(43) + Math.round((i * len(43)) / 2)}));
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
          {items.map((it) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}>
              <Card style={{display: 'flex', alignItems: 'center', gap: 28, padding: '28px 44px'}}>
                <div style={{width: 70, height: 70, borderRadius: 22, background: theme.colors.hero, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Check size={44} color={theme.colors.onHero} /></div>
                <span style={{...H, fontWeight: theme.weight.strong, fontSize: 64}}>{it.t}</span>
              </Card>
            </Enter>
          ))}
          <Enter delay={at(43) + 40} dir="up">
            <Card style={{padding: '28px 44px'}}>
              <div style={{display: 'flex', justifyContent: 'space-between', marginBottom: 16}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 48}}>কাজ</span><Chip>পুরোপুরি শেষ হয়নি</Chip></div>
              <div style={{height: 38, borderRadius: 38, background: theme.colors.heroSoft, overflow: 'hidden'}}><div style={{width: `${bar * 22}%`, height: '100%', borderRadius: 38, background: theme.colors.accent}} /></div>
              <div style={{...H, fontWeight: theme.weight.strong, fontSize: 46, color: theme.colors.accent, marginTop: 12}}>কিন্তু শুরু হয়েছে</div>
            </Card>
          </Enter>
        </div>
        <Enter delay={at(44)} cfg="bouncy" from={0.5} style={{width: 720, flexShrink: 0}}>
          <Card dark style={{padding: '64px 50px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 26, boxShadow: glowA}}>
            <Flag size={190} fill={theme.colors.accent} />
            <Words text="শুরু হওয়াটাই সবচেয়ে বড় *জয়*" delay={at(44) + 10} per={5} size={72} align="center" color={theme.colors.onHero} hlColor="rgba(255,184,77,0.4)" />
          </Card>
        </Enter>
      </div>
      {items.map((it, i) => <Sfx key={it.t} at={it.d + 6} type="click" rate={1 + i * 0.06} vol={0.8} />)}
      <Sfx at={at(44)} type="chime" />
    </Stage>
  );
};

// ২৬ — আক্রমণ নয়, শুধু ফিরে আসা (cue 45)
export const Returns: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const pts = [[60, 150], [260, 170], [440, 300], [560, 170], [740, 120], [900, 280], [1040, 120], [1220, 60], [1460, 40]];
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ');
  const t = useEase(at(45) + 10, len(45) - 40, 'inOut');
  const idx = Math.min(pts.length - 2, Math.floor(t * (pts.length - 1)));
  const lt = t * (pts.length - 1) - idx;
  const px = pts[idx][0] + (pts[idx + 1][0] - pts[idx][0]) * lt, py = pts[idx][1] + (pts[idx + 1][1] - pts[idx][1]) * lt;
  return (
    <Stage style={C}>
      <Enter delay={at(45)} dir="down" dist={24}><Chip dark style={{alignSelf: 'flex-start'}}>এখনো মাঝে মাঝে ফেলে রাখে</Chip></Enter>
      <Enter delay={at(45) + 8} dir="up" style={{marginTop: 30}}>
        <Card style={{padding: 30}}>
          <svg width={1520} height={380} viewBox="0 0 1520 380" style={{overflow: 'visible'}}>
            <DrawPath d={d} delay={at(45) + 10} dur={len(45) - 40} color={theme.colors.text} width={12} />
            <circle cx={px} cy={py} r={22 + Math.sin(f / 5) * 2} fill={theme.colors.accent} opacity={clamp01(t * 30)} />
          </svg>
        </Card>
      </Enter>
      <div style={{display: 'flex', gap: 50, marginTop: 40, alignItems: 'center'}}>
        <div style={{...H, fontSize: 74, color: theme.colors.textDim}}><Struck delay={at(45) + 50}>নিজেকে আক্রমণ</Struck></div>
        <Enter delay={at(45) + 100} dir="right" dist={50} cfg="bouncy"><Chip dark style={{fontSize: 62, padding: '14px 44px', boxShadow: glow}}><Repeat size={64} color={theme.colors.onHero} /> শুধু ফিরে আসে</Chip></Enter>
      </div>
      <Sfx at={at(45)} type="pop" />
      <Sfx at={at(45) + 50} type="click" />
      <Sfx at={at(45) + 100} type="chime" vol={0.8} />
    </Stage>
  );
};

// ২৭ — সহায়তা: বিশ্বস্ত মানুষ বা বিশেষজ্ঞ (cue 46–47)
export const Support: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Words text="অপরাধবোধের এই চক্র যদি *মানসিক স্বাস্থ্যকে* অনেক বেশি প্রভাবিত করে" delay={at(46)} per={4} size={70} weight={theme.weight.strong} />
      <div style={{display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 50, marginTop: 64}}>
        <Enter delay={at(47)} dir="right" dist={60}>
          <Card style={{width: 600, height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22}}><Person size={170} /><span style={{...H, fontSize: 70}}>বিশ্বস্ত মানুষ</span></Card>
        </Enter>
        <Enter delay={at(47) + 16} cfg="bouncy" from={0.4}><Heart size={120} /></Enter>
        <Enter delay={at(47) + 30} dir="left" dist={60}>
          <Card dark style={{width: 600, height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 22, boxShadow: glow}}><Person size={170} fill={theme.colors.bg} /><span style={{...H, fontSize: 70}}>বিশেষজ্ঞ</span></Card>
        </Enter>
      </div>
      <Enter delay={at(47) + 50} dir="up" style={{marginTop: 40, alignSelf: 'center'}}><Chip style={{fontSize: 46}}>কথা বলা ভালো</Chip></Enter>
      <Sfx at={at(46)} type="pop" vol={0.7} />
      <Sfx at={at(47)} type="pop" vol={0.8} />
      <Sfx at={at(47) + 30} type="pop" rate={1.06} vol={0.8} />
    </Stage>
  );
};

// ২৮ — কমেন্ট বক্স (টাইপরাইটার শুধু ইনপুট UI-তে) (cue 48)
export const CommentBox: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const words = 'তার প্রথম ছোট ধাপটা কী?'.split(' ');
  const start = at(48) + 40, per = Math.max(6, Math.floor((len(48) - 100) / words.length));
  const shown = Math.max(0, Math.min(words.length, Math.floor((f - start) / per) + 1));
  const press = useEase(start + per * words.length + 8, 10, 'out');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
        <Enter delay={at(48)} dir="down" dist={24}><Chip dark>নিচের কমেন্টে</Chip></Enter>
        <Words text="আজ রাতে যে কাজটা *ফেলে রেখেছ*" delay={at(48) + 6} per={4} size={72} />
      </div>
      <Enter delay={at(48) + 24} dir="up" cfg="bouncy" style={{marginTop: 46}}>
        <Card style={{padding: '40px 44px'}}>
          <div style={{display: 'flex', gap: 34, alignItems: 'flex-start'}}>
            <div style={{width: 100, height: 100, borderRadius: '50%', background: theme.colors.hero, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Person size={64} color={theme.colors.onHero} fill="transparent" /></div>
            <div style={{flex: 1, minHeight: 170, borderRadius: 28, border: `3px solid ${theme.colors.line}`, background: theme.colors.bgAlt, padding: '26px 36px', ...H, fontWeight: theme.weight.strong, fontSize: 66, lineHeight: 1.5}}>
              {words.slice(0, shown).join(' ')}
              <span style={{display: 'inline-block', width: 5, height: 68, background: theme.colors.accent, marginLeft: 8, verticalAlign: 'middle', opacity: f % 30 < 18 ? 1 : 0}} />
            </div>
          </div>
          <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: 24}}>
            <div style={{...H, fontSize: 46, padding: '12px 46px', borderRadius: 999, background: theme.colors.hero, color: theme.colors.onHero, transform: `scale(${1 - 0.06 * Math.sin(press * Math.PI)})`, boxShadow: press > 0.5 ? glow : 'none'}}>পাঠাও</div>
          </div>
        </Card>
      </Enter>
      <Sfx at={at(48)} type="pop" />
      <Sfx at={at(48) + 24} type="whoosh" rate={1.05} vol={0.8} />
      <Sfx at={start + per * words.length + 8} type="click" />
    </Stage>
  );
};

// ২৯ — সাবস্ক্রাইব (লোগো নেই, তাই টেক্সট-ওয়ার্ডমার্ক) (cue 49)
export const Subscribe: React.FC = () => {
  const {at, len} = useScene();
  const tags = ['সিনেমাটিক গল্প', 'বিজ্ঞান', 'বাস্তবসম্মত আত্মউন্নয়ন'].map((t, i) => ({t, d: at(49) + 10 + Math.round((i * (len(49) - 80)) / 3)}));
  const nameAt = at(49) + Math.round(len(49) * 0.55);
  const press = useEase(nameAt + 40, 12, 'out');
  const done = press > 0.6;
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
          <Words text="আরও এমন *ভিডিও* পেতে" delay={at(49)} per={5} size={92} />
          {tags.map((t) => (
            <Enter key={t.t} delay={t.d} dir="right" dist={50}>
              <Card style={{display: 'flex', alignItems: 'center', gap: 24, padding: '18px 36px', alignSelf: 'flex-start'}}><Sparkle size={50} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>{t.t}</span></Card>
            </Enter>
          ))}
        </div>
        <div style={{width: 720, flexShrink: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 44}}>
          <Enter delay={nameAt} cfg="bouncy" from={0.6} float={5}>
            <Card dark style={{padding: '70px 90px', boxShadow: glow}}>
              <span style={{...H, fontSize: 150, letterSpacing: 0}}>NextOra</span>
            </Card>
          </Enter>
          <Enter delay={nameAt + 20} dir="up" cfg="bouncy">
            <div style={{...H, fontSize: 62, padding: '20px 62px', borderRadius: 999, background: done ? theme.colors.heroSoft : theme.colors.accent, color: done ? theme.colors.text : theme.colors.bg, transform: `scale(${1 - 0.07 * Math.sin(press * Math.PI)})`, boxShadow: done ? 'none' : glowA, border: `3px solid ${theme.colors.accent}`}}>
              {done ? '✓ সাবস্ক্রাইবড' : 'সাবস্ক্রাইব'}
            </div>
          </Enter>
        </div>
      </div>
      {tags.map((t, i) => <Sfx key={t.t} at={t.d} type="pop" rate={1 + i * 0.06} vol={0.75} />)}
      <Sfx at={nameAt} type="chime" />
      <Sfx at={nameAt + 40} type="click" />
    </Stage>
  );
};

// ৩০ — সমাপ্তি: NextOra · Better Mind, Bigger Life. (cue 50)
export const End: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const glw = 0.75 + Math.sin(f / 18) * 0.25;
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
        <Enter delay={at(50)} cfg="bouncy" from={0.6} float={4}>
          <div style={{width: 560, height: 560, borderRadius: '50%', background: theme.colors.heroSoft, border: `2px solid ${theme.colors.line}`, boxShadow: `0 0 ${150 * glw}px ${theme.colors.heroGlow}, ${theme.shadow}`, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', gap: 10}}>
            <Sparkle size={90} />
            <span style={{...H, fontSize: 150, letterSpacing: 0, lineHeight: 1.2}}>NextOra</span>
          </div>
        </Enter>
        <Words text="Better Mind, Bigger Life." delay={at(50) + 22} per={7} size={104} align="center" />
      </div>
      <Sfx at={at(50)} type="chime" />
      <Sfx at={at(50) + 22} type="pop" vol={0.7} />
    </Stage>
  );
};
