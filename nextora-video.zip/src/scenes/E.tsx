import React from 'react';
import {interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from '../components/Ui';
import {DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Battery, Check, ClockIcon, Cross, Doc, Flag, Heart, Magnifier, Phone, Pin, Pulse, RainCloud, Repeat, Shield, Sparkle, Tag, Warn} from '../components/Icons';
import {Sfx} from '../components/AudioKit';

export const H: React.CSSProperties = {fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, letterSpacing: 0};
export const C: React.CSSProperties = {justifyContent: 'center'};
export const glow = `0 0 90px ${theme.colors.heroGlow}, ${theme.shadow}`;
export const glowA = `0 0 90px ${theme.colors.accentGlow}, ${theme.shadow}`;

// ১ — হুক: রাত ১১টা, ল্যাপটপ থেকে ফোনে (cue 1–2)
export const Hook: React.FC = () => {
  const {at} = useScene();
  const swap = useEase(at(2) - 4, 18, 'inOut');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 34}}>
          <Enter delay={at(1)} dir="down" dist={30}>
            <Chip style={{fontSize: 46, padding: '12px 36px'}}><ClockIcon size={50} color={theme.colors.accent} /> ১১:০০</Chip>
          </Enter>
          <Words text="রাত ১১টা।" delay={at(1) + 6} per={8} size={200} />
          <Enter delay={at(1) + 34} dir="up">
            <Card style={{display: 'flex', alignItems: 'center', gap: 26, padding: '22px 36px', alignSelf: 'flex-start'}}>
              <Flag size={70} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56}}>কাল সকালেই জমা</span>
            </Card>
          </Enter>
          <Enter delay={at(2)} dir="up" cfg="bouncy">
            <Card dark style={{display: 'flex', alignItems: 'center', gap: 26, padding: '22px 40px', alignSelf: 'flex-start', boxShadow: glow}}>
              <Phone size={70} color={theme.colors.onHero} /><span style={{...H, fontSize: 56}}>শুধু পাঁচ মিনিট…</span>
            </Card>
          </Enter>
        </div>
        <Enter delay={at(1) - 4} dir="left" dist={80} style={{width: 820, height: 640, flexShrink: 0, position: 'relative'}}>
          <Photo src="images/laptop-typing.jpg" w={820} h={640} pos="40% 50%" style={{position: 'absolute', inset: 0, opacity: 1 - swap}} />
          <Photo src="images/phone-coffee.jpg" w={820} h={640} pos="50% 50%" zoomOut style={{position: 'absolute', inset: 0, opacity: swap}} />
        </Enter>
      </div>
      <Sfx at={at(1)} type="thud" />
      <Sfx at={at(1) + 34} type="pop" />
      <Sfx at={at(2)} type="pop" rate={1.06} />
    </Stage>
  );
};

// ২ — সময় গড়িয়ে যায়: ঘড়ি ১১ → ১টা (cue 3)
export const TimeSlip: React.FC = () => {
  const {at, len} = useScene();
  const p = useEase(at(3) + 8, len(3) - 24, 'inOut');
  const hr = 330 + 60 * p, mn = 720 * p * 2.2;
  const shown = p < 0.34 ? '১১:০০' : p < 0.68 ? '১২:০০' : '০১:০০';
  const items = ['পাঁচ মিনিট', 'এক ঘণ্টা', 'দুই ঘণ্টা', 'রাত ১টা'].map((t, i) => ({t, d: at(3) + 6 + Math.round((i * (len(3) - 24)) / 4)}));
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 110}}>
        <Enter delay={at(3)} cfg="bouncy" from={0.7} style={{flexShrink: 0}}>
          <div style={{position: 'relative', width: 640, height: 780}}>
            <svg width={640} height={640} viewBox="0 0 640 640">
              <circle cx={320} cy={320} r={290} fill={theme.colors.card} stroke={theme.colors.line} strokeWidth={4} />
              {Array.from({length: 12}).map((_, i) => <path key={i} d="M320 50 L320 80" stroke={theme.colors.textDim} strokeWidth={i % 3 === 0 ? 10 : 5} strokeLinecap="round" transform={`rotate(${i * 30} 320 320)`} />)}
              <path d="M320 320 L320 200" stroke={theme.colors.text} strokeWidth={16} strokeLinecap="round" transform={`rotate(${hr} 320 320)`} />
              <path d="M320 320 L320 120" stroke={theme.colors.accent} strokeWidth={9} strokeLinecap="round" transform={`rotate(${mn} 320 320)`} />
              <circle cx={320} cy={320} r={16} fill={theme.colors.accent} />
            </svg>
            <div style={{position: 'absolute', left: 0, right: 0, top: 650, textAlign: 'center', ...H, fontSize: 104, color: theme.colors.accent}}>{shown}</div>
          </div>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
          {items.map((it, i) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}>
              <Card dark={i === 3} style={{display: 'flex', alignItems: 'center', gap: 28, padding: '22px 40px', boxShadow: i === 3 ? glow : theme.shadow}}>
                <span style={{...H, fontSize: 70, color: i === 3 ? theme.colors.onHero : theme.colors.accent, width: 70}}>{toBn(i + 1)}</span>
                <span style={{...H, fontWeight: theme.weight.strong, fontSize: 70}}>{it.t}</span>
              </Card>
            </Enter>
          ))}
        </div>
      </div>
      <Sfx at={at(3)} type="whoosh" rate={0.9} />
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={0.95 + i * 0.05} vol={0.75} />)}
    </Stage>
  );
};

// ৩ — অপরাধবোধ: কাজের উপর ভারী চাপ, "আমি অলস" (cue 4–5)
export const Guilt: React.FC = () => {
  const {at} = useScene();
  const drop = useSpring(at(4) + 20, 'bouncy');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{width: 700, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0, flexShrink: 0}}>
          <div style={{transform: `translateY(${(1 - drop) * -420}px)`, opacity: clamp01(drop * 3), zIndex: 2}}>
            <Card dark style={{padding: '30px 60px', borderRadius: 28, boxShadow: glow}}><span style={{...H, fontSize: 84}}>অপরাধবোধ</span></Card>
          </div>
          <Enter delay={at(4)} dir="up" style={{transform: 'none'}}>
            <div style={{transform: `scaleY(${1 - drop * 0.06}) translateY(${drop * 10}px)`, transformOrigin: '50% 100%', marginTop: -14}}>
              <Card style={{width: 560, height: 420, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>
                <Doc size={210} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 56, color: theme.colors.textDim}}>কাজটা পড়ে আছে</span>
              </Card>
            </div>
          </Enter>
        </div>
        <Enter delay={at(5)} dir="left" dist={70} cfg="bouncy" style={{flex: 1}}>
          <Card dark style={{padding: '60px 64px', borderRadius: 60, boxShadow: glow}}>
            <Words text="“আমি আসলে খুব *অলস!*”" delay={at(5) + 8} per={6} size={112} color={theme.colors.onHero} hlColor="rgba(255,184,77,0.4)" />
          </Card>
        </Enter>
      </div>
      <Sfx at={at(4) + 20} type="thud" />
      <Sfx at={at(5)} type="pop" />
    </Stage>
  );
};

// ৪ — মোড় নেওয়া প্রশ্ন: অলসতা নয়? (cue 6)
export const Twist: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <Words text="কাজ ফেলে রাখার আসল কারণ" delay={at(6)} per={5} size={76} weight={theme.weight.strong} color={theme.colors.textDim} align="center" />
      <div style={{display: 'flex', alignItems: 'center', gap: 56, marginTop: 24}}>
        <Enter delay={at(6) + 22} cfg="bouncy" from={0.7}>
          <span style={{...H, fontSize: 230, color: theme.colors.text, lineHeight: 1.3}}><Struck delay={at(6) + 60} thick={14}>অলসতা</Struck></span>
        </Enter>
        <Enter delay={at(6) + 80} cfg="bouncy" from={0.4}>
          <div style={{width: 190, height: 190, borderRadius: '50%', background: theme.colors.hero, boxShadow: glow, display: 'flex', alignItems: 'center', justifyContent: 'center', ...H, fontSize: 150, color: theme.colors.onHero, lineHeight: 1.2}}>নয়?</div>
        </Enter>
      </div>
      <Sfx at={at(6)} type="whoosh" />
      <Sfx at={at(6) + 60} type="click" />
      <Sfx at={at(6) + 80} type="chime" />
    </Stage>
  );
};

// ৫ — আজকের ভিডিওর পথ: আসল সমস্যা খোঁজা + বের হওয়ার পথ (cue 7)
export const Agenda: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const sc = Math.sin(f / 14) * 26;
  const d2 = at(7) + Math.round(len(7) / 2);
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 100}}>
        <Enter delay={at(7)} cfg="bouncy" from={0.6} style={{flexShrink: 0}}>
          <div style={{width: 470, height: 470, borderRadius: '50%', background: theme.colors.heroSoft, border: `2px solid ${theme.colors.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center', boxShadow: glow}}>
            <div style={{transform: `translate(${sc}px, ${-sc * 0.5}px)`}}><Magnifier size={300} color={theme.colors.text} fill={theme.colors.heroGlow} /></div>
          </div>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 36}}>
          <Enter delay={at(7) + 10} dir="right" dist={60}>
            <Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '34px 44px'}}><Pin size={90} /><span style={{...H, fontSize: 82}}>আসল সমস্যা</span></Card>
          </Enter>
          <Enter delay={d2} dir="right" dist={60} cfg="bouncy">
            <Card dark style={{display: 'flex', alignItems: 'center', gap: 30, padding: '34px 44px', boxShadow: glow}}><Repeat size={90} color={theme.colors.onHero} /><span style={{...H, fontSize: 70, lineHeight: 1.35}}>চক্র থেকে বের হওয়ার পথ</span></Card>
          </Enter>
        </div>
      </div>
      <Sfx at={at(7)} type="pop" />
      <Sfx at={at(7) + 10} type="whoosh" rate={1.05} vol={0.7} />
      <Sfx at={d2} type="pop" rate={1.08} />
    </Stage>
  );
};

// ৬ — "অলস্" ট্যাগ ও সংজ্ঞা (cue 8–9)
export const Label: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const swing = Math.sin(f / 9) * 7 * clamp01((f - at(8)) / 12);
  const lvl = 0.05 + Math.max(0, Math.sin(f / 22)) * 0.04;
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 36}}>
          <Enter delay={at(8)} cfg="bouncy" from={0.5} dir="down" dist={90}>
            <div style={{transform: `rotate(${swing}deg)`, transformOrigin: '50% 0%', display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
              <div style={{width: 6, height: 150, background: theme.colors.textDim}} />
              <div style={{width: 440, height: 230, borderRadius: 36, background: theme.colors.accent, boxShadow: glowA, position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                <div style={{position: 'absolute', top: 18, left: 195, width: 50, height: 50, borderRadius: '50%', background: theme.colors.bg}} />
                <span style={{...H, fontSize: 120, color: theme.colors.bg, marginTop: 40}}>অলস্</span>
              </div>
            </div>
          </Enter>
          <Words text="নিজেদের একটা *নাম* দিয়ে দিই" delay={at(8) + 14} per={5} size={70} weight={theme.weight.strong} align="center" />
        </div>
        <Enter delay={at(9)} dir="left" dist={70} cfg="bouncy" style={{width: 800, flexShrink: 0}}>
          <Card style={{padding: '44px 54px', display: 'flex', flexDirection: 'column', gap: 26, alignItems: 'center'}}>
            <Chip>অলসতা মানে</Chip>
            <Battery size={280} level={lvl} />
            <span style={{...H, fontSize: 62, lineHeight: 1.4, textAlign: 'center'}}>কিছু করার <span style={{color: theme.colors.accent}}>ইচ্ছাই না</span> থাকা</span>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(8)} type="pop" />
      <Sfx at={at(9)} type="whoosh" rate={1.1} vol={0.8} />
    </Stage>
  );
};

// ৭ — আরিফের ইচ্ছা ছিল ≠ শুরু করতে পারা (cue 10–11)
export const ArifWanted: React.FC = () => {
  const {at, len} = useScene();
  const items = ['ইচ্ছা ছিল', 'চিন্তাও ছিল', 'মাথার ভেতর ঘুরেছে'].map((t, i) => ({t, d: at(10) + Math.round((i * len(10)) / 3)}));
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 80}}>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
          {items.map((it) => (
            <Enter key={it.t} delay={it.d} dir="right" dist={60}>
              <Card style={{display: 'flex', alignItems: 'center', gap: 30, padding: '30px 44px'}}>
                <div style={{width: 74, height: 74, borderRadius: 24, background: theme.colors.hero, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Check size={46} color={theme.colors.onHero} /></div>
                <span style={{...H, fontWeight: theme.weight.strong, fontSize: 66}}>{it.t}</span>
              </Card>
            </Enter>
          ))}
        </div>
        <div style={{width: 720, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22, flexShrink: 0}}>
          <Enter delay={at(11)} dir="down" dist={50}><Card style={{padding: '26px 56px'}}><span style={{...H, fontSize: 68}}>ইচ্ছা থাকা</span></Card></Enter>
          <Enter delay={at(11) + 14} cfg="bouncy" from={0.3}><div style={{width: 120, height: 120, borderRadius: '50%', background: theme.colors.accent, display: 'flex', alignItems: 'center', justifyContent: 'center', ...H, fontSize: 96, color: theme.colors.bg, lineHeight: 1.2, boxShadow: glowA}}>≠</div></Enter>
          <Enter delay={at(11) + 26} dir="up" dist={50}><Card dark style={{padding: '26px 56px', boxShadow: glow}}><span style={{...H, fontSize: 68}}>শুরু করতে পারা</span></Card></Enter>
        </div>
      </div>
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 + i * 0.06} vol={0.75} />)}
      <Sfx at={at(11) + 14} type="chime" />
    </Stage>
  );
};

// ৮ — মনোবিজ্ঞান: আবেগ সামলানোর সমস্যা (cue 12)
export const Psych: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Enter delay={at(12)} dir="down" dist={24}><Chip dark>মনোবিজ্ঞানীদের মতে</Chip></Enter>
      <div style={{display: 'flex', gap: 60, marginTop: 44}}>
        <Enter delay={at(12) + 22} dir="left" dist={70} style={{flex: 1}}>
          <Card style={{height: 520, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26, opacity: 0.85}}>
            <ClockIcon size={170} /><span style={{...H, fontSize: 76, color: theme.colors.textDim}}>সময় ব্যবস্থাপনা</span><Chip>শুধু নয়</Chip>
          </Card>
        </Enter>
        <Enter delay={at(12) + 70} dir="right" dist={70} cfg="bouncy" style={{flex: 1}}>
          <Card dark style={{height: 520, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26, boxShadow: glow}}>
            <Heart size={170} /><span style={{...H, fontSize: 82}}>আবেগ সামলানো</span><Chip style={{background: theme.colors.accentSoft}}>অনেক সময়</Chip>
          </Card>
        </Enter>
      </div>
      <Sfx at={at(12)} type="pop" />
      <Sfx at={at(12) + 22} type="pop" rate={0.94} vol={0.8} />
      <Sfx at={at(12) + 70} type="chime" />
    </Stage>
  );
};

// ৯ — শুরু করতে গেলে অস্বস্তি: বিরক্তি, দুশ্চিন্তা, ভয় → পালাতে চায় (cue 13–14)
export const Discomfort: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const dim = useEase(at(14) - 4, 14, 'out');
  const feel = [
    {t: 'বিরক্তি', icon: <RainCloud size={130} />}, {t: 'দুশ্চিন্তা', icon: <Pulse size={130} />}, {t: 'ভয়', icon: <Warn size={120} />},
  ].map((x, i) => ({...x, d: at(13) + 24 + Math.round((i * (len(13) - 30)) / 3)}));
  const run = ((f - at(14)) % 36) / 36;
  return (
    <Stage style={C}>
      <Words text="শুরু করতে গেলে *অস্বস্তি*" delay={at(13)} per={6} size={96} />
      <div style={{display: 'flex', gap: 40, marginTop: 46, opacity: 1 - dim * 0.55}}>
        {feel.map((x) => (
          <Enter key={x.t} delay={x.d} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card style={{height: 330, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 20}}>{x.icon}<span style={{...H, fontSize: 70}}>{x.t}</span></Card>
          </Enter>
        ))}
      </div>
      <div style={{display: 'flex', alignItems: 'center', gap: 50, marginTop: 50}}>
        <Enter delay={at(14)} dir="up" cfg="bouncy">
          <Card style={{padding: '30px 54px', borderRadius: 60}}><span style={{...H, fontSize: 88}}>যদি ভালো না হয়?</span></Card>
        </Enter>
        <Enter delay={at(14) + 40} dir="left" dist={60}>
          <Card dark style={{display: 'flex', alignItems: 'center', gap: 24, padding: '30px 50px', boxShadow: glow}}>
            <span style={{...H, fontSize: 70}}>মস্তিষ্ক পালাতে চায়</span>
            <span style={{...H, fontSize: 80, color: theme.colors.accent, transform: `translateX(${run * 30}px)`, opacity: 1 - run * 0.6}}>→</span>
          </Card>
        </Enter>
      </div>
      {feel.map((x, i) => <Sfx key={x.t} at={x.d} type="pop" rate={1 - i * 0.05} vol={0.75} />)}
      <Sfx at={at(14)} type="pop" />
      <Sfx at={at(14) + 40} type="whoosh" rate={1.1} vol={0.7} />
    </Stage>
  );
};

// ১০ — ফোন → অস্বস্তি মিলায় → মস্তিষ্ক শেখে (cue 15–16)
export const PhoneRelief: React.FC = () => {
  const {at, len} = useScene();
  const g = useEase(at(15) + 26, Math.max(40, len(15) - 50), 'inOut');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 50, alignItems: 'stretch'}}>
        <Enter delay={at(15)} dir="up" cfg="bouncy">
          <Card style={{width: 520, height: 400, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 26}}>
            <Phone size={210} color={theme.colors.text} /><Chip>ফোন খুললে</Chip>
          </Card>
        </Enter>
        <Enter delay={at(15) + 14} dir="left" dist={60} style={{flex: 1}}>
          <Card style={{height: 400, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 34}}>
            <div style={{...H, fontWeight: theme.weight.strong, fontSize: 64}}>অস্বস্তি</div>
            <div style={{height: 46, borderRadius: 46, background: theme.colors.heroSoft, overflow: 'hidden'}}>
              <div style={{width: `${interpolate(g, [0, 1], [94, 8])}%`, height: '100%', borderRadius: 46, background: theme.colors.accent}} />
            </div>
            <Enter delay={at(15) + 70} dir="up"><Chip dark style={{fontSize: 46}}>ভালো লাগে</Chip></Enter>
          </Card>
        </Enter>
      </div>
      <Enter delay={at(16)} dir="up" cfg="bouncy" style={{marginTop: 44}}>
        <Card dark style={{display: 'flex', alignItems: 'center', gap: 40, padding: '34px 54px', boxShadow: glow}}>
          <Repeat size={110} color={theme.colors.onHero} />
          <span style={{...H, fontSize: 70, lineHeight: 1.35}}>সাময়িক স্বস্তিই শেখায়: পরেরবারও পালাও</span>
        </Card>
      </Enter>
      <Sfx at={at(15)} type="pop" />
      <Sfx at={at(15) + 26} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(15) + 70} type="click" />
      <Sfx at={at(16)} type="thud" vol={0.7} />
    </Stage>
  );
};

// ১১ — ইচ্ছাশক্তির দুর্বলতা নয়, স্বাভাবিক প্রবণতা (cue 17)
export const NotWillpower: React.FC = () => {
  const {at, len} = useScene();
  return (
    <Stage style={C}>
      <Enter delay={at(17)} dir="left" dist={70}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 40, padding: '38px 60px'}}>
          <Cross size={80} /><span style={{...H, fontSize: 96, color: theme.colors.textDim}}><Struck delay={at(17) + 34}>ইচ্ছাশক্তির দুর্বলতা</Struck></span>
        </Card>
      </Enter>
      <Enter delay={at(17) + Math.round(len(17) * 0.35)} dir="right" dist={70} cfg="bouncy" style={{marginTop: 50}}>
        <Card dark style={{display: 'flex', alignItems: 'center', gap: 40, padding: '46px 60px', boxShadow: glow}}>
          <Shield size={120} fill={theme.colors.bg} />
          <div>
            <div style={{...H, fontSize: 92, lineHeight: 1.3}}>স্বাভাবিক প্রবণতা</div>
            <div style={{...H, fontWeight: theme.weight.strong, fontSize: 52, color: theme.colors.accent, marginTop: 6}}>অস্বস্তি থেকে পালিয়ে যাওয়ার</div>
          </div>
        </Card>
      </Enter>
      <Sfx at={at(17)} type="pop" />
      <Sfx at={at(17) + 34} type="click" />
      <Sfx at={at(17) + Math.round(len(17) * 0.35)} type="chime" />
    </Stage>
  );
};

// ১২ — চারটা কারণ: ফাঁকা চার ঘর (cue 18)
export const FourIntro: React.FC = () => {
  const {at, len} = useScene();
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 100}}>
        <div style={{flex: 1}}>
          <Words text="চারটা *কারণ*" delay={at(18)} per={8} size={190} />
          <Enter delay={at(18) + 26} dir="up" style={{marginTop: 20}}><Chip style={{fontSize: 46}}>ফেলে রাখার পেছনে লুকিয়ে</Chip></Enter>
        </div>
        <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 30, width: 760, flexShrink: 0}}>
          {[1, 2, 3, 4].map((n, i) => (
            <Enter key={n} delay={at(18) + 8 + Math.round((i * (len(18) - 12)) / 4)} cfg="bouncy" from={0.6}>
              <div style={{height: 260, borderRadius: theme.radius, border: `4px dashed ${theme.colors.line}`, display: 'flex', alignItems: 'center', justifyContent: 'center', background: theme.colors.heroSoft, ...H, fontSize: 130, color: theme.colors.accent}}>{toBn(n)}</div>
            </Enter>
          ))}
        </div>
      </div>
      <Sfx at={at(18)} type="thud" vol={0.8} />
      {[0, 1, 2, 3].map((i) => <Sfx key={i} at={at(18) + 8 + Math.round((i * (len(18) - 12)) / 4)} type="pop" rate={1 + i * 0.05} vol={0.7} />)}
    </Stage>
  );
};
