// theme.ts — রং, ইজিং, spring প্রিসেট ও ফন্টের একমাত্র উৎস। কম্পোনেন্টে সরাসরি হেক্স নয়।
import {Easing} from 'remotion';

export const theme = {
  colors: {
    // স্কিম ২ — Deadline Blue
    bg: '#0A1630',
    bgAlt: '#0F1F42',
    hero: '#3D8BFF', // হিরো (প্রতি ফ্রেমে সর্বোচ্চ একটি জোরালো উপাদান)
    accent: '#FFB84D',
    text: '#EEF3FF',
    textDim: 'rgba(238,243,255,0.66)',
    textFaint: 'rgba(238,243,255,0.28)',
    onHero: '#FFFFFF',
    card: 'rgba(20,38,78,0.82)',
    cardSolid: '#13264E',
    line: 'rgba(238,243,255,0.14)',
    accentSoft: 'rgba(255,184,77,0.30)',
    accentGlow: 'rgba(255,184,77,0.42)',
    heroSoft: 'rgba(61,139,255,0.18)',
    heroGlow: 'rgba(61,139,255,0.5)',
    vignette: 'rgba(3,8,22,0.55)',
    shadow: 'rgba(2,6,18,0.6)',
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
    body: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
  },
  weight: {hero: 700, strong: 600, body: 500},
  size: {h1: 148, h2: 108, h3: 76, body: 54, label: 38, small: 30},
  radius: 36,
  shadow: '0 36px 70px -26px rgba(2,6,18,0.75), 0 6px 18px -8px rgba(2,6,18,0.5)',
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;
