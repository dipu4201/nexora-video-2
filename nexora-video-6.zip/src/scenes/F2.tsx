import React from 'react';
import {Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Stage} from '../components/Ui';
import {DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Book, Check, Cross, Doc, Coin, Flag, Heart, Moon, Person, Repeat, Scale, Shield, Sparkle} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {BlurBG, C, Flash, H, PhotoBG, PhotoCard, glow} from '../components/Kit';

const Bubble: React.FC<{who: string; t: string; d: number; right?: boolean}> = ({who, t, d, right}) => (
  <Enter delay={d} dir={right ? 'left' : 'right'} dist={50} cfg="bouncy" style={{alignSelf: right ? 'flex-end' : 'flex-start', maxWidth: 820}}>
    <Card dark={right} style={{padding: '22px 36px', borderRadius: 36, boxShadow: right ? glow : theme.shadow}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 38, opacity: 0.8}}>{who}</div><div style={{...H, fontWeight: theme.weight.strong, fontSize: 52, lineHeight: 1.35}}>“{t}”</div></Card>
  </Enter>
);

// ১২ — বোনের কলেজের ফি: মা-ছেলের কথা (cue 25–28)
export const Fee: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/mother-son.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <div style={{display: 'flex', flexDirection: 'column', gap: 24, flexShrink: 0}}>
            <Enter delay={at(25) - 4} dir="right" dist={80}><PhotoCard src="images/mother-son.jpg" w={760} h={400} pos="45% 40%" /></Enter>
            <Enter delay={at(25)} dir="up"><Chip dark style={{fontSize: 44}}>বোনের কলেজের ফি দিতে হবে</Chip></Enter>
          </div>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
            <Bubble who="মা" t="বাবা, তোর কাছে কিছু টাকা আছে?" d={at(26)} />
            <Bubble who="আরিফ" t="না মা, এখন নেই।" d={at(27)} right />
            <Bubble who="মা" t="আচ্ছা, সমস্যা নেই, আমি দেখি।" d={at(28)} />
          </div>
        </div>
      </Stage>
      <Sfx at={at(25)} type="pop" vol={0.7} />
      <Sfx at={at(26)} type="pop" vol={0.75} />
      <Sfx at={at(27)} type="thud" vol={0.6} />
      <Sfx at={at(28)} type="pop" rate={1.05} vol={0.75} />
    </>
  );
};

// ১৩ — ছাদে একা রাত (cue 29–30)
export const RoofAlone: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/rooftop-night.jpg" pos="50% 50%" side="left" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 28, width: 1050}}>
          <Enter delay={at(29)} dir="down" dist={24}><Chip>সেদিন রাতে ছাদে একা</Chip></Enter>
          <Words text="আমি কি কোনোদিন *পারব?*" delay={at(30)} per={6} size={120} />
          <Words text="নাকি সারাজীবন শুধু স্বপ্নই দেখে যাব?" delay={at(30) + 36} per={5} size={80} weight={theme.weight.strong} color={theme.colors.textDim} />
        </div>
      </Stage>
      <Sfx at={at(29)} type="pop" vol={0.6} />
      <Sfx at={at(30)} type="whoosh" rate={0.9} vol={0.6} />
    </PhotoBG>
  );
};

// ১৪ — মায়ের কথা: "সবকিছু একা সামলাতে হবে?" (cue 31–33)
export const Mother1: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/mother-comfort.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(31) - 4} dir="right" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/mother-comfort.jpg" w={880} h={480} pos="45% 40%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
            <Enter delay={at(31)} dir="down" dist={24}><Chip dark style={{fontSize: 42}}>পরদিন সকালে মাকে কষ্টের কথা বলল</Chip></Enter>
            <Enter delay={at(32)} dir="up"><Card style={{padding: '26px 38px'}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 38, opacity: 0.75}}>মা</div><Words text="“আমরা কি তোকে কখনো বলেছি, সবকিছু একা *সামলাতে* হবে?”" delay={at(32) + 6} per={4} size={58} /></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(31)} type="pop" vol={0.6} />
      <Sfx at={at(32)} type="whoosh" rate={0.95} vol={0.6} />
      <Sfx at={at(33)} type="chime" vol={0.7} />
    </>
  );
};

// ১৫ — "তুই ভালো থাক", ভার ভাগ হয়ে যায় (cue 34–35)
export const Mother2: React.FC = () => {
  const {at} = useScene();
  const share = useEase(at(35) + 8, 40, 'inOut');
  return (
    <Stage style={C}>
      <div style={{display: 'flex', gap: 40}}>
        <Enter delay={at(34)} dir="right" dist={60} style={{flex: 1}}><Card dark style={{height: 330, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, boxShadow: glow, textAlign: 'center'}}><Heart size={110} fill={theme.colors.onHero} color={theme.colors.onHero} /><span style={{...H, fontSize: 58, lineHeight: 1.3}}>তুই ভালো থাক,<br />নিজের জীবনটা ঠিক কর</span></Card></Enter>
        <Enter delay={at(35)} dir="left" dist={60} style={{flex: 1}}><Card style={{height: 330, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 18, textAlign: 'center'}}><Shield size={110} /><span style={{...H, fontSize: 58, lineHeight: 1.3}}>আমাদের যতটুকু সম্ভব<br />আমরা সামনে নেব</span></Card></Enter>
      </div>
      <Enter delay={at(35) + 8} dir="up" style={{marginTop: 44}}>
        <Card style={{padding: '36px 50px'}}>
          <div style={{display: 'flex', justifyContent: 'space-between', ...H, fontWeight: theme.weight.strong, fontSize: 44, marginBottom: 16}}><span>পরিবারের ভার</span><span style={{color: theme.colors.textDim}}>এখন ভাগ হচ্ছে</span></div>
          <div style={{display: 'flex', height: 56, borderRadius: 56, overflow: 'hidden', background: theme.colors.heroSoft}}>
            <div style={{width: `${interpolate(share, [0, 1], [100, 45])}%`, background: theme.colors.accent}} /><div style={{flex: 1, background: theme.colors.hero}} />
          </div>
          <div style={{display: 'flex', justifyContent: 'space-between', ...H, fontWeight: theme.weight.strong, fontSize: 40, marginTop: 14}}><span>আরিফ</span><span>পরিবার</span></div>
        </Card>
      </Enter>
      <Sfx at={at(34)} type="pop" vol={0.75} />
      <Sfx at={at(35)} type="pop" rate={0.94} vol={0.75} />
      <Sfx at={at(35) + 8} type="whoosh" rate={0.9} vol={0.6} />
      <Sfx at={at(35) + 40} type="chime" vol={0.8} />
    </Stage>
  );
};

// ১৬ — নিজের জীবনকে ব্যর্থতার চোখে দেখা (cue 36–37)
export const Lens: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <div style={{display: 'flex', alignItems: 'center', gap: 50}}>
        <Enter delay={at(36)} cfg="bouncy" from={0.5} style={{flexShrink: 0}}>
          <svg width={330} height={330} viewBox="0 0 100 100"><circle cx="50" cy="50" r="36" fill={theme.colors.heroSoft} stroke={theme.colors.text} strokeWidth="5" /><path d="M30 30 L48 52 L38 62 L62 78 M48 52 L70 40" fill="none" stroke={theme.colors.accent} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" /></svg>
        </Enter>
        <div style={{flex: 1}}><Words text="নিজের জীবনটাকেই *ব্যর্থতার চোখে* দেখতে শুরু করেছিল" delay={at(36) + 6} per={5} size={80} /></div>
      </div>
      <Enter delay={at(37)} dir="up" style={{marginTop: 40}}>
        <Card style={{display: 'flex', alignItems: 'center', gap: 36, padding: '30px 50px'}}><Coin size={96} /><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60, color: theme.colors.textDim, lineHeight: 1.3}}><Struck delay={at(37) + 34}>টাকা আয় করতে না পারলে আমার কোনো মূল্য নেই</Struck></span></Card>
      </Enter>
      <Sfx at={at(36)} type="pop" vol={0.7} />
      <Sfx at={at(37)} type="whoosh" rate={0.95} vol={0.6} />
      <Sfx at={at(37) + 34} type="click" />
    </Stage>
  );
};

// ১৭ — তুমি মূল্যহীন নও (cue 38)
export const Worth: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <Enter delay={at(38)} cfg="bouncy" from={0.5} style={{filter: `drop-shadow(0 0 ${40 + Math.sin(f / 9) * 14}px ${theme.colors.heroGlow})`}}><Heart size={220} /></Enter>
      <div style={{marginTop: 30}}><Words text="আজ প্রতিষ্ঠিত না হলেও" delay={at(38) + 8} per={6} size={84} weight={theme.weight.strong} color={theme.colors.textDim} align="center" /></div>
      <Words text="তুমি *মূল্যহীন নও*" delay={at(38) + 34} per={8} size={170} align="center" />
      <Flash at={at(38) + 34} />
      <Sfx at={at(38)} type="chime" />
      <Sfx at={at(38) + 34} type="thud" />
    </Stage>
  );
};

// ১৮ — পাঁচটা সিদ্ধান্ত (cue 39)
export const FiveIntro: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/decisions-card.jpg" dim={0.66} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
          <Enter delay={at(39) - 4} dir="right" dist={90} style={{flexShrink: 0}}><Card style={{padding: 14, borderRadius: 40, boxShadow: glow}}><Img src={staticFile("images/decisions-card.jpg")} style={{width: 880, height: 561, borderRadius: 28, objectFit: "cover", display: "block"}} /></Card></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
            <Enter delay={at(39)} dir="down" dist={24}><Chip dark>তাই আরিফ নিজের জন্য</Chip></Enter>
            <Words text="*পাঁচটা সিদ্ধান্ত* নিল" delay={at(39) + 8} per={7} size={116} />
          </div>
        </div>
      </Stage>
      <Sfx at={at(39)} type="whoosh" vol={0.7} />
      <Sfx at={at(39) + 10} type="chime" vol={0.8} />
    </>
  );
};

// ১৯ — পাঁচ সিদ্ধান্তের তালিকা (cue 40–44)
export const Decisions: React.FC = () => {
  const {at} = useScene();
  const items = [
    {t: 'প্রতিদিন অন্তত এক ঘণ্টা দক্ষতা বাড়ানো', d: at(40), icon: <Book size={80} />},
    {t: 'সিভির সঙ্গে ইন্টারভিউয়ের প্রস্তুতি', d: at(41), icon: <Doc size={76} />},
    {t: 'টিউশন বা ছোট কাজে আয় শুরু', d: at(42), icon: <Coin size={78} />},
    {t: 'পরিবারের সঙ্গে খোলামেলা কথা', d: at(43), icon: <Heart size={76} />},
    {t: 'নিজের শরীর ও মনের যত্ন', d: at(44), icon: <Moon size={76} />},
  ];
  return (
    <>
      <BlurBG src="images/study-green.jpg" dim={0.7} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 56}}>
          <Enter delay={at(40) - 4} dir="right" dist={80} style={{flexShrink: 0}}><PhotoCard src="images/study-green.jpg" w={640} h={500} pos="40% 40%" /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 16}}>
            {items.map((it, i) => (
              <Enter key={it.t} delay={it.d} dir="right" dist={60} cfg="bouncy">
                <Card dark={i === 4} style={{display: 'flex', alignItems: 'center', gap: 26, padding: '16px 34px', boxShadow: i === 4 ? glow : theme.shadow}}>
                  <span style={{...H, fontSize: 64, color: i === 4 ? theme.colors.onHero : theme.colors.hero, width: 56}}>{toBn(i + 1)}</span>{it.icon}
                  <span style={{...H, fontWeight: theme.weight.strong, fontSize: 46, lineHeight: 1.25}}>{it.t}</span>
                </Card>
              </Enter>
            ))}
          </div>
        </div>
      </Stage>
      {items.map((it, i) => <Sfx key={it.t} at={it.d} type="pop" rate={1 + i * 0.05} vol={0.75} />)}
    </>
  );
};

// ২০ — পরের মাসেও সব মেটেনি, কিন্তু একটা জিনিস বদলাল (cue 45–47)
export const Changed: React.FC = () => {
  const {at} = useScene();
  return (
    <Stage style={C}>
      <Enter delay={at(45)} dir="left" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 36, padding: '30px 50px'}}><Cross size={70} color={theme.colors.accent} /><span style={{...H, fontSize: 72, color: theme.colors.textDim}}><Struck delay={at(45) + 30}>বড় চাকরি</Struck> পায়নি</span></Card></Enter>
      <Enter delay={at(46)} dir="left" dist={60} style={{marginTop: 28}}><Card style={{display: 'flex', alignItems: 'center', gap: 36, padding: '30px 50px'}}><Cross size={70} color={theme.colors.accent} /><span style={{...H, fontSize: 72, color: theme.colors.textDim}}><Struck delay={at(46) + 30}>সব সমস্যা</Struck> মেটেনি</span></Card></Enter>
      <Enter delay={at(47)} dir="up" cfg="bouncy" style={{marginTop: 50}}><Card dark style={{display: 'flex', alignItems: 'center', gap: 36, padding: '44px 60px', boxShadow: glow}}><Sparkle size={110} color={theme.colors.onHero} fill={theme.colors.onHero} /><span style={{...H, fontSize: 96}}>কিন্তু একটা জিনিস বদলেছিল</span></Card></Enter>
      <Sfx at={at(45)} type="pop" vol={0.7} />
      <Sfx at={at(45) + 30} type="click" vol={0.8} />
      <Sfx at={at(46) + 30} type="click" rate={0.92} vol={0.8} />
      <Sfx at={at(47)} type="chime" />
    </Stage>
  );
};

// ২১ — চিন্তার বদল: "আমি কিছুই পারছি না" → "আজ আমি কী করতে পারি" (cue 48–49)
export const Flip: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/desk-night.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 28}}>
            <Enter delay={at(48)} dir="left" dist={60}><Card style={{padding: '30px 44px'}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 38, opacity: 0.7, marginBottom: 6}}>আগে</div><span style={{...H, fontSize: 64, color: theme.colors.textDim}}><Struck delay={at(48) + 36}>আমি কিছুই করতে পারছি না</Struck></span></Card></Enter>
            <Enter delay={at(49)} dir="up" cfg="bouncy"><Card dark style={{padding: '34px 44px', boxShadow: glow}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 38, opacity: 0.8, marginBottom: 6}}>এখন</div><span style={{...H, fontSize: 76, lineHeight: 1.25}}>আজ আমি কী করতে পারি?</span></Card></Enter>
          </div>
          <Enter delay={at(48) - 4} dir="left" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/desk-night.jpg" w={700} h={500} pos="45% 45%" zoomOut /></Enter>
        </div>
      </Stage>
      <Sfx at={at(48)} type="pop" vol={0.7} />
      <Sfx at={at(48) + 36} type="click" />
      <Sfx at={at(49)} type="chime" />
    </>
  );
};

// ২২ — বাবা-মায়ের বয়স, নিজেকে ব্যর্থ ভেবো না (cue 50–51)
export const Parents: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/family.jpg" dim={0.64} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(50) - 4} dir="right" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/family.jpg" w={880} h={460} pos="50% 40%" /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
            <Words text="বাবার বয়স বাড়ছে, মায়েরও অনেক স্বপ্ন আছে" delay={at(50)} per={4} size={58} weight={theme.weight.strong} />
            <Enter delay={at(51)} dir="up" cfg="bouncy"><Card dark style={{padding: '24px 38px', boxShadow: glow}}><span style={{...H, fontSize: 56, lineHeight: 1.3}}>সব স্বপ্ন পূরণ না পারলেও <span style={{opacity: 0.9}}><Struck delay={at(51) + 36}>নিজেকে ব্যর্থ</Struck></span> ভেবো না</span></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(50)} type="pop" vol={0.6} />
      <Sfx at={at(51)} type="chime" vol={0.8} />
      <Sfx at={at(51) + 36} type="click" vol={0.8} />
    </>
  );
};

// ২৩ — "স্বপ্নের মধ্যে তুমিও আছো" (cue 52)
export const DreamBubble: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const you = useSpring(at(52) + Math.round(len(52) * 0.55), 'bouncy');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 70}}>
        <Enter delay={at(52)} cfg="bouncy" from={0.6} style={{flexShrink: 0}}>
          <div style={{position: 'relative', width: 760, height: 620}}>
            <div style={{position: 'absolute', inset: 0, borderRadius: '50%', background: theme.colors.heroSoft, border: `3px solid ${theme.colors.hero}`, boxShadow: `0 0 ${60 + Math.sin(f / 12) * 20}px ${theme.colors.heroGlow}`}} />
            <div style={{position: 'absolute', left: 170, top: 150, display: 'flex', gap: 40, alignItems: 'center'}}>
              <Person size={150} fill={theme.colors.heroSoft} /><Person size={150} fill={theme.colors.accentSoft} />
              <div style={{transform: `scale(${you})`, opacity: clamp01(you), filter: `drop-shadow(0 0 20px ${theme.colors.heroGlow})`}}><Person size={190} fill={theme.colors.hero} /></div>
            </div>
            <div style={{position: 'absolute', left: 190, right: 190, bottom: 120, textAlign: 'center', ...H, fontSize: 56, color: theme.colors.textDim}}>বাবা-মায়ের স্বপ্ন</div>
            <div style={{position: 'absolute', left: -20, bottom: -10, width: 70, height: 70, borderRadius: '50%', background: theme.colors.heroSoft, border: `3px solid ${theme.colors.hero}`}} />
          </div>
        </Enter>
        <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 26}}>
          <Words text="সুখ-স্বাচ্ছন্দ্যের পাশাপাশি সেই স্বপ্নের মধ্যে" delay={at(52)} per={4} size={58} weight={theme.weight.strong} color={theme.colors.textDim} />
          <Enter delay={at(52) + Math.round(len(52) * 0.55)} dir="up" cfg="bouncy"><Card dark style={{padding: '30px 50px', boxShadow: glow}}><span style={{...H, fontSize: 88}}>তুমিও আছো</span></Card></Enter>
        </div>
      </div>
      <Sfx at={at(52)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(52) + Math.round(len(52) * 0.55)} type="chime" />
    </Stage>
  );
};

// ২৪ — সফল হওয়ার চেষ্টা, কিন্তু নিজেকে হারিয়ো না (cue 53)
export const Balance: React.FC = () => {
  const {at, len} = useScene();
  const t = useEase(at(53) + 20, Math.max(40, len(53) - 40), 'inOut');
  return (
    <>
      <BlurBG src="images/family-hug.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(53) - 4} dir="right" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/family-hug.jpg" w={800} h={420} pos="50% 40%" /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
            <Enter delay={at(53)} dir="up"><Card style={{padding: '24px 38px'}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 40, marginBottom: 10}}>তাদের জন্য সফল হওয়ার চেষ্টা</div><div style={{height: 34, borderRadius: 34, background: theme.colors.heroSoft}}><div style={{width: `${interpolate(t, [0, 1], [20, 80])}%`, height: '100%', borderRadius: 34, background: theme.colors.hero}} /></div></Card></Enter>
            <Enter delay={at(53) + 14} dir="up"><Card dark style={{padding: '24px 38px', boxShadow: glow}}><div style={{...H, fontSize: 44, marginBottom: 10}}>কিন্তু নিজেকে হারিয়ে ফেলো না</div><div style={{height: 34, borderRadius: 34, background: 'rgba(23,17,11,0.3)'}}><div style={{width: `${interpolate(t, [0, 1], [20, 80])}%`, height: '100%', borderRadius: 34, background: theme.colors.onHero}} /></div></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(53)} type="pop" vol={0.7} />
      <Sfx at={at(53) + 14} type="pop" rate={1.06} vol={0.7} />
      <Sfx at={at(53) + 50} type="chime" vol={0.8} />
    </>
  );
};

// ২৫ — ধীরে চলো, কিন্তু থেমে যেয়ো না (cue 54)
export const Slow: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const t = useEase(at(54) + 10, len(54) - 10, 'inOut');
  return (
    <PhotoBG src="images/arms-raised.jpg" pos="50% 40%" side="left" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', height: '100%', gap: 36, width: 1100}}>
          <Words text="ধীরে চলো," delay={at(54)} per={8} size={150} />
          <Words text="কিন্তু *থেমে যেয়ো না*" delay={at(54) + 20} per={8} size={130} />
          <Enter delay={at(54) + 30} dir="up"><div style={{height: 20, borderRadius: 20, background: theme.colors.heroSoft, width: 760}}><div style={{width: `${t * 100}%`, height: '100%', borderRadius: 20, background: theme.colors.hero}} /></div></Enter>
        </div>
      </Stage>
      <Sfx at={at(54)} type="whoosh" rate={0.9} vol={0.7} />
      <Sfx at={at(54) + 20} type="chime" vol={0.8} />
    </PhotoBG>
  );
};

// ২৬ — কমেন্ট বক্স (টাইপরাইটার শুধু ইনপুট UI-তে) (cue 55–56)
export const CommentBox: React.FC = () => {
  const f = useCurrentFrame();
  const {at, len} = useScene();
  const words = 'তোমার পরিবারের জন্য কী করতে চাও যেটা এখনো পারোনি?'.split(' ');
  const start = at(55) + 40, per = 6;
  const shown = Math.max(0, Math.min(words.length, Math.floor((f - start) / per) + 1));
  const press = useEase(at(56) + 30, 10, 'out');
  return (
    <>
      <BlurBG src="images/family-hug.jpg" dim={0.7} />
      <Stage style={C}>
        <div style={{display: 'flex', alignItems: 'center', gap: 36}}>
          <Enter delay={at(56)} dir="down" dist={24}><Chip dark>কমেন্টে জানাও</Chip></Enter>
          <Words text="তোমার পরিবারের জন্য *কী করতে চাও?*" delay={at(55)} per={5} size={74} />
        </div>
        <Enter delay={at(55) + 20} dir="up" cfg="bouncy" style={{marginTop: 46}}>
          <Card style={{padding: '40px 44px'}}>
            <div style={{display: 'flex', gap: 30, alignItems: 'flex-start'}}>
              <div style={{width: 96, height: 96, borderRadius: '50%', background: theme.colors.hero, flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center'}}><Person size={60} color={theme.colors.onHero} fill="transparent" /></div>
              <div style={{flex: 1, minHeight: 190, borderRadius: 28, border: `3px solid ${theme.colors.line}`, background: theme.colors.bgAlt, padding: '24px 34px', ...H, fontWeight: theme.weight.strong, fontSize: 56, lineHeight: 1.5}}>
                {words.slice(0, shown).join(' ')}<span style={{display: 'inline-block', width: 5, height: 58, background: theme.colors.hero, marginLeft: 8, verticalAlign: 'middle', opacity: f % 30 < 18 ? 1 : 0}} />
              </div>
            </div>
            <div style={{display: 'flex', justifyContent: 'flex-end', marginTop: 22}}><div style={{...H, fontSize: 44, padding: '12px 44px', borderRadius: 999, background: theme.colors.hero, color: theme.colors.onHero, transform: `scale(${1 - 0.06 * Math.sin(press * Math.PI)})`, boxShadow: press > 0.5 ? glow : 'none'}}>পাঠাও</div></div>
          </Card>
        </Enter>
      </Stage>
      <Sfx at={at(55)} type="pop" />
      <Sfx at={at(56) + 30} type="click" />
    </>
  );
};

// ২৭ — সাবস্ক্রাইব (cue 57)
export const Subscribe: React.FC = () => {
  const {at} = useScene();
  const press = useEase(at(57) + 56, 12, 'out');
  const done = press > 0.6;
  return (
    <>
      <BlurBG src="images/back-sunset.jpg" dim={0.62} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 90}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 30}}>
            <Words text="এমন *বাস্তব গল্প* শুনতে" delay={at(57)} per={6} size={96} />
            <Enter delay={at(57) + 30} dir="up" cfg="bouncy"><div style={{alignSelf: 'flex-start', ...H, fontSize: 66, padding: '20px 62px', borderRadius: 999, background: done ? theme.colors.heroSoft : theme.colors.hero, color: done ? theme.colors.text : theme.colors.onHero, transform: `scale(${1 - 0.07 * Math.sin(press * Math.PI)})`, boxShadow: done ? 'none' : glow, border: `3px solid ${theme.colors.hero}`, display: 'inline-block'}}>{done ? '✓ সাবস্ক্রাইবড' : 'সাবস্ক্রাইব'}</div></Enter>
          </div>
          <Enter delay={at(57) + 8} cfg="bouncy" from={0.6} float={5} style={{flexShrink: 0}}>
            <div style={{width: 560, height: 560, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 0 120px ${theme.colors.heroGlow}, ${theme.shadow}`}}><Img src={staticFile('logo.png')} style={{width: '100%', height: '100%', objectFit: 'cover'}} /></div>
          </Enter>
        </div>
      </Stage>
      <Sfx at={at(57) + 8} type="chime" />
      <Sfx at={at(57) + 56} type="click" />
    </>
  );
};

// ২৮ — সমাপ্তি (cue 58)
export const End: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  const glw = 0.75 + Math.sin(f / 18) * 0.25;
  return (
    <Stage style={{alignItems: 'center', justifyContent: 'center'}}>
      <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 40}}>
        <Enter delay={at(58)} cfg="bouncy" from={0.55} float={4}>
          <div style={{width: 600, height: 600, borderRadius: '50%', overflow: 'hidden', boxShadow: `0 0 ${150 * glw}px ${theme.colors.heroGlow}, ${theme.shadow}`}}><Img src={staticFile('logo.png')} style={{width: '100%', height: '100%', objectFit: 'cover'}} /></div>
        </Enter>
        <Words text="Better Mind, Bigger Life." delay={at(58) + 22} per={7} size={104} align="center" />
      </div>
      <Sfx at={at(58)} type="chime" />
      <Sfx at={at(58) + 22} type="pop" vol={0.7} />
    </Stage>
  );
};
