import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {useScene} from '../scene';
import {Card, Chip, Photo, Stage} from '../components/Ui';
import {Counter, DrawPath, Enter, Struck, Words, clamp01, toBn, useEase, useSpring} from '../components/Motion';
import {Book, Check, ClockIcon, Cross, Doc, Heart, Moon, Person, Repeat, Shield, Sparkle} from '../components/Icons';
import {Sfx} from '../components/AudioKit';
import {BlurBG, C, Flash, H, PhotoBG, PhotoCard, glow} from '../components/Kit';

const warm = `0 0 80px ${theme.colors.accentGlow}, ${theme.shadow}`;
const Eye: React.FC<{size?: number; color?: string}> = ({size = 90, color = theme.colors.text}) => (
  <svg width={size} height={size} viewBox="0 0 100 100"><path d="M8 50 Q50 14 92 50 Q50 86 8 50 Z" fill="none" stroke={color} strokeWidth="6" strokeLinejoin="round" /><circle cx="50" cy="50" r="14" fill={theme.colors.hero} stroke={color} strokeWidth="5" /></svg>
);

// ১ — হুক: বাবার কথা (cue 1)
export const Hook: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/father-son.jpg" dim={0.55} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(1) - 4} dir="right" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/father-son.jpg" w={860} h={560} pos="50% 40%" zoomOut /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
            <Enter delay={at(1)} dir="down" dist={24}><Chip dark>বাবা যখন বলেন</Chip></Enter>
            <Enter delay={at(1) + 8} dir="up"><div style={{...H, fontSize: 150, lineHeight: 0.7, color: theme.colors.hero}}>“</div></Enter>
            <Words text="আমাদের নিয়ে চিন্তা করিস না, তুই নিজের *ভবিষ্যৎটা* দেখ" delay={at(1) + 14} per={5} size={74} />
          </div>
        </div>
      </Stage>
      <Flash at={at(1) + 1} />
      <Sfx at={at(1)} type="thud" vol={0.7} />
      <Sfx at={at(1) + 14} type="whoosh" rate={0.9} vol={0.6} />
    </>
  );
};

// ২ — চিন্তা কি সত্যিই কমে? (cue 2–3)
export const Options: React.FC = () => {
  const {at} = useScene();
  const grow = useEase(at(3) + 6, 40, 'inOut');
  return (
    <Stage style={C}>
      <Words text="তখন কি সত্যিই চিন্তা *কমে* যায়?" delay={at(2)} per={5} size={100} />
      <Enter delay={at(2) + 24} dir="up" style={{marginTop: 50}}>
        <Card style={{padding: '44px 56px'}}>
          <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 60}}>মনের ভার</span>
            <Enter delay={at(3)} dir="left" dist={30}><Chip dark style={{fontSize: 44}}>নাকি আরও খারাপ লাগে?</Chip></Enter></div>
          <div style={{height: 50, borderRadius: 50, background: theme.colors.heroSoft, overflow: 'hidden'}}><div style={{width: `${interpolate(grow, [0, 1], [38, 94])}%`, height: '100%', borderRadius: 50, background: grow > 0.5 ? theme.colors.accent : theme.colors.hero}} /></div>
        </Card>
      </Enter>
      <Sfx at={at(2)} type="whoosh" vol={0.6} />
      <Sfx at={at(3)} type="pop" />
      <Sfx at={at(3) + 20} type="thud" vol={0.6} />
    </Stage>
  );
};

// ৩ — মানুষ দুটো তাকিয়ে আছে (cue 4–6)
export const Eyes: React.FC = () => {
  const {at} = useScene();
  const rise = useSpring(at(6) + 6, 'bouncy');
  return (
    <Stage>
      <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 40}}>
        <div style={{display: 'flex', flexDirection: 'column', gap: 30, width: 560}}>
          {['বাবা', 'মা'].map((t, i) => (
            <Enter key={t} delay={at(4) + i * 14} dir="right" dist={60}><Card style={{display: 'flex', alignItems: 'center', gap: 28, padding: '28px 42px'}}><Person size={96} fill={theme.colors.heroSoft} /><span style={{...H, fontSize: 80}}>{t}</span><Eye size={84} /></Card></Enter>
          ))}
        </div>
        <Enter delay={at(4) + 28} dir="up" style={{flex: 1}}><div style={{...H, fontSize: 90, color: theme.colors.hero, textAlign: 'center'}}>→ → →</div></Enter>
        <div style={{width: 640, display: 'flex', flexDirection: 'column', gap: 24, alignItems: 'center'}}>
          <Enter delay={at(5)} dir="up"><Chip style={{fontSize: 44}}>অনেক কিছু চায় না, শুধু চায়</Chip></Enter>
          <div style={{transform: `translateY(${(1 - rise) * 80}px) scale(${0.9 + rise * 0.1})`, opacity: clamp01(rise * 1.5)}}>
            <Card dark style={{padding: '40px 52px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14, boxShadow: glow}}><Person size={150} fill={theme.colors.onHero} color={theme.colors.onHero} /><span style={{...H, fontSize: 64, lineHeight: 1.3, textAlign: 'center'}}>একদিন তুমি নিজের পায়ে দাঁড়াও</span></Card>
          </div>
        </div>
      </div>
      <Sfx at={at(4)} type="pop" vol={0.7} />
      <Sfx at={at(4) + 14} type="pop" rate={0.94} vol={0.7} />
      <Sfx at={at(6) + 6} type="chime" />
    </Stage>
  );
};

// ৪ — আজকের গল্প আরিফের: পরিবার (cue 7–11)
export const Intro: React.FC = () => {
  const {at} = useScene();
  const cx = 960, cy = 540;
  const nodes = [
    {t: '', x: cx - 560, y: cy - 250, d: at(8), node: <Card style={{display: 'flex', alignItems: 'baseline', gap: 18, padding: '12px 36px'}}><span style={{...H, fontWeight: theme.weight.strong, fontSize: 48}}>বয়স</span><Counter from={0} to={24} delay={at(8) + 6} dur={24} style={{...H, fontSize: 100, color: theme.colors.hero}} /></Card>},
    {t: '', x: cx + 540, y: cy - 250, d: at(9), node: <Card style={{display: 'flex', alignItems: 'center', gap: 20, padding: '16px 36px'}}><Book size={70} /><span style={{...H, fontSize: 48}}>বিশ্ববিদ্যালয় শেষ</span></Card>},
    {t: '', x: cx - 580, y: cy + 60, d: at(10), node: <Card style={{display: 'flex', alignItems: 'center', gap: 20, padding: '16px 36px'}}><Person size={70} fill={theme.colors.heroSoft} /><span style={{...H, fontSize: 46, lineHeight: 1.25}}>বাবা: ছোট চাকরি</span></Card>},
    {t: '', x: cx + 580, y: cy + 60, d: at(10) + 36, node: <Card style={{display: 'flex', alignItems: 'center', gap: 20, padding: '16px 36px'}}><Heart size={66} /><span style={{...H, fontSize: 46, lineHeight: 1.25}}>মা: সংসার সামলান</span></Card>},
    {t: '', x: cx, y: cy + 300, d: at(11), node: <Card style={{display: 'flex', alignItems: 'center', gap: 20, padding: '16px 36px'}}><Person size={66} fill={theme.colors.accentSoft} /><span style={{...H, fontSize: 48}}>ছোট বোন: কলেজে</span></Card>},
  ];
  return (
    <Stage pad={0}>
      <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
        {nodes.map((n, i) => <DrawPath key={i} d={`M${cx} ${cy} L${n.x} ${n.y}`} delay={n.d - 4} dur={20} color={theme.colors.line} width={6} />)}
      </svg>
      <Enter delay={at(7)} cfg="bouncy" from={0.5} style={{position: 'absolute', left: cx - 210, top: cy - 210}}>
        <div style={{width: 420, height: 420, borderRadius: '50%', overflow: 'hidden', border: `6px solid ${theme.colors.hero}`, boxShadow: glow}}><Img src={staticFile('images/back-sunset.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', objectPosition: '50% 40%'}} /></div>
      </Enter>
      <div style={{position: 'absolute', left: 0, right: 0, top: 70, display: 'flex', justifyContent: 'center'}}><Enter delay={at(7)} dir="down" dist={24}><Chip dark style={{fontSize: 56, padding: '10px 50px'}}>আজকের গল্প আরিফের</Chip></Enter></div>
      {nodes.map((n, i) => <div key={i} style={{position: 'absolute', left: n.x - 250, top: n.y - 50, width: 500, display: 'flex', justifyContent: 'center'}}><Enter delay={n.d} cfg="bouncy" from={0.8}>{n.node}</Enter></div>)}
      <Sfx at={at(7)} type="chime" vol={0.8} />
      {nodes.map((n, i) => <Sfx key={i} at={n.d} type="pop" rate={1 + i * 0.05} vol={0.7} />)}
    </Stage>
  );
};

// ৫ — স্বপ্ন: নিজের উপার্জনে বাবা-মায়ের কষ্ট দূর (cue 12)
export const Dream: React.FC = () => {
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/family.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
            <Enter delay={at(12)} dir="down" dist={24}><Chip dark><Sparkle size={44} color={theme.colors.onHero} fill={theme.colors.onHero} /> আরিফের স্বপ্ন</Chip></Enter>
            <Words text="নিজের উপার্জনে বাবা-মায়ের *সব কষ্ট দূর* করবে" delay={at(12) + 8} per={5} size={84} />
          </div>
          <Enter delay={at(12) - 4} dir="left" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/family.jpg" w={900} h={470} pos="50% 40%" zoomOut /></Enter>
        </div>
      </Stage>
      <Sfx at={at(12)} type="chime" vol={0.8} />
      <Sfx at={at(12) + 8} type="whoosh" rate={0.95} vol={0.6} />
    </>
  );
};

// ৬ — ছয় মাস চাকরি খুঁজেও কিছু হয়নি (cue 13)
export const SixMonths: React.FC = () => {
  const {at, len} = useScene();
  const tiles = Array.from({length: 6}).map((_, i) => at(13) + 20 + Math.round((i * (len(13) - 30)) / 6));
  return (
    <>
      <BlurBG src="images/job-search.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(13) - 4} dir="right" dist={90} style={{flexShrink: 0}}><PhotoCard src="images/job-search.jpg" w={880} h={430} pos="40% 40%" /></Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24}}>
            <Words text="*ছয় মাস* চাকরি খুঁজেও কিছু হচ্ছিল না" delay={at(13)} per={5} size={76} />
            <div style={{display: 'flex', gap: 14}}>
              {tiles.map((d, i) => <Enter key={i} delay={d} cfg="bouncy" from={0.5} style={{flex: 1}}><Card style={{height: 110, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 0}}><span style={{...H, fontSize: 46, color: theme.colors.textDim}}>{toBn(i + 1)}</span></Card></Enter>)}
            </div>
            <Enter delay={at(13) + 20 + len(13) - 20} dir="up"><Chip style={{fontSize: 44}}>মাস</Chip></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(13)} type="pop" vol={0.7} />
      {tiles.map((d, i) => <Sfx key={i} at={d} type="click" rate={0.9 + i * 0.04} vol={0.45} />)}
    </>
  );
};

// ৭ — বন্ধুরা চাকরি পাচ্ছে, আরিফ ব্যর্থ (cue 14–16)
export const Friends: React.FC = () => {
  const {at, len} = useScene();
  const ds = [0, 1, 2, 3].map((i) => at(14) + 8 + Math.round((i * len(14)) / 4));
  const you = useEase(at(16) + 10, 20, 'out');
  return (
    <Stage style={C}>
      <Words text="বন্ধুরা একে একে চাকরি পাচ্ছিল" delay={at(14)} per={5} size={84} />
      <div style={{display: 'flex', gap: 30, marginTop: 50}}>
        {ds.map((d, i) => (
          <Enter key={i} delay={d} dir="up" cfg="bouncy" style={{flex: 1}}>
            <Card dark={i < 4} style={{height: 250, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, boxShadow: glow}}><Person size={110} fill={theme.colors.onHero} color={theme.colors.onHero} /><Check size={56} color={theme.colors.onHero} /></Card>
          </Enter>
        ))}
        <Enter delay={at(16)} dir="up" cfg="bouncy" style={{flex: 1}}>
          <Card style={{height: 250, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 12, filter: `grayscale(${you})`}}><Person size={110} fill={theme.colors.heroSoft} /><Repeat size={56} color={theme.colors.accent} /></Card>
        </Enter>
      </div>
      <div style={{display: 'flex', gap: 24, marginTop: 40}}>
        <Enter delay={at(15)} dir="up" cfg="bouncy"><Chip dark style={{fontSize: 46}}><Sparkle size={44} color={theme.colors.onHero} fill={theme.colors.onHero} /> প্রথম বেতনে বাবা-মাকে উপহার</Chip></Enter>
        <Enter delay={at(16) + 14} dir="up" cfg="bouncy"><Chip style={{fontSize: 46}}>আরিফ প্রতিদিন নতুন চেষ্টা, তবু ব্যর্থ</Chip></Enter>
      </div>
      {ds.map((d, i) => <Sfx key={i} at={d} type="pop" rate={1 + i * 0.06} vol={0.7} />)}
      <Sfx at={at(15)} type="chime" vol={0.7} />
      <Sfx at={at(16)} type="thud" vol={0.6} />
    </Stage>
  );
};

// ৮ — বাবার ওষুধ: মা-বাবার কথোপকথন (cue 17–20)
export const Medicine: React.FC = () => {
  const {at} = useScene();
  const bubbles = [
    {who: 'মা', t: 'তোমার বাকি ওষুধগুলো আনোনি?', d: at(18), right: false},
    {who: 'বাবা', t: 'না, কয়েকটা নিয়েছি, বাকিগুলো পরে নেব।', d: at(19), right: true},
    {who: 'বাবা', t: 'এই মাসে একটু খরচ বেশি।', d: at(20), right: true},
  ];
  return (
    <>
      <BlurBG src="images/father-medicine.jpg" dim={0.6} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <div style={{display: 'flex', flexDirection: 'column', gap: 24, flexShrink: 0}}>
            <Enter delay={at(17) - 4} dir="right" dist={80}><PhotoCard src="images/father-medicine.jpg" w={760} h={420} pos="45% 40%" zoomOut /></Enter>
            <Enter delay={at(17)} dir="up"><Chip dark style={{fontSize: 44}}>বিকেলে বাবা ওষুধ নিয়ে ফিরলেন</Chip></Enter>
          </div>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 22}}>
            {bubbles.map((b, i) => (
              <Enter key={i} delay={b.d} dir={b.right ? 'left' : 'right'} dist={50} cfg="bouncy" style={{alignSelf: b.right ? 'flex-end' : 'flex-start', maxWidth: 820}}>
                <Card dark={b.right} style={{padding: '22px 36px', borderRadius: 36, boxShadow: b.right ? glow : theme.shadow}}><div style={{...H, fontWeight: theme.weight.strong, fontSize: 40, opacity: 0.8}}>{b.who}</div><div style={{...H, fontWeight: theme.weight.strong, fontSize: 52, lineHeight: 1.35}}>“{b.t}”</div></Card>
              </Enter>
            ))}
          </div>
        </div>
      </Stage>
      <Sfx at={at(17)} type="pop" vol={0.7} />
      {bubbles.map((b, i) => <Sfx key={i} at={b.d} type="pop" rate={i ? 0.92 : 1.05} vol={0.75} />)}
    </>
  );
};

// ৯ — পাশের ঘর থেকে শোনা, ব্যাংক ব্যালেন্স (cue 21–23)
export const Listening: React.FC = () => {
  const f = useCurrentFrame();
  const {at} = useScene();
  return (
    <>
      <BlurBG src="images/bank.jpg" dim={0.66} />
      <Stage>
        <div style={{display: 'flex', height: '100%', alignItems: 'center', gap: 60}}>
          <Enter delay={at(21)} dir="right" dist={60} style={{width: 840, flexShrink: 0}}>
            <Card style={{padding: 30}}>
              <svg width={780} height={380} viewBox="0 0 780 380">
                <rect x="10" y="20" width="360" height="340" rx="20" fill={theme.colors.heroSoft} stroke={theme.colors.text} strokeWidth="5" />
                <rect x="410" y="20" width="360" height="340" rx="20" fill={theme.colors.accentSoft} stroke={theme.colors.text} strokeWidth="5" />
                {[0, 1, 2].map((k) => <path key={k} d={`M${400 - k * 0} ${190 - 40 - k * 26} Q${360 - k * 30} 190 400 ${190 + 40 + k * 26}`} fill="none" stroke={theme.colors.hero} strokeWidth="5" opacity={0.3 + 0.7 * Math.abs(Math.sin((f - at(21)) / 9 - k * 0.8))} />)}
                <circle cx="190" cy="190" r="46" fill={theme.colors.hero} /><circle cx="590" cy="190" r="46" fill={theme.colors.textFaint} />
              </svg>
              <div style={{display: 'flex', justifyContent: 'space-between', ...H, fontWeight: theme.weight.strong, fontSize: 44, padding: '0 40px'}}><span>আরিফ, পাশের ঘরে</span><span style={{color: theme.colors.textDim}}>বাবা-মা</span></div>
            </Card>
          </Enter>
          <div style={{flex: 1, display: 'flex', flexDirection: 'column', gap: 24, alignItems: 'center'}}>
            <Enter delay={at(22)} dir="left" dist={80}><PhotoCard src="images/bank.jpg" w={600} h={360} pos="50% 40%" /></Enter>
            <Enter delay={at(23)} dir="up" cfg="bouncy"><Card dark style={{padding: '18px 56px', boxShadow: glow}}><span style={{...H, fontSize: 70}}>কয়েকশ টাকা</span></Card></Enter>
          </div>
        </div>
      </Stage>
      <Sfx at={at(21)} type="pop" vol={0.6} />
      <Sfx at={at(22)} type="whoosh" rate={1.05} vol={0.6} />
      <Sfx at={at(23)} type="thud" vol={0.7} />
    </>
  );
};

// ১০ — এত বড় হয়েও ওষুধ কেনার সামর্থ্য নেই (cue 24)
export const Thought: React.FC = () => {
  const {at} = useScene();
  return (
    <PhotoBG src="images/rooftop-dusk.jpg" pos="40% 50%" side="right" zoomOut>
      <Stage>
        <div style={{display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'flex-start', height: '100%', gap: 24, width: 1000}}>
          <Enter delay={at(24)} dir="down" dist={24}><Chip>আরিফের মনে হলো</Chip></Enter>
          <Words text="এত বড় হয়েও," delay={at(24) + 6} per={6} size={96} weight={theme.weight.strong} color={theme.colors.textDim} />
          <Words text="বাবার ওষুধ কেনার *সামর্থ্য* তার নেই" delay={at(24) + 26} per={6} size={104} />
        </div>
      </Stage>
      <Sfx at={at(24)} type="pop" vol={0.6} />
      <Sfx at={at(24) + 26} type="thud" vol={0.7} />
    </PhotoBG>
  );
};

// ১১ — শ্বাসের বিরতি: SRT-র ৬৮ সেকেন্ডের ফাঁক (cue 24 → 25), শুধু ভিজ্যুয়াল
export const Breath: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <PhotoBG src="images/rooftop-night.jpg" pos="45% 50%" side="full" panX={-60}>
      <AbsoluteFill>
        {Array.from({length: 22}).map((_, i) => {
          const sx = (i * 211) % 1920, sp = 0.18 + ((i * 41) % 10) / 40, size = 3 + (i % 4) * 2;
          const y = 1080 - ((f * sp * 1.2 + i * 97) % 1180);
          return <div key={i} style={{position: 'absolute', left: sx + Math.sin(f / 50 + i) * 22, top: y, width: size, height: size, borderRadius: '50%', background: theme.colors.hero, opacity: 0.25 + 0.25 * Math.sin(f / 24 + i)}} />;
        })}
      </AbsoluteFill>
    </PhotoBG>
  );
};
