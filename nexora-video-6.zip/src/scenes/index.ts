import {SceneDef} from '../scene';
import {Breath, Dream, Eyes, Friends, Hook, Intro, Listening, Medicine, Options, SixMonths, Thought} from './F1';
import {Balance, Changed, CommentBox, Decisions, DreamBubble, End, Fee, FiveIntro, Flip, Lens, Mother1, Mother2, Parents, RoofAlone, Slow, Subscribe, Worth} from './F2';

export const SCENES: SceneDef[] = [
  {id: 'hook', from: 1, to: 1, C: Hook},
  {id: 'options', from: 2, to: 3, C: Options},
  {id: 'eyes', from: 4, to: 6, C: Eyes},
  {id: 'intro', from: 7, to: 11, C: Intro},
  {id: 'dream', from: 12, to: 12, C: Dream},
  {id: 'sixMonths', from: 13, to: 13, C: SixMonths},
  {id: 'friends', from: 14, to: 16, C: Friends},
  {id: 'medicine', from: 17, to: 20, C: Medicine},
  {id: 'listening', from: 21, to: 23, C: Listening},
  {id: 'thought', from: 24, to: 24, C: Thought},
  {id: 'breath', from: 24, to: 24, gapFrom: 24, C: Breath},
  {id: 'fee', from: 25, to: 28, C: Fee},
  {id: 'roofAlone', from: 29, to: 30, C: RoofAlone},
  {id: 'mother1', from: 31, to: 33, C: Mother1},
  {id: 'mother2', from: 34, to: 35, C: Mother2},
  {id: 'lens', from: 36, to: 37, C: Lens},
  {id: 'worth', from: 38, to: 38, C: Worth},
  {id: 'fiveIntro', from: 39, to: 39, C: FiveIntro},
  {id: 'decisions', from: 40, to: 44, C: Decisions},
  {id: 'changed', from: 45, to: 47, C: Changed},
  {id: 'flip', from: 48, to: 49, C: Flip},
  {id: 'parents', from: 50, to: 51, C: Parents},
  {id: 'dreamBubble', from: 52, to: 52, C: DreamBubble},
  {id: 'balance', from: 53, to: 53, C: Balance},
  {id: 'slow', from: 54, to: 54, C: Slow},
  {id: 'comment', from: 55, to: 56, C: CommentBox},
  {id: 'subscribe', from: 57, to: 57, C: Subscribe},
  {id: 'end', from: 58, to: 58, C: End},
];
