// theme.ts — রং, ইজিং, spring প্রিসেট ও ফন্টের একমাত্র উৎস। কম্পোনেন্টে সরাসরি হেক্স নয়।
import {Easing} from 'remotion';

export const theme = {
  colors: {
    // স্কিম ২ — Warm Home Lamp
    bg: '#15110D',
    bgAlt: '#1F1812',
    hero: '#E9A23B', // হিরো ল্যাম্পের অ্যাম্বার (প্রতি ফ্রেমে সর্বোচ্চ একটি জোরালো উপাদান)
    accent: '#FF8A5C',
    text: '#F7EFE3',
    textDim: 'rgba(247,239,227,0.66)',
    textFaint: 'rgba(247,239,227,0.28)',
    onHero: '#17110B',
    card: 'rgba(38,29,22,0.88)',
    cardSolid: '#261D16',
    line: 'rgba(247,239,227,0.15)',
    accentSoft: 'rgba(255,138,92,0.26)',
    accentGlow: 'rgba(255,138,92,0.45)',
    heroSoft: 'rgba(233,162,59,0.16)',
    heroGlow: 'rgba(233,162,59,0.45)',
    vignette: 'rgba(0,0,0,0.55)',
    shadow: 'rgba(0,0,0,0.65)',
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
    body: '"Hind Siliguri", "Noto Sans Bengali", "FreeSans", sans-serif',
  },
  weight: {hero: 700, strong: 600, body: 500},
  size: {h1: 148, h2: 108, h3: 76, body: 54, label: 38, small: 30},
  radius: 36,
  shadow: '0 36px 70px -26px rgba(0,0,0,0.8), 0 6px 18px -8px rgba(0,0,0,0.55)',
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;
